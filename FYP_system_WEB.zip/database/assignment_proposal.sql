CREATE DATABASE  IF NOT EXISTS `assignment` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `assignment`;
-- MySQL dump 10.13  Distrib 5.6.17, for Win32 (x86)
--
-- Host: localhost    Database: assignment
-- ------------------------------------------------------
-- Server version	5.6.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `proposal`
--

DROP TABLE IF EXISTS `proposal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proposal` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `proposal_title` varchar(250) NOT NULL,
  `supervisor_name` varchar(100) NOT NULL,
  `proposal_description` varchar(1000) NOT NULL,
  `objective` varchar(1000) NOT NULL,
  `scope` varchar(1000) NOT NULL,
  `number_of_students` int(11) NOT NULL,
  `proposal_status` varchar(30) DEFAULT 'Pending Approval',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  UNIQUE KEY `proposal_title_UNIQUE` (`proposal_title`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proposal`
--

LOCK TABLES `proposal` WRITE;
/*!40000 ALTER TABLE `proposal` DISABLE KEYS */;
INSERT INTO `proposal` VALUES (1,'test title','Dr.Spongebob','test desc','test obj','test scope',1,'Pending Approval'),(4,'test','Leong Jean Cheong','test','test','tsets',1,'Pending Approval'),(5,'test2','Leong Jean Cheong','testtttt','tttttttttttt','ttttttttttttttttttt',1,'Pending Approval'),(6,'Hello','Teh Jiing Joe','Hello','Hello','Hello',2,'Approve'),(8,'Web Application','Teh Jiing Joe','Describe Title','Create a web application','Basic Web Application',1,'Reject'),(9,'hhhh','Teh Jiing Joe','hhhhh','hhhhhh','hhhhhhhhh',2,'Approve'),(10,'qqqqqqqq','Teh Jiing Joe','qqqqhufeudeuifnenejnf','qqqqqqqqfuiefuiehnfuiefui','qqqqqqqqqq',1,'Approve'),(11,'111111111111','Teh Jiing Joe','1111111111111111','11111111111','111111111111',1,'Reject'),(12,'12','Teh Jiing Joe','12312313213123213','12312131331233','1321332233',1,'Approve'),(13,'Non-fungible tokens as digital attendance on blockchains','Timothy','In this project, non-fungible tokens (NFT) are minted and distributed to students as proof of attendance. The project looks into the development of a framework to automatically distribute the NFTs to students once their attendance is confirmed. The framework will look into the process and validation of the whole attendance system, including the lecturers’ and students’ role in the system. The deliverable is a decentralized application (DApp) that allows for the tracking of the students’ attendance.','1. Design the framework of the attendance taking DApp with the use of NFT\r\n2. Design the data flow and determine the data requirements of the DApp\r\n3. Develop the smart contracts applicable to the DApp\r\n4. Design the UX and screen design flow','Decentralized application on Ethereum\r\nSmart contracts and tokens\r\nWeb and mobile applications',1,'Approve'),(14,'Shit','Timothy','shit description','1. web\r\n2. app\r\n','1. web \r\n2. trust',1,'Approve');
/*!40000 ALTER TABLE `proposal` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-04-01 16:16:25
