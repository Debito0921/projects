<?php
	include "config.php";
	// Check user login or not
	if(!isset($_SESSION['email'])){
		header('Location: login.php');
	}

    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit'])) {
        $supervisor_name = trim($_SESSION['name']);
        $name = trim($_POST['student_name']);

        $get_id = "SELECT * FROM student WHERE student_name='".$name."'";
        $get_ids = mysqli_query($con,$get_id);

        $get_idss = $get_ids->fetch_assoc();

        $id = trim($get_idss['student_id']);
        $title = trim($_POST['title']);
        $start_time = trim($_POST['start_time']);
        $end_time = trim($_POST['end_time']);
        $date = trim($_POST['date']);
        $link = trim($_POST['link']);
        $status = trim('Pending');

		if($query = $con->prepare("SELECT * FROM meeting WHERE student_name = ?")) {
            $error = '';

            $query->bind_param('s', $name);
            $query->execute();
            $query->store_result();


			$error = '';
			if(empty($error)){
				$sql = $con->prepare("INSERT INTO meeting (supervisor_name, student_name, student_id, date, start_time, end_time, link, status) VALUES (?,?,?,?,?,?,?,?);");
				$sql->bind_param("ssssssss", $supervisor_name, $name, $id, $date, $start_time, $end_time, $link, $status);
				$result = $sql->execute();
				if ($result) {
					$error .= "<p class='success'>Successful Added!</p>";
				} else {
					$error .= "<p class='error'>Not Successful Added!</p>";
				}
			}
		}
		// $row = mysqli_fetch_array($result);
		
		$query->close();
		$sql->close();
		mysqli_close($con);

		header('Location: meeting.php');
	}
    
    $get = "SELECT * FROM meeting WHERE supervisor_name='".$_SESSION['name']."'";
    $resultss = mysqli_query($con,$get);
    $getssss = "SELECT * FROM meeting WHERE student_name='".$_SESSION['name']."'";
    $resultsss = mysqli_query($con,$getssss);

    $student_name = "SELECT * FROM student WHERE student_name='".$_SESSION['name']."'";
    $get_students = mysqli_query($con,$student_name);

    $student_proposal = "SELECT * FROM assign_project WHERE supervisor_name='".$_SESSION['name']."'";
    $student_proposals = mysqli_query($con,$student_proposal);
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Meeting</title>
        <link rel="stylesheet"  href ="css/menu.css"/>
	    <script src="css/menu.js"></script>
		<link rel="stylesheet" href="css/tracking.css" />
        <style>
			body {
			  background-image: url('background.jpg');
			  background-repeat: no-repeat;
			  background-size: cover;
			}
            .goal fieldset {
            margin: 1em auto;
            background-color: #E3E4FA;
            width: 85%;
            }

            .goal legend {
            background-color: #CCCCFF;
            color: #454545;
            margin: 0 auto;
            width: 90%;
            padding: 0.5em;
            text-align: center;
            font-weight: bold;
            font-size: 28px;
            }
            .goal captions {
                padding: 1.5em 1.5em; 
                font-weight: bold;
                font-size: 26px;
            }

            div#titlebox {    
                margin-top: 1em; 
                margin-left: 5em;
            }

            .goal input[type=text] {
                font-size: 15px;
                width: 650px;   
            }

            .goal label {
                font-size : 18px;
            }

            .goal input[type=submit] {
                font-size : 18px;
                margin : 1em 1em 1em 1em;
            }



            /* table formatting */
            table{
                margin:0.7em auto;
                width:90%;
                color: #666;
                font-size:1.15em;
            }

            tr {
                padding:0.75rem;
            }

            td,th {
                padding:0.75rem;
                text-align: left;
                
            }

            th {
                font-size:1.2em;
            }
			.isDisabled {
                color: currentColor;
                cursor: not-allowed;
                opacity: 0.5;
                text-decoration: none;
                pointer-events: none;
            }
        </style>
    </head>
    <body>
        <header>
            <h1><img src="images/MMUnewLogo.png" alt="MMU" width = "270" height = "70"/></h1>
            <hr>
            <h2> Set a Meeting </h2>
            <hr>
        </header>
        <div id="mySidenav" class="sidenav">
            <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
            <a href="homepage.php"><?php echo $_SESSION['name'] ?></a>
        <br/>
        <a href="homepage.php">Home</a>
        <?php
            $auth = "SELECT * FROM student WHERE student_name='".$_SESSION['name']."';";
            $_auth = mysqli_query($con, $auth);

            $register = "SELECT * FROM assign_project;";
            $registered = mysqli_query($con, $register);
			$emptyArray = array();
			$emptyArray2 = array();
			
			$trackresult = "SELECT * FROM result WHERE student_name='".$_SESSION['name']."';";
			$registered2 = mysqli_query($con, $trackresult);
			
			
            while($_registered = mysqli_fetch_array($registered)){
				
                $emptyArray[] = $_registered['student_name'];
				
            }
			
			while ($_registered2 = mysqli_fetch_array($registered2) ) {
				
				$emptyArray2[] = $_registered2['student_name'];
			}
			
			

            while($_auth_ = $_auth->fetch_assoc()){
                if($_auth_['role'] == 'student') {
                    if(!in_array($_SESSION['name'],$emptyArray)){
                        echo "<a href='myFYP.php' class='isDisabled'>My FYP</a>";
                        echo "<a href='planning.php' class='isDisabled'>Planning</a>";
                        echo "<a href='meeting.php' class='isDisabled'>Meeting</a>";
                        echo "<a href='tracking.php' class='isDisabled'>Progress Tracking</a>";
                        echo "<a href='result.php' class='isDisabled'>Result</a>";
                    } else {
                        echo "<a href='myFYP.php'>My FYP</a>";
                        echo "<a href='planning.php'>Planning</a>";
                        echo "<a href='meeting.php'>Meeting</a>";
                        echo "<a href='tracking.php'>Progress Tracking</a>";
						if( !in_array($_SESSION['name'],$emptyArray2) ){
							echo "<a href='result.php' class ='isDisabled'>Result</a>";
						} else {
								echo "<a href='result.php'>Result</a>";
						}
				
					} 

                } 
                if($_auth_['role'] == 'supervisor'){
                    echo "<a href='proposal.php'>Proposal</a>";
                    echo "<a href='list.php'>List of Proposal</a>";
                    echo "<a href='proposal_view.php'>Proposal Status</a>";
                    echo "<a href='project.php'>Project Assignment</a>";
                    echo "<a href='meeting.php'>Meeting</a>";
                    echo "<a href='result.php'>Marksheet</a>";
                }
            }
        ?>

        <?php
            $gets = "SELECT * FROM student WHERE student_name='".$_SESSION['name']."';";
            $results = mysqli_query($con, $gets);

            while($row = $results->fetch_assoc()){
                if($row['role'] == 'admin') {
                    echo "<a href='admin_approval.php'>For Admin only</a>";
                } else {
                    echo "";
                }
            }
        ?>
        
        <a href='logout.php'>Logout</a>
        </div>
    
        <span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; Menu</span>

		<div id="goalSetting" class="goal">
        <?php 
            $row_students = $get_students->fetch_assoc();
                if ($row_students['role'] == 'supervisor'){
                    echo '<fieldset>
                    <legend> Set A Meeting </legend>
                    <div id="titlebox">
                    <form action="" method="POST">
                        <p>
                        <label for="student_name">Name:</label>';
                            echo '<select name="student_name">';
                            while ($getss = $student_proposals->fetch_assoc()){
                                echo '<option>'.$getss['student_name'].'</option>';
                            }
                            echo '</select>';
                        echo '<p>
                            <label for="date"> Date </label> 
                            <input type="date" name="date" required/>
                        </p>
                        <p>
                            <label for="start_time"> Start Time </label> 
                            <input type="time" name="start_time" required/>
                        </p>
                        <p>
                            <label for="end_time"> End Time </label> 
                            <input type="time" name="end_time" required/>
                        </p>
                        <p>
                            <label for="link"> Link </label> 
                            <input type="text" name="link" required/>
                        </p>
                        <p>
                            <input type="submit" name="submit" value="Submit">
                        </p>
                    </form>
                    </div>
                </fieldset>
                <fieldset>
                    <legend> Meeting Tracking </legend>
                    <div id ="trackingTable">
                        <table>
                            <thead>
                                <tbody>
                                    <tr>
                                        <th title ="student_name" style="text-align:center"> Student Name </th>
                                        <th title ="student_id" style="text-align:center"> Student ID </th>
                                        <!-- <th title ="title" style="text-align:center"> Title </th> -->
                                        <th title ="date" style="text-align:center"> Date </th>
                                        <th title ="start_time" style="text-align:center"> Start Time </th>
                                        <th title ="end_time" style="text-align:center">End Time</th>
                                        <th title ="link" style="text-align:center"> Link </th>
                                        <th title="status" style="text-align:center">Status</th>
                                        <th></th>
                                        <th title="Complete" style="text-align:center"></th>
                                    </tr>
                                </tbody>
                            </thead>
                            <thead>
                            <form action="" method="POST">
                                <tbody>';
                                        while($row = $resultss->fetch_assoc()) {
                                            echo "<tr>";
                                            echo "<td style='text-align:center'>".$row['student_name']."</td>";
                                            echo "<td style='text-align:center'>".$row['student_id']."</td>";
                                            // echo "<td style='text-align:center'>".$row['title']."</td>";
                                            echo "<td style='text-align:center'>".$row['date']."</td>";
                                            echo "<td style='text-align:center'>".$row['start_time']."</td>";
                                            echo "<td style='text-align:center'>".$row['end_time']."</td>";
                                            echo "<td style='text-align:center'><a href=".$row['link'].">".$row['link']."</a></td>";
                                            echo "<td style='text-align:center'>".$row['status']."</td>";
                                            // echo '<td><button type="button" href="#myModal" data-bs-toggle="modal">Update Progress</button>';
                                            if ($row['status'] == 'Complete'){
                                                echo "<td style='text-align:center'><a href='view_meeting_log.php?id=".$row['id']."'><button type='button'>Meeting Log</button></a></td>";
                                            } else if($row['status'] == 'Accept') {
                                                echo "<td><input type='submit' name='done' value='Mark as Done'></td>";
                                                echo "<td><input type='hidden' name='dates' value='".$row['date']."' /></td>";
                                            } else {
                                                echo "<td></td>";
                                                echo "<td></td>";
                                            }
                                            echo "</tr>";
                                        }
                                echo '</tbody>
                                </form>
                            </thead>
                        </table>
                    </div>
                </fieldset>';

                } else if ($row_students['role'] == 'student'){
                    echo '<fieldset>
                    <legend> Meeting Tracking </legend>
                    <div id ="trackingTable">
                        <table>
                            <thead>
                                <tbody>
                                    <tr>
                                        <th title ="date" style="text-align:center"> Date </th>
                                        <th title ="start_time" style="text-align:center"> Start Time </th>
                                        <th title ="end_time" style="text-align:center">End Time</th>
                                        <th title ="link" style="text-align:center"> Link </th>
                                        <th></th>
                                        <th title="status" style="text-align:center">Status</th>
                                        <th title="status" style="text-align:center">Meeting Log</th>
                                    </tr>
                                </tbody>
                            </thead>
                            <thead>
                                <tbody>
                                    <form action="" method="POST">';
                                        while($row = $resultsss->fetch_assoc()) {
                                            echo "<tr>";
                                            echo "<td style='text-align:center'>".$row['date']."</td>";
                                            echo "<td style='text-align:center'>".$row['start_time']."</td>";
                                            echo "<td style='text-align:center'>".$row['end_time']."</td>";
                                            echo "<td style='text-align:center'><a href=".$row['link'].">".$row['link']."</a></td>";
                                            if ($row['status'] == 'Accept'){
                                                echo "<td><input type='hidden' name='date' value='".$row['date']."' /></td>";
                                                echo "<td style='text-align:center'>".$row['status']."</td>";
                                            } else if ($row['status'] == 'Complete') {
                                                echo "<td><input type='hidden' name='date' value='".$row['date']."' /></td>";
                                                echo "<td style='text-align:center'>".$row['status']."</td>";
                                            } else {
                                                echo "<td><input type='hidden' name='date' value='".$row['date']."' /></td>";
                                                echo "<td style='text-align:center'><input type='submit' name='submits' value='Accept?' /></td>";
                                            }

                                            if ($row['status'] == 'Complete') {
                                                echo "<td style='text-align:center'><a href='meeting_log.php?id=".$row['id']."'><button type='button'>Meeting Log</button></a></td>";
                                            } else {
                                                echo "";
                                            }
                                            echo "</tr>";
                                        }
                                    echo '</form>
                                </tbody>
                            </thead>
                        </table>
                    </div>
                </fieldset>';
                }
            ?>
            <?php
                if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['done'])) {
                    $status = trim('Complete');
                    $name = trim($_SESSION['name']);
                    $date = trim($_POST['dates']);

                    echo "<script>console.log('".$date."')</script>";

                    if($query = $con->prepare("SELECT * FROM meeting WHERE supervisor_name = ?")) {
                        $error = '';

                        $query->bind_param('s', $name);
                        $query->execute();
                        $query->store_result();


                        $error = '';
                        if(empty($error)){
                            $sql = $con->prepare("UPDATE meeting SET status=? WHERE supervisor_name=? and date=?;");
                            $sql->bind_param("sss", $status, $name, $date);
                            $result = $sql->execute();
                            if ($result) {
                                $error .= "<p class='success'>Successful Update!</p>";
                            } else {
                                $error .= "<p class='error'>Not Successful Update!</p>";
                            }
                        }
                    }
                    // $row = mysqli_fetch_array($result);
                    
                    $query->close();
                    $sql->close();
                    echo "<meta http-equiv='refresh' content='0'>";
                }

                if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submits'])) {
                    $status = trim('Accept');
                    $name = trim($_SESSION['name']);
                    $id = trim($_SESSION['id']);
                    $date = trim($_POST['date']);

                    echo "<script>console.log('".$date."')</script>";

                    if($query = $con->prepare("SELECT * FROM meeting WHERE student_name = ?")) {
                        $error = '';

                        $query->bind_param('s', $name);
                        $query->execute();
                        $query->store_result();


                        $error = '';
                        if(empty($error)){
                            $sql = $con->prepare("UPDATE meeting SET status=? WHERE student_name=? and date=?;");
                            $sql->bind_param("sss", $status, $name, $date);
                            $result = $sql->execute();
                            if ($result) {
                                $error .= "<p class='success'>Successful Update!</p>";
                            } else {
                                $error .= "<p class='error'>Not Successful Update!</p>";
                            }
                        }
                    }
                    // $row = mysqli_fetch_array($result);
                    $query->close();
                    $sql->close();
                    mysqli_close($con);
                    echo "<meta http-equiv='refresh' content='0'>";

                }
            ?>
        </div>
    </body>
</html>