<?php
	include "config.php";
	// Check user login or not
	if(!isset($_SESSION['email'])){
		header('Location: login.php');
	}

    $get = 'SELECT * FROM student WHERE student_name="'.$_SESSION['name'].'"';
    $result = mysqli_query($con,$get);

    $student_name = 'SELECT * FROM assign_project WHERE supervisor_name="'.$_SESSION['name'].'"';
    $result_student_name = mysqli_query($con,$student_name);

    $student_grade = 'SELECT * FROM result WHERE student_name="'.$_SESSION['name'].'"';
    $result_grade = mysqli_query($con,$student_grade);
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Result</title>
        <link rel="stylesheet"  href ="css/menu.css"/>
	    <script src="css/menu.js"></script>
		<style>
		body {
		  background-image: url('background.jpg');
		  background-repeat: no-repeat;
          background-size: cover;
		}
		</style>
		<link rel="stylesheet" href="css/result.css" />
    </head>
	<header>
		<h1><img src="images/MMUnewLogo.png" alt="MMU" width = "270" height = "70"/></h1>
		<hr>
		<h2> Result </h2>
		<hr>
	</header>
    <body>
        <div id="mySidenav" class="sidenav">
            <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
            <a href="homepage.php"><?php echo $_SESSION['name'] ?></a>
            <br/>
            <a href="homepage.php">Home</a>
            <?php
            $auth = "SELECT * FROM student WHERE student_name='".$_SESSION['name']."';";
            $_auth = mysqli_query($con, $auth);

            $register = "SELECT * FROM assign_project;";
            $registered = mysqli_query($con, $register);
			$emptyArray = array();
			$emptyArray2 = array();
			
			$trackresult = "SELECT * FROM result WHERE student_name='".$_SESSION['name']."';";
			$registered2 = mysqli_query($con, $trackresult);
			
			
            while($_registered = mysqli_fetch_array($registered)){
				
                $emptyArray[] = $_registered['student_name'];
				
            }
			
			while ($_registered2 = mysqli_fetch_array($registered2) ) {
				
				$emptyArray2[] = $_registered2['student_name'];
			}
			
			

            while($_auth_ = $_auth->fetch_assoc()){
                if($_auth_['role'] == 'student') {
                    if(!in_array($_SESSION['name'],$emptyArray)){
                        echo "<a href='myFYP.php' class='isDisabled'>My FYP</a>";
                        echo "<a href='planning.php' class='isDisabled'>Planning</a>";
                        echo "<a href='meeting.php' class='isDisabled'>Meeting</a>";
                        echo "<a href='tracking.php' class='isDisabled'>Progress Tracking</a>";
                        echo "<a href='result.php' class='isDisabled'>Result</a>";
                    } else {
                        echo "<a href='myFYP.php'>My FYP</a>";
                        echo "<a href='planning.php'>Planning</a>";
                        echo "<a href='meeting.php'>Meeting</a>";
                        echo "<a href='tracking.php'>Progress Tracking</a>";
						if( !in_array($_SESSION['name'],$emptyArray2) ){
							echo "<a href='result.php' class ='isDisabled'>Result</a>";
						} else {
								echo "<a href='result.php'>Result</a>";
						}
				
					} 

                } 
                if($_auth_['role'] == 'supervisor'){
                    echo "<a href='proposal.php'>Proposal</a>";
                    echo "<a href='list.php'>List of Proposal</a>";
                    echo "<a href='proposal_view.php'>Proposal Status</a>";
                    echo "<a href='project.php'>Project Assignment</a>";
                    echo "<a href='meeting.php'>Meeting</a>";
                    echo "<a href='result.php'>Marksheet</a>";
                }
            }
        ?>

        <?php
            $gets = "SELECT * FROM student WHERE student_name='".$_SESSION['name']."';";
            $results = mysqli_query($con, $gets);

            while($row = $results->fetch_assoc()){
                if($row['role'] == 'admin') {
                    echo "<a href='admin_approval.php'>For Admin only</a>";
                } else {
                    echo "";
                }
            }
        ?>
        
        <a href='logout.php'>Logout</a>
        </div>
    
        <span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; Menu</span>
        <div id="result" class="result">
        <?php 
        $row = $result->fetch_assoc();
            if ($row['role'] == 'student'){
                while($grading = $result_grade->fetch_assoc()){
                    echo "<fieldset>";
                    echo "<legend> Your Result ( Student ) </legend>";
                    echo '<div id="titlebox">';
                    echo '<p><caption>FYP 1 : <caption></P>';
                    echo '<p><input type="text" id="fyp1" name="fyp1"  size="10" value="'.$grading['fyp1'].'" disabled>';
                    echo '</p>';
                    
                    echo '<p><caption>FYP 2 : <caption></P>';
                    echo '<p><input type="text" id="fyp2" name="fyp2"  size="10" value="'.$grading['fyp2'].'" disabled>';
                    echo '</p>';
                    
                    echo '<p><caption>Grade : <caption></p>';
                    echo '<p><input type="text" id="Grade" name="Grade" size="10" value="'.$grading['grade'].'" disabled>';
                    echo '</p>';
                    echo '</div>';
                    echo '</fieldset>';
                }

            } else if ($row['role'] == 'supervisor'){
                echo '<form action="" method="POST">';
                echo '<fieldset>
                <legend> Result (Supervisor) </legend>
                <div id="titlebox">
                <table>
                    <tr>
                        <td>
                            <label>Student name : </label>
                        </td>
                        <td>
                            <select name="student">';
                            while ($get_name = $result_student_name->fetch_assoc()){
                                echo '<option>'.$get_name['student_name'].'</option>';
                            }
                            echo '</select>
                        </td>
                    </tr>
                        <td>
                            <label>FYP 1 : </label> 
                        </td>
                        <td>
                            <input type="text" id="fyp1" name="fyp1" placeholder="marks" min="0" max="50"> <label>/ 50 </label>				
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <label>FYP 2: </label> 
                        </td>
                        <td>
                            <input type="text" id="fyp2" name="fyp2" placeholder="marks" min="0" max="50"> <label>/ 50 </label>				
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <label>Select Grade : </label>
                        </td>
                        <td>
                            <select name="grade">
                            <option>Grade</option>
                            <option>A+</option>
                            <option>A</option>
                            <option>A-</option>
                            <option>B+</option>
                            <option>B</option>
                            <option>B-</option>
                            <option>C+</option>
                            <option>C</option>
                            <option>Failed</option>
                            </select>
                        </td>
                    </tr>
                </table>
                
                <p>
                    <input type="submit" name="submits" value="Submit">
                </p>
                </fieldset>';
                echo '</form>';
            }
            
            if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submits'])){
                $name = trim($_POST['student']);
                $fyp1 = trim($_POST['fyp1']);
                $fyp2 = trim($_POST['fyp2']);
                $grade = trim($_POST['grade']);
                
                $query = $con->prepare('INSERT INTO result (student_name, fyp1, fyp2, grade) VALUES (?,?,?,?)');
                $query->bind_param('ssss', $name, $fyp1, $fyp2, $grade );
                $query->execute();

                $query->close();
                mysqli_close($con);
            }
        ?>
        </div>
    </body>
</html>