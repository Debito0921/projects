<?php
    require_once "config.php";
    // require_once "session.php";

   

    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit'])) { 
		
        $name = trim($_POST['name']);
        $id = trim($_POST['id']);
        $password = trim($_POST['password']);
        $email = trim($_POST['email']);
		$role = trim($_POST['role']);

        if($query = $con->prepare("SELECT * FROM student WHERE student_email = ?")) {
            $error = '';

            $query->bind_param('s', $email);
            $query->execute();
            $query->store_result();

            if ($query->num_rows > 0) {
                $error .= "The email has already registered!";
            } else {
                if (strlen($password) < 6){
                    $error .= "Password must have at least 6 characters";
                }

                if(empty($error)){
                    $sql = $con->prepare("INSERT INTO student (student_name, student_id, student_password, student_email, role) VALUES (?,?,?,?,?);");
                    $sql->bind_param("sssss", $name, $id, $password, $email, $role);
                    $result = $sql->execute();
                    if ($result) {
                        $error .= "Successful Registered!";
                    } else {
                        $error .= "Not Successful Registered!";
                    }
					$sql->close();
                }
            }

        }
		echo "<script>alert('$error')</script>";
        $query->close();
        mysqli_close($con);
    }
?>
<!DOCTYPE html>
<html>
    <head>
        <!-- input script -->
        <meta charset="UTF-8">
		<link rel="stylesheet" href="css/register.css" />
		
      
    </head>
    <body>
        <main>
		<img src="./images/mmulogo.png" alt="MMU Logo" />
            <div class="container-fluid">
                <form action="" method="POST">
				<fieldset>
					<table>
						<tr class="selectRole">
							<td>
								<label>Role:</label>
							</td>
							<td>
								<input type="radio" name="role" value="student" required/>Student
							</td>
							<td>
								<input type="radio" name="role" value="supervisor" />Supervisor
							</td>
						</tr>
						
						<tr>
							<div class="form-group">
							<td>
								<label>Name : </label>
							</td>
							<td>
								<input type="text" class="form-control" name="name" id="name" value="" required />
							</td>
							</div>
						</tr>
						
						<tr>
							<div class="form-group">
							<td>
								<label>ID : </label>
							</td>
							<td>
								<input type="text" class="form-control" name="id" id="id" value="" required />
							</td>
							</div>
						</tr>
							
						<tr>
							<div class="form-group">
							<td>
								<label>Password : </label>
							</td>
							<td>
								<input type="password"class="form-control" name="password" id="password" value="" required />
							</td>
							</div>
						</tr>
							
						<tr>
							<div class="form-group">
							<td>
								<label>Email : </label>
							</td>
							<td>
								<input type="email" class="form-control" name="email" id="email" value="" required />
							</td>
							</div>
						</tr>
						</table>
							<p style = "text-align : right" >
							<div class="form-group">
							
								<input type="submit" name="submit" class="btn btn-primary btn-lg" value="Submit" />
							</div>
							</p>
							
							<p>Already have an account? <a href="login.php">Login here</a></p>
							
					</fieldset>
				</form>	
            </div>
        </main>
    </body>
</html>


