<?php
	include "config.php";
	// Check user login or not
	if(!isset($_SESSION['email'])){
		header('Location: login.php');
	}

	if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit'])) {
        $name = trim($_SESSION['name']);
        $id = trim($_SESSION['id']);
		$goal = trim($_POST['goalName']);
		$date_created = trim($_POST['date']);
		$progress = trim("None");
		$status = trim("None");

		if($query = $con->prepare("SELECT * FROM tracking WHERE student_name = ?")) {
            $error = '';

            $query->bind_param('s', $name);
            $query->execute();
            $query->store_result();


			$error = '';
			if(empty($error)){
				$sql = $con->prepare("INSERT INTO tracking (student_name, student_id, goal, date_created, progress, status) VALUES (?,?,?,?,?,?);");
				$sql->bind_param("ssssss", $name, $id, $goal, $date_created, $progress, $status);
				$result = $sql->execute();
				if ($result) {
					$error .= "<p class='success'>Successful Added!</p>";
				} else {
					$error .= "<p class='error'>Not Successful Added!</p>";
				}
			}
		}
		// $row = mysqli_fetch_array($result);
		
		$query->close();
		$sql->close();
		mysqli_close($con);

		header('Location: tracking.php');
	}
	
	$get = "SELECT * FROM tracking WHERE student_name='".$_SESSION['name']."' and student_id='".$_SESSION['id']."'";
	$result = mysqli_query($con,$get);
?>

<!DOCTYPE html>
<html>
    <head>
        <title>Progress tracking</title>
        <link rel="stylesheet"  href ="css/menu.css"/>
		<!-- <link rel="stylesheet" href="css/tracking.css" /> -->
	    <script src="css/menu.js"></script>
		<!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script> -->
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
		<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
		<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>

		<style>	
			body {
			  background-image: url('background.jpg');
			  background-repeat: no-repeat;
			  background-size: cover;
			}
			.goal fieldset {
			margin: 1em auto;
			background-color: #E3E4FA;
			width: 85%;
			}

			.goal legend {
			background-color: #CCCCFF;
			color: #454545;
			margin: 0 auto;
			width: 90%;
			padding: 0.5em;
			text-align: center;
			font-weight: bold;
			font-size: 28px;
			}
			.goal captions {
				padding: 1.5em 1.5em; 
				font-weight: bold;
				font-size: 26px;
			}

			div#titlebox {    
				margin-top: 1em; 
				margin-left: 5em;
			}

			.goal input[type=text] {
				font-size: 15px;
				width: 650px;   
			}

			.goal label {
				font-size : 18px;
			}

			/* .goal input[type=submit] {
				font-size : 18px;
				margin : 1em 1em 1em 1em;
			} */

			input[type=submit] {
				font-size : 18px;
				margin : 1em 1em 1em 1em;
			}



			/* table formatting */
			table{
				margin:0.7em auto;
				width:90%;
				color: #666;
				font-size:1.15em;
			}

			tr {
				padding:0.75rem;
			}

			td,th {
				padding:0.75rem;
				text-align: left;
				
			}

			th {
				font-size:1.2em;
			}
			.isDisabled {
                color: currentColor;
                cursor: not-allowed;
                opacity: 0.5;
                text-decoration: none;
                pointer-events: none;
            }
		</style>
		<script>
			$(document).on("click", ".open-AddBookDialog", function () {
				$('.testing').empty()
				var pdfid = $(this).data('id');
				console.log(pdfid);
				$('.testing').val(pdfid);
			});
		</script>
    </head>
    <body  id="bootstrap-overrides">
	<header>
		<h1><img src="images/MMUnewLogo.png" alt="MMU" width = "270" height = "70"/></h1>
		<hr>
		<h2> Goal Setting / Progress Tracking </h2>
		<hr>
	</header>
		<div id="mySidenav" class="sidenav">
            <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
			<a href="homepage.php"><?php echo $_SESSION['name'] ?></a>
        <br/>
		<a href="homepage.php">Home</a>
        <?php
            $auth = "SELECT * FROM student WHERE student_name='".$_SESSION['name']."';";
            $_auth = mysqli_query($con, $auth);

            $register = "SELECT * FROM assign_project;";
            $registered = mysqli_query($con, $register);
			$emptyArray = array();
			$emptyArray2 = array();
			
			$trackresult = "SELECT * FROM result WHERE student_name='".$_SESSION['name']."';";
			$registered2 = mysqli_query($con, $trackresult);
			
			
            while($_registered = mysqli_fetch_array($registered)){
				
                $emptyArray[] = $_registered['student_name'];
				
            }
			
			while ($_registered2 = mysqli_fetch_array($registered2) ) {
				
				$emptyArray2[] = $_registered2['student_name'];
			}
			
			

            while($_auth_ = $_auth->fetch_assoc()){
                if($_auth_['role'] == 'student') {
                    if(!in_array($_SESSION['name'],$emptyArray)){
                        echo "<a href='myFYP.php' class='isDisabled'>My FYP</a>";
                        echo "<a href='planning.php' class='isDisabled'>Planning</a>";
                        echo "<a href='meeting.php' class='isDisabled'>Meeting</a>";
                        echo "<a href='tracking.php' class='isDisabled'>Progress Tracking</a>";
                        echo "<a href='result.php' class='isDisabled'>Result</a>";
                    } else {
                        echo "<a href='myFYP.php'>My FYP</a>";
                        echo "<a href='planning.php'>Planning</a>";
                        echo "<a href='meeting.php'>Meeting</a>";
                        echo "<a href='tracking.php'>Progress Tracking</a>";
						if( !in_array($_SESSION['name'],$emptyArray2) ){
							echo "<a href='result.php' class ='isDisabled'>Result</a>";
						} else {
								echo "<a href='result.php'>Result</a>";
						}
				
					} 

                } 
                if($_auth_['role'] == 'supervisor'){
                    echo "<a href='proposal.php'>Proposal</a>";
                    echo "<a href='list.php'>List of Proposal</a>";
                    echo "<a href='proposal_view.php'>Proposal Status</a>";
                    echo "<a href='project.php'>Project Assignment</a>";
                    echo "<a href='meeting.php'>Meeting</a>";
                    echo "<a href='result.php'>Marksheet</a>";
                }
            }
        ?>

        <?php
            $gets = "SELECT * FROM student WHERE student_name='".$_SESSION['name']."';";
            $results = mysqli_query($con, $gets);

            while($row = $results->fetch_assoc()){
                if($row['role'] == 'admin') {
                    echo "<a href='admin_approval.php'>For Admin only</a>";
                } else {
                    echo "";
                }
            }
        ?>
        
        <a href='logout.php'>Logout</a>
        </div>
    
        <span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; Menu</span>
		
		<div id="goalSetting" class="goal">
			<fieldset>
			
				<legend> Goal Setting </legend>
				<div id="titlebox">
				<form action="" method="POST">
					<p>
					<label for="goalName">Please enter your goal here :</label>
					<input type="text" id="goalName" name="goalName" placeholder="Enter your goal here" size="200" required>
					</p>
					<p>
						<label for="goalDate"> Enter the starting date : </label> 
						<input type="date" name="date" required/>
					</p>
					<p>
						<input type="submit" name="submit" value="Submit">
					</p>
				</form>
				</div>
			</fieldset>
	
			<fieldset>
				<legend> Progress Tracking </legend>
				<div id ="trackingTable">
					<table>
						<thead>
							<tbody>
								<tr>
									<th title ="Goal"> Goal </th>
									<th title ="Date"> Date Created </th>
									<th title ="Progress"> Progress </th>
									<th title ="Status"> Status </th>
									<th title ="update"></th>
									<th title ="marking"></th>
								</tr>
							</tbody>
						</thead>
						<thead>
							<tbody>
								<?php 
									while($row = $result->fetch_assoc()) {
										echo "<tr>";
										echo "<td>".$row['goal']."</td>";
										echo "<td>".$row['date_created']."</td>";
										echo "<td><progress max=100 value=".$row['progress']."></progress></td>";
										echo "<td>".$row['status']."</td>";
										// echo '<td><button type="button" href="#myModal" data-id="'.$row['id'].'" data-target="#my-modal" class="open-AddBookDialog" data-bs-toggle="modal">Update Progress</button>';
										if ($row['status'] == 'Completed'){
											echo '<td></td>';
										} else {
											echo '<td><button href="#" class="open-AddBookDialog" data-id="'.$row['id'].'" data-toggle="modal" data-target="#my-modal">Update</button></td>';
										}
										echo "</tr>";
									}
								?>
							</tbody>
						</thead>
					</table>
				</div>
			</fieldset>
			<div class="modal fade" id="my-modal" tabindex="-1" role="dialog" aria-labelledby="my-modal" aria-hidden="true">
				<div class="modal-dialog" role="document">
					<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title" id="exampleModalLabel">My Modal</h5>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
						</button>
					</div>
					<div class="modal-body">
						<!-- <div class="testing"></div> -->
						<form action="" method="POST">
							<input type="text" class="testing" name="uid" hidden />
							<input type="number" name="progress" size="10" min=0 max=100 step=10 required/>
							<input type="submit" name="submits" value="Submit" />
						</form>

						<?php
							if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submits'])) {
								$name = trim($_SESSION['name']);
								$id = trim($_SESSION['id']);
								$progress = trim($_POST['progress']);
								$uid = trim($_POST['uid']);
								$status_ongoing = trim("Ongoing");
								$status_completed = trim("Completed");

								if($query = $con->prepare("SELECT * FROM tracking WHERE student_name = ?")) {
									$error = '';
						
									$query->bind_param('s', $name);
									$query->execute();
									$query->store_result();

									$progress = (int)$progress; 
															
									$error = '';
									if($progress < 100 && $progress != null ){
										$sql = $con->prepare("UPDATE tracking SET progress=?, status=? WHERE student_name=? and student_id=? and id=?");
										$sql->bind_param("sssss", $progress, $status_ongoing, $name, $id, $uid);
										$result = $sql->execute();
										if ($result) {
											$error .= "<p class='success'>Successful Update!</p>";
										} else {
											$error .= "<p class='error'>Not Successful Update!</p>";
										}
									}
									else if($progress == null){
										
									}
									else {
										$sql = $con->prepare("UPDATE tracking SET progress=?, status=? WHERE student_name=? and student_id=? and id=?");
										$sql->bind_param("sssss", $progress, $status_completed, $name, $id, $uid);
										$result = $sql->execute();
										if ($result) {
											$error .= "<p class='success'>Successful Update!</p>";
										} else {
											$error .= "<p class='error'>Not Successful Update!</p>";
										}
									}
								}
								
								$query->close();
								mysqli_close($con);
								echo "<meta http-equiv='refresh' content='0'>";	
							}
						?>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
					</div>
					</div>
				</div>
			</div>
		</div>
    </body>
</html>