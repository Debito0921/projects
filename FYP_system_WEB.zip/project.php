<?php 
    include "config.php";

    // Check user login or not
    if(!isset($_SESSION['email'])){
        header('Location: login.php');
    }

    $get = "SELECT * FROM proposal WHERE proposal_status='Approve' and supervisor_name='".$_SESSION['name']."';";
    $result = mysqli_query($con, $get);

?>

<!DOCTYPE html charset="UTF-8">
<html>
<head>
    <title>Proposal Status</title>
    <link rel="stylesheet" href="css/menu.css" />
    <script src="css/menu.js"></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>

    <script>
        $(document).on("click", ".open-AddBookDialog", function () {
            $('.testing').empty()
            var pdfid = $(this).data('id');
            console.log(pdfid);
            $('.testing').val(pdfid);
        });
    </script>
</head>
<style>
	body {
		  background-image: url('background.jpg');
		  background-repeat: no-repeat;
		  background-size: cover;
	}
    fieldset {
        margin: 1em auto;
        background-color: #E3E4FA;
        width: 85%;
    }

    legend {
        background-color: #CCCCFF;
        color: #454545;
        margin: 0 auto;
        width: 90%;
        padding: 0.5em;
        text-align: center;
        font-weight: bold;
        font-size: 28px;
    }
    table{
        margin:0.7em auto;
        width:90%;
        color: #666;
        font-size:1.15em;
        border-collapse: separate;
    }

    tr.border_bottom td{
        padding:0.75rem;
        
        border-bottom: 1pt solid black;
    }

    td {
        padding:0.75rem;
        text-align: left;
        
    }

    th {
        text-align: center;
        font-size:1.2em;
        border-bottom: 1pt solid black;
    }
    td.status {
        text-align: center;
        border-left: 1.2pt solid gray;
    }
</style>
<body>
	<header>
		<h1><img src="images/MMUnewLogo.png" alt="MMU" width = "270" height = "70"/></h1>
		<hr>
		<h2> Project Assignment </h2>
		<hr>
	</header>
    <div id="mySidenav" class="sidenav">
        <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
        <a href="homepage.php"><?php echo $_SESSION['name'] ?></a>
        <br/>
        <a href="homepage.php">Home</a>
        <?php
            $auth = "SELECT * FROM student WHERE student_name='".$_SESSION['name']."';";
            $_auth = mysqli_query($con, $auth);

            $register = "SELECT * FROM assign_project;";
            $registered = mysqli_query($con, $register);
			$emptyArray = array();
			$emptyArray2 = array();
			
			$trackresult = "SELECT * FROM result WHERE student_name='".$_SESSION['name']."';";
			$registered2 = mysqli_query($con, $trackresult);
			
			
            while($_registered = mysqli_fetch_array($registered)){
				
                $emptyArray[] = $_registered['student_name'];
				
            }
			
			while ($_registered2 = mysqli_fetch_array($registered2) ) {
				
				$emptyArray2[] = $_registered2['student_name'];
			}
			
			

            while($_auth_ = $_auth->fetch_assoc()){
                if($_auth_['role'] == 'student') {
                    if(!in_array($_SESSION['name'],$emptyArray)){
                        echo "<a href='myFYP.php' class='isDisabled'>My FYP</a>";
                        echo "<a href='planning.php' class='isDisabled'>Planning</a>";
                        echo "<a href='meeting.php' class='isDisabled'>Meeting</a>";
                        echo "<a href='tracking.php' class='isDisabled'>Progress Tracking</a>";
                        echo "<a href='result.php' class='isDisabled'>Result</a>";
                    } else {
                        echo "<a href='myFYP.php'>My FYP</a>";
                        echo "<a href='planning.php'>Planning</a>";
                        echo "<a href='meeting.php'>Meeting</a>";
                        echo "<a href='tracking.php'>Progress Tracking</a>";
						if( !in_array($_SESSION['name'],$emptyArray2) ){
							echo "<a href='result.php' class ='isDisabled'>Result</a>";
						} else {
								echo "<a href='result.php'>Result</a>";
						}
				
					} 

                } 
                if($_auth_['role'] == 'supervisor'){
                    echo "<a href='proposal.php'>Proposal</a>";
                    echo "<a href='list.php'>List of Proposal</a>";
                    echo "<a href='proposal_view.php'>Proposal Status</a>";
                    echo "<a href='project.php'>Project Assignment</a>";
                    echo "<a href='meeting.php'>Meeting</a>";
                    echo "<a href='result.php'>Marksheet</a>";
                }
            }
        ?>

        <?php
            $gets = "SELECT * FROM student WHERE student_name='".$_SESSION['name']."';";
            $results = mysqli_query($con, $gets);

            while($row = $results->fetch_assoc()){
                if($row['role'] == 'admin') {
                    echo "<a href='admin_approval.php'>For Admin only</a>";
                } else {
                    echo "";
                }
            }
        ?>
        
        <a href='logout.php'>Logout</a>
    </div>
    <span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; Menu</span>

    <fieldset>
        <legend>Assign My Topic</legend>
        <div id="proposal-table" class="goal">
            <table>
                <thead>
                    <tbody>
                        <tr class="border_bottom">
                            <th title="Title">Project Title</th>
                            <th title="Assign">Assign to: </th>
                        </tr>
                    </tbody>
                </thead>
                <thead>
                    <tbody>
                        <?php 
                            $get_title = "SELECT * FROM assign_project;"; 
                            $get_title = mysqli_query($con, $get_title);
                            $columnValues = array();
                            while ($get_titles = mysqli_fetch_array($get_title)){
                                $columnValues[] = $get_titles['project_title'];
                            }
                            
                            while($lets = $get_title->fetch_assoc()) {
                                $names = $lets['student_name'];
                                echo $names;
                            }
                            
                            while($row = $result->fetch_assoc()) {
                                $get_row = "SELECT * FROM assign_project WHERE supervisor_name='".$_SESSION['name']."' and project_title='".$row['proposal_title']."'";
                                $result2 = mysqli_query($con, $get_row);
								while ($row3 = $result2->fetch_assoc()){
									$studentProjectRow = $row3["student_name"];
								}

                                echo "<tr class='border_bottom'>";
                                echo "<td class='status'>".$row['proposal_title']."</td>";

                                    if (mysqli_num_rows($result2) && in_array($row['proposal_title'], $columnValues)){
                                            echo "<td class='status'>".$studentProjectRow."</td>";
                                    } else {
                                        echo "<td class='status'><a href='#' class='open-AddBookDialog' data-id='".$row['proposal_title']."' data-toggle='modal' data-target='#my-modal'>Assign this topic</a></td>";
                                    }
                                echo "</tr>";
                            }
                        ?>
                    </tbody>
                </thead>
            </table>
            <div class="modal fade" id="my-modal" tabindex="-1" role="dialog" aria-labelledby="my-modal" aria-hidden="true">
				<div class="modal-dialog" role="document">
					<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title" id="exampleModalLabel">Assign this topic to: </h5>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
						</button>
					</div>
					<div class="modal-body">
						<!-- <div class="testing"></div> -->
						<form action="" method="POST">
							<input type="text" class="testing" name="title" hidden />
                            <?php 
                                $assign = 'SELECT * FROM student WHERE role="student";';
                                $list_student = mysqli_query($con, $assign);

                                echo '<select name="assign">';
                                    while ($students = $list_student->fetch_assoc()){
                                        echo "<option value='".$students['student_name']."'>".$students['student_name']."</option>";
                                    }
                                echo '</select>';
                            ?>
                            <div> 
                                <br/>
							    <input type="submit" name="submits" value="Submit" />
                                
                            </div>
						</form>
                        
                        <?php
                            if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submits'])){
                                $assign_student = trim($_POST['assign']);
                                $supervisor = trim($_SESSION['name']);
                                $title = trim($_POST['title']);

                                $query = $con->prepare('INSERT INTO assign_project (student_name, supervisor_name, project_title) VALUES (?, ?, ?)');
                                $query->bind_param('sss', $assign_student, $supervisor, $title);
                                $_query = $query->execute();
                                
                                $error = '';
                                if ($_query) {
                                    $error .= "<p class='success'>Successful Assign!</p>";
                                } else {
                                    $error .= "<p class='error'>Not Successful Assign!</p>";
                                }

                                $query->close();
                                mysqli_close($con);
                                echo "<meta http-equiv='refresh' content='0'>";
                            }
                        ?>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
					</div>
					</div>
				</div>
			</div>
        </div>
    </fieldset>
</body>
</html>