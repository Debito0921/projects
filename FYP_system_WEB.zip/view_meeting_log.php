<?php
	include "config.php";
	// Check user login or not
	if(!isset($_SESSION['email'])){
		header('Location: login.php');
	}

    $date = "SELECT * FROM meeting WHERE id='".$_GET['id']."'";
    $get_date = mysqli_query($con, $date);

    while ($get_log = $get_date->fetch_assoc()){
        $date2 = "SELECT * FROM meeting_log WHERE meeting_date='".$get_log['date']."' and student_name='".$get_log['student_name']."'";
        $get_date2 = mysqli_query($con, $date2);
    }


    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit'])) {
        $student_name = trim($_POST['student_name']);
        $meeting_date = trim($_POST['date']);
        $comments = trim($_POST['comments']);

		$error = '';
		
        if ($query = $con->prepare("SELECT * FROM meeting_log WHERE student_name = ? AND meeting_date=?;")) {
            $query->bind_param('ss', $student_name, $meeting_date);
            $query->execute();
            $query->store_result();
            	
            if(empty($error)) {
                $sql = $con->prepare("UPDATE meeting_log SET comments=? WHERE student_name=? and meeting_date=?");
                $sql->bind_param("sss", $comments, $student_name, $meeting_date);
                $result = $sql->execute();
                if($result) {
                    $error .= "Meeting Log Successfully Update!";
                    header("Location: meeting.php");
                }
                else {
                    $error .= "Something wrong when inserting record!";
                }
                $sql->close();
            }
        }
        $query->close();	
	}

?>

<!DOCTYPE html>
<html>
    <head>
        <title>Proposal</title>
        <link rel="stylesheet"  href ="css/menu.css" />
		<link rel="stylesheet" href="css/proposal.css" />
		<script src="css/menu.js"></script>
    </head>
    <body>
	<header>
		<h1><img src="images/MMUnewLogo.png" alt="MMU" width = "270" height = "70"/></h1>
		<hr>
		<h2> Meeting Log </h2>
		<hr>
	</header>
        <div id="mySidenav" class="sidenav">
            <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
			<a href="homepage.php"><?php echo $_SESSION['name'] ?></a>
        <br/>
		<a href="homepage.php">Home</a>
        <?php
            $auth = "SELECT * FROM student WHERE student_name='".$_SESSION['name']."';";
            $_auth = mysqli_query($con, $auth);

            $register = "SELECT * FROM assign_project;";
            $registered = mysqli_query($con, $register);
			$emptyArray = array();
			$emptyArray2 = array();
			
			$trackresult = "SELECT * FROM result WHERE student_name='".$_SESSION['name']."';";
			$registered2 = mysqli_query($con, $trackresult);
			
			
            while($_registered = mysqli_fetch_array($registered)){
				
                $emptyArray[] = $_registered['student_name'];
				
            }
			
			while ($_registered2 = mysqli_fetch_array($registered2) ) {
				
				$emptyArray2[] = $_registered2['student_name'];
			}
			
			

            while($_auth_ = $_auth->fetch_assoc()){
                if($_auth_['role'] == 'student') {
                    if(!in_array($_SESSION['name'],$emptyArray)){
                        echo "<a href='myFYP.php' class='isDisabled'>My FYP</a>";
                        echo "<a href='planning.php' class='isDisabled'>Planning</a>";
                        echo "<a href='meeting.php' class='isDisabled'>Meeting</a>";
                        echo "<a href='tracking.php' class='isDisabled'>Progress Tracking</a>";
                        echo "<a href='result.php' class='isDisabled'>Result</a>";
                    } else {
                        echo "<a href='myFYP.php'>My FYP</a>";
                        echo "<a href='planning.php'>Planning</a>";
                        echo "<a href='meeting.php'>Meeting</a>";
                        echo "<a href='tracking.php'>Progress Tracking</a>";
						if( !in_array($_SESSION['name'],$emptyArray2) ){
							echo "<a href='result.php' class ='isDisabled'>Result</a>";
						} else {
								echo "<a href='result.php'>Result</a>";
						}
				
					} 

                } 
                if($_auth_['role'] == 'supervisor'){
                    echo "<a href='proposal.php'>Proposal</a>";
                    echo "<a href='list.php'>List of Proposal</a>";
                    echo "<a href='proposal_view.php'>Proposal Status</a>";
                    echo "<a href='project.php'>Project Assignment</a>";
                    echo "<a href='meeting.php'>Meeting</a>";
                    echo "<a href='result.php'>Marksheet</a>";
                }
            }
        ?>

        <?php
            $gets = "SELECT * FROM student WHERE student_name='".$_SESSION['name']."';";
            $results = mysqli_query($con, $gets);

            while($row = $results->fetch_assoc()){
                if($row['role'] == 'admin') {
                    echo "<a href='admin_approval.php'>For Admin only</a>";
                } else {
                    echo "";
                }
            }
        ?>
        
        <a href='logout.php'>Logout</a>
        </div>
        <span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; Menu</span>
		
		<div id="proposal" class="proposal">
			<fieldset>
			<legend> Meeting Log </legend>
			<div id="titlebox">
				<form method="POST" action="">
                    <?php
                    $get_meeting = "SELECT * FROM meeting WHERE id='".$_GET['id']."'";
                    $result1 = mysqli_query($con, $get_meeting);

                    $hi = "SELECT * FROM assign_project WHERE student_name='".$_SESSION['name']."'";
                    $hi1 = mysqli_query($con, $hi);

                    while($hi2 = $hi1->fetch_assoc()){
                        $hi3 = $hi2['project_title'];
                    }


                    while($row = $get_date2->fetch_assoc()){
                        echo '<p>
                        <label><b>Meeting Date: </b></label>
                        <input type="text" name="date" value="'.$row['meeting_date'].'" readonly />
                        </p>

                        <p>
                            <label><b>Project Title: </b></label>
                            <input type="text" name="project_title" value="'.$row['proposal_title'].'" readonly />
                        </p>
                        <p>
                            <label><b>Student ID: </b></label>
                            <input type="text" name="student_id" value="'.$row['student_id'].'" style="width:150px" readonly />
                            <label><b>Student Name: </b></label>
                            <input type="text" name="student_name" value="'.$row['student_name'].'" readonly />
                        </p>
                        <p>
                            <label><b>Supervisor Name: </b></label>
                            <input type="text" name="supervisor_name" value="'.$row['supervisor_name'].'" readonly />
                        </p>
                        <p>
                            <label><b>Work Done: </b></label>
                            <p><textarea style="resize:none" id="workdone" name="workdone" rows="30" cols="90" placeholder="[Please write the details of the work done, after the last meeting]" readonly>'.$row['workdone'].'</textarea>
                        </p>
                        <p>
                            <label><b>Work To Be Done: </b></label>
                            <p><textarea style="resize:none" id="worktobedone" name="worktobedone" rows="30" cols="90" placeholder="[Please write the details of the work to be done, before the next meeting]" readonly>'.$row['work_to_be_done'].'</textarea>
                        </p>
                        <p>
                            <label><b>PROBLEMS ENCOUNTERED AND SOLUTIONS: </b></label>
                            <p><textarea style="resize:none" id="problems" name="problems" rows="30" cols="90" placeholder="[Please write the details of the problems encountered, after the last meeting and provide the solutions / plan for the solutions]" readonly>'.$row['problem_encounter'].'</textarea>
                        </p>
                        <p>
                            <label><b>COMMENTS (Supervisor): </b></label>';
                            if ($row['comments'] == ""){
                                echo '<p><textarea style="resize:none" id="comments" name="comments" rows="30" cols="90" placeholder="" required></textarea>';
                            } else {
                                echo '<p><textarea style="resize:none" id="comments" name="comments" rows="30" cols="90" placeholder="" readonly>'.$row['comments'].'</textarea>';
                            }
                        echo '</p>
                        <p>
                            <input type="submit" name="submit" value="Submits" />
                        </p>';
                    }
                    ?>
				</form>
				</div>
			</fieldset>
			
		</div>
		<?php 
			if(!empty($error)) {
				echo"<script type='text/javascript'>alert('$error')</script>";
			}
		?>
    </body>
</html>

