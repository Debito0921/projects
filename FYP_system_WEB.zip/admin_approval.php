<?php 
    include "config.php";

    // Check user login or not
    if(!isset($_SESSION['email'])){
        header('Location: login.php');
    }

    $get = "SELECT * FROM proposal;";
    $result = mysqli_query($con, $get);

?>

<!DOCTYPE html charset="UTF-8">
<html>
<head>
    <title>Proposal Status</title>
    <link rel="stylesheet" href="css/menu.css" />
    <script src="css/menu.js"></script>
    <link rel="stylesheet" href="css/tracking.css" />
</head>
<style>
	body {
		  background-image: url('background.jpg');
		  background-repeat: no-repeat;
		  background-size: cover;
		}
    fieldset {
    margin: 1em auto;
    background-color: #E3E4FA;
    width: 85%;
    }

    legend {
    background-color: #CCCCFF;
    color: #454545;
    margin: 0 auto;
    width: 90%;
    padding: 0.5em;
    text-align: center;
    font-weight: bold;
    font-size: 28px;
    }
    captions {
        padding: 1.5em 1.5em; 
        font-weight: bold;
        font-size: 26px;
    }

    div#titlebox {    
        margin-top: 1em; 
        margin-left: 5em;
    }

    input[type=text] {
        font-size: 15px;
        width: 650px;   
    }

    label {
        font-size : 18px;
    }

    input[type=submit] {
        font-size : 18px;
    }



    /* table formatting */
    table{
        margin:0.7em auto;
        width:90%;
        color: #666;
        font-size:1.15em;
    }

    tr {
        padding:0.75rem;
    }

    td,th {
        padding:0.75rem;
        text-align: left;
        
    }

    th {
        font-size:1.2em;
    }
</style>
<body>
	<header>
		<h1><img src="images/MMUnewLogo.png" alt="MMU" width = "270" height = "70"/></h1>
		<hr>
		<h2> Proposal </h2>
		<hr>
	</header>
    <div id="mySidenav" class="sidenav">
        <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
        <a href="homepage.php"><?php echo $_SESSION['name'] ?></a>
        <br/>
        <a href="homepage.php">Home</a>
        <?php
            $auth = "SELECT * FROM student WHERE student_name='".$_SESSION['name']."';";
            $_auth = mysqli_query($con, $auth);

            $register = "SELECT * FROM assign_project;";
            $registered = mysqli_query($con, $register);
			$emptyArray = array();
			$emptyArray2 = array();
			
			$trackresult = "SELECT * FROM result WHERE student_name='".$_SESSION['name']."';";
			$registered2 = mysqli_query($con, $trackresult);
			
			
            while($_registered = mysqli_fetch_array($registered)){
				
                $emptyArray[] = $_registered['student_name'];
				
            }
			
			while ($_registered2 = mysqli_fetch_array($registered2) ) {
				
				$emptyArray2[] = $_registered2['student_name'];
			}
			
			

            while($_auth_ = $_auth->fetch_assoc()){
                if($_auth_['role'] == 'student') {
                    if(!in_array($_SESSION['name'],$emptyArray)){
                        echo "<a href='myFYP.php' class='isDisabled'>My FYP</a>";
                        echo "<a href='planning.php' class='isDisabled'>Planning</a>";
                        echo "<a href='meeting.php' class='isDisabled'>Meeting</a>";
                        echo "<a href='tracking.php' class='isDisabled'>Progress Tracking</a>";
                        echo "<a href='result.php' class='isDisabled'>Result</a>";
                    } else {
                        echo "<a href='myFYP.php'>My FYP</a>";
                        echo "<a href='planning.php'>Planning</a>";
                        echo "<a href='meeting.php'>Meeting</a>";
                        echo "<a href='tracking.php'>Progress Tracking</a>";
						if( !in_array($_SESSION['name'],$emptyArray2) ){
							echo "<a href='result.php' class ='isDisabled'>Result</a>";
						} else {
								echo "<a href='result.php'>Result</a>";
						}
				
					} 

                } 
                if($_auth_['role'] == 'supervisor'){
                    echo "<a href='proposal.php'>Proposal</a>";
                    echo "<a href='list.php'>List of Proposal</a>";
                    echo "<a href='proposal_view.php'>Proposal Status</a>";
                    echo "<a href='project.php'>Project Assignment</a>";
                    echo "<a href='meeting.php'>Meeting</a>";
                    echo "<a href='result.php'>Marksheet</a>";
                }
            }
        ?>

        <?php
            $gets = "SELECT * FROM student WHERE student_name='".$_SESSION['name']."';";
            $results = mysqli_query($con, $gets);

            while($row = $results->fetch_assoc()){
                if($row['role'] == 'admin') {
                    echo "<a href='admin_approval.php'>For Admin only</a>";
                } else {
                    echo "";
                }
            }
        ?>
        
        <a href='logout.php'>Logout</a>
    </div>
    <span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; Menu</span>

    <fieldset>
        <legend>Proposal Status</legend>
        <div id ="trackingTable">
        <table>
            <thead>
                <tbody>
                    <tr>
                        <th title="supervisor_name" style="text-align:center">Supervisor Name</th>
                        <th title="title" style="text-align:center">Title</th>
                        <th title="status" style="text-align:center">Status</th>
                        <th title="" style="text-align:center"></th>
                    </tr>
                </tbody>
            </thead>
            <thead>
                <form action="" method="post">
                <tbody>
                    <?php 
                        while($row = $result->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td style='text-align:center'>".$row['supervisor_name']."</td>";
                            echo "<td style='text-align:center'>".$row['proposal_title']."</td>";
                            echo "<td style='text-align:center'>".$row['proposal_status']."</td>";

                            if ($row['proposal_status'] == 'Pending Approval'){
                                echo "<td style='text-align:center'><a href='view.php?id=".$row['id']."' class='buttonize'>View</a></td>";
                            } else {
                                echo "<td style='text-align:center'><input type='submit' name='view' value='View' hidden></td>";
                            }
                            echo "</tr>";
                        }
                    ?>
                </tbody>
                </form>
            </thead>
        </table>
        </div>
    </fieldset>
</body>
</html>