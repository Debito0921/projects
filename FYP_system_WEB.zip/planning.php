<?php
	include "config.php";
	// Check user login or not
	if(!isset($_SESSION['email'])){
		header('Location: login.php');
	}

    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit'])) {
        $name = trim($_SESSION['name']);
        $id = trim($_SESSION['id']);
        $planning = trim($_POST['planning']);
        $startWeek = trim($_POST['startWeek']);
        $endWeek = trim($_POST['endWeek']);
        $status = trim('Pending');

		if($query = $con->prepare("SELECT * FROM planning WHERE student_name = ?")) {
            $error = '';

            $query->bind_param('s', $name);
            $query->execute();
            $query->store_result();


			$error = '';
			if(empty($error)){
				$sql = $con->prepare("INSERT INTO planning (student_name, student_id , planning, startWeek, endWeek, status) VALUES (?,?,?,?,?,?);");
				$sql->bind_param("ssssss", $name, $id, $planning, $startWeek, $endWeek, $status);
				$result = $sql->execute();
				if ($result) {
					$error .= "<p class='success'>Successful Added!</p>";
				} else {
					$error .= "<p class='error'>Not Successful Added!</p>";
				}
			}
		}
		// $row = mysqli_fetch_array($result);
		
		$query->close();
		$sql->close();
		mysqli_close($con);

        header('Location: planning.php');
		
	}
    $get = "SELECT * FROM planning WHERE student_name='".$_SESSION['name']."' and student_id='".$_SESSION['id']."'";
    $resultss = mysqli_query($con,$get);
?>

<!DOCTYPE html>
<html>
    <head>
        <title>Planning</title>
        <link rel="stylesheet"  href ="css/menu.css"/>
        <!-- <link rel="stylesheet"  href ="css/tracking.css"/> -->
	    <script src="css/menu.js"></script>
        <style>
			body {
			  background-image: url('background.jpg');
			  background-repeat: no-repeat;
			  background-size: cover;
			}
            .planning fieldset {
            margin: 1em auto;
            background-color: #E3E4FA;
            width: 85%;
            }

            .planning legend {
            background-color: #CCCCFF;
            color: #454545;
            margin: 0 auto;
            width: 90%;
            padding: 0.5em;
            text-align: center;
            font-weight: bold;
            font-size: 28px;
            }
            .planning captions {
                padding: 1.5em 1.5em; 
                font-weight: bold;
                font-size: 26px;
            }

            div#titlebox {    
                margin-top: 1em; 
                margin-left: 5em;
            }

            .planning input[type=text] {
                font-size: 15px;
                width: 650px;   
            }

            .planning label {
                font-size : 18px;
            }

            /* .goal input[type=submit] {
                font-size : 18px;
                margin : 1em 1em 1em 1em;
            } */

            input[type=submit] {
                font-size : 18px;
                margin : 1em 1em 1em 1em;
            }



            /* table formatting */
            table{
                margin:0.7em auto;
                width:90%;
                color: #666;
                font-size:1.15em;
            }

            tr {
                padding:0.75rem;
            }

            td,th {
                padding:0.75rem;
                text-align: left;
                
            }

            th {
                font-size:1.2em;
            }
			.isDisabled {
                color: currentColor;
                cursor: not-allowed;
                opacity: 0.5;
                text-decoration: none;
                pointer-events: none;
            }
        </style>
    </head>

    <header>
		<h1><img src="images/MMUnewLogo.png" alt="MMU" width = "270" height = "70"/></h1>
		<hr>
		<h2> Planning </h2>
		<hr>
	</header>

    <body>
        <div id="mySidenav" class="sidenav">
            <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
            <a href=""><?php echo $_SESSION['name'] ?></a>
            <br/>
            <a href="homepage.php">Home</a>
            <?php
            $auth = "SELECT * FROM student WHERE student_name='".$_SESSION['name']."';";
            $_auth = mysqli_query($con, $auth);

            $register = "SELECT * FROM assign_project;";
            $registered = mysqli_query($con, $register);
			$emptyArray = array();
			$emptyArray2 = array();
			
			$trackresult = "SELECT * FROM result WHERE student_name='".$_SESSION['name']."';";
			$registered2 = mysqli_query($con, $trackresult);
			
			
            while($_registered = mysqli_fetch_array($registered)){
				
                $emptyArray[] = $_registered['student_name'];
				
            }
			
			while ($_registered2 = mysqli_fetch_array($registered2) ) {
				
				$emptyArray2[] = $_registered2['student_name'];
			}
			
			

            while($_auth_ = $_auth->fetch_assoc()){
                if($_auth_['role'] == 'student') {
                    if(!in_array($_SESSION['name'],$emptyArray)){
                        echo "<a href='myFYP.php' class='isDisabled'>My FYP</a>";
                        echo "<a href='planning.php' class='isDisabled'>Planning</a>";
                        echo "<a href='meeting.php' class='isDisabled'>Meeting</a>";
                        echo "<a href='tracking.php' class='isDisabled'>Progress Tracking</a>";
                        echo "<a href='result.php' class='isDisabled'>Result</a>";
                    } else {
                        echo "<a href='myFYP.php'>My FYP</a>";
                        echo "<a href='planning.php'>Planning</a>";
                        echo "<a href='meeting.php'>Meeting</a>";
                        echo "<a href='tracking.php'>Progress Tracking</a>";
						if( !in_array($_SESSION['name'],$emptyArray2) ){
							echo "<a href='result.php' class ='isDisabled'>Result</a>";
						} else {
								echo "<a href='result.php'>Result</a>";
						}
				
					} 

                } 
                if($_auth_['role'] == 'supervisor'){
                    echo "<a href='proposal.php'>Proposal</a>";
                    echo "<a href='list.php'>List of Proposal</a>";
                    echo "<a href='proposal_view.php'>Proposal Status</a>";
                    echo "<a href='project.php'>Project Assignment</a>";
                    echo "<a href='meeting.php'>Meeting</a>";
                    echo "<a href='result.php'>Marksheet</a>";
                }
            }
        ?>

        <?php
            $gets = "SELECT * FROM student WHERE student_name='".$_SESSION['name']."';";
            $results = mysqli_query($con, $gets);

            while($row = $results->fetch_assoc()){
                if($row['role'] == 'admin') {
                    echo "<a href='admin_approval.php'>For Admin only</a>";
                } else {
                    echo "";
                }
            }
        ?>
        
        <a href='logout.php'>Logout</a>
        </div>
        <span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; Menu</span>

        <div id="planning" class="planning">
            <fieldset>
                <legend> Planning</legend>
                <div id="titlebox">
                <form action="" method="POST">
                    <p>
                        <label for="planning">Please enter your planning here :</label>
                        <input type="text" id="planning" name="planning" placeholder="Enter your planning" size="200" required>
                    </p>
                    <p>
                        <label for="startWeek"> Enter the starting week : </label> 
                        <input type="week" name="startWeek" required/>
                    </p>
                    <p>
                        <label for="endWeek"> Enter the finsih week : </label> 
                        <input type="week" name="endWeek" required/>
                    </p>
                    <p>
                        <input type="submit" name="submit" value="Submit">
                    </p>
                </form>
                </div>
            </fieldset>
<!-- ------------------------------------------------------------------------------------------------------------------------------------- -->
            <fieldset>
				<legend> Planning Status</legend>
				<div id ="planningTable">
					<table>
						<thead>
							<tbody>
								<tr>
									<th title ="student_name" style="text-align:center"> Student Name </th>
									<th title ="student_id" style="text-align:center"> Student ID </th>
									<!-- <th title ="title" style="text-align:center"> Title </th> -->
                                    <th title ="planning" style="text-align:center"> Planning </th>
									<th title ="startWeek" style="text-align:center"> Start Week </th>
									<th title ="endWeek" style="text-align:center">End Week</th>
								</tr>
							</tbody>
						</thead>

						<thead>
							<tbody>
								<?php 
									while($row = $resultss->fetch_assoc()) {
										echo "<tr>";
										echo "<td style='text-align:center'>".$row['student_name']."</td>";
										echo "<td style='text-align:center'>".$row['student_id']."</td>";
										//echo "<td style='text-align:center'>".$row['title']."</td>";
										echo "<td style='text-align:center'>".$row['planning']."</td>";
										echo "<td style='text-align:center'>".$row['startWeek']."</td>";
										echo "<td style='text-align:center'>".$row['endWeek']."</td>";
										echo "</tr>";
									}
								?>
							</tbody>
						</thead>
					</table>
				</div>
			</fieldset>
         
            <?php
                if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submits'])) {
                    $status = trim('Accept');
                    $name = trim($_SESSION['name']);
                    $id = trim($_SESSION['id']);

                    if($query = $con->prepare("SELECT * FROM planning WHERE student_name = ?")) {
                        $error = '';

                        $query->bind_param('s', $name);
                        $query->execute();
                        $query->store_result();

                        $error = '';
                        if(empty($error)){
                            $sql = $con->prepare("UPDATE planning SET status=? WHERE student_name=? and student_id=?;");
                            $sql->bind_param("sss", $status, $name, $id);
                            $result = $sql->execute();
                            if ($result) {
                                $error .= "<p class='success'>Successful Update!</p>";
                            } else {
                                $error .= "<p class='error'>Not Successful Update!</p>";
                            }
                        }
                    }
                    // $row = mysqli_fetch_array($result);
                    
                    $query->close();
                    $sql->close();
                    mysqli_close($con);
                }
            ?>
        </div>
    </body>
</html>