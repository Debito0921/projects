#include <iostream>

using namespace std;

void CapsAandB(char *str)
{

}
int main()
{
     char str1[]="abcde";
     CapsAandB(str1);


}


