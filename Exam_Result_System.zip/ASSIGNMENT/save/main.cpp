#include <iostream>
#include <fstream>

using namespace std;
void AboveBelowMean();

int main()
{
    string x;
    ofstream mfile;
    mfile.open("MaCiBai.txt");
    mfile <<
    mfile.close();


    return 0;
}




void AboveBelowMean()
{
    cout << "_____________________________________________________________" << endl;
    cout << "|                                                           |" << endl;
    cout << "|    ==================== Main Menu ====================    |" << endl;
    cout << "|        Load Data ----------------------------- [1]        |" << endl;
    cout << "|        Subjects ------------------------------ [2]        |" << endl;
    cout << "|        Compare Subjects ---------------------- [3]        |" << endl;
    cout << "|        Sort of Data -------------------------- [4]        |" << endl;
    cout << "|        Academic Report ----------------------- [5]        |" << endl;
    cout << "|        EXIT ---------------------------------- [6]        |" << endl;
    cout << "|___________________________________________________________|" << endl << endl;
    cout << " Please Enter Your Desire Number. " << endl;


}
