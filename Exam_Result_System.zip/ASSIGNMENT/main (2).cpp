#include <iostream>
#include <fstream>
#include <cmath>
#include <iomanip>
#include <string>
#include <stdlib.h>
#include <bits/stdc++.h>

using namespace std;

////// MAIN MENU AND LOAD DATA //////
void MainMenu(int, int, string, string);
void MainMenuChoice(int, int, int, string, string);
void LoadData(int, int, string, string);

////// STATISTICS //////
void subjectList(int, string);
void SubjectMenu(int, int, string, string);
void SubjectMenuChoice(int, int, int, string, string);
void StatisticsMenu(int, int, int, string, string);
int Minimum(int*, int, string);
int Maximum(int*, int, string);
double Median(int*, int, int, string);
double Mean(int*, int, string);
double Variance(int*, int, string);
double StandardDeviation(int*, int, string);
void DistinctNumberFrequency(int*, int, int, string, string);
void Histogram(int, int, int, string, string);
void printHistogram(int, int, int, int, int, int);
void AboveBelowMean(int, int, int, string, string);

////// COMPARE SUBJECTS //////
void CompareSubjectsMenu(int, int, string, string);
void CompareSubjectsChoice1(int, int, int, int, string, string);
void CompareSubjectsChoice2(int, int, int, int, string, string);
void CompareTable(int, int, int, int, string, string);
double Pearson(int, int, int, int, int, int);
double LinearA(int, int, int, int, int, int);
double LinearB(int, int, int, int, int, int);

////// SORT DATA /////
void SortDataMenu(int, int, string, string);
void SortSubjectsMenu(int, int, int, string, string);
void SortAscending(int*, int*, int);
void SortDescending(int*, int*, int);
void AscendDescend(int, int, int, int, string, string);

///// EXTRAS /////
int* arrayInformation(int, int, int, string);
char Header(int, int, string, string);
void Continue();

int main()
{
    cout << " -------------------------------------------------------" << endl;
    cout << "    Welcome To Academic Information And Report System " << endl;
    cout << " -------------------------------------------------------" << endl;
    Continue();
    string file, header;
    int row = 0, col = 0;

    MainMenu(row, col, header, file);
return 0;
}

/////////////////////////////////////////////////////////////////////////////////////////////
void MainMenu(int row, int col, string header, string file)
{
    int MainMenu_Num = 0;

    do
    {
        cout << "_____________________________________________________________" << endl;
        cout << "|                                                           |" << endl;
        cout << "|    ==================== Main Menu ====================    |" << endl;
        cout << "|        Load Data ----------------------------- [1]        |" << endl;
        cout << "|        Subjects ------------------------------ [2]        |" << endl;
        cout << "|        Compare Subjects ---------------------- [3]        |" << endl;
        cout << "|        Sort of Data -------------------------- [4]        |" << endl;
        cout << "|        Academic Report ----------------------- [5]        |" << endl;
        cout << "|        EXIT ---------------------------------- [6]        |" << endl;
        cout << "|___________________________________________________________|" << endl << endl;
        cout << " Please Enter Your Desire Number. " << endl;
        MainMenuChoice(MainMenu_Num, row, col, header, file);
    }
    while (MainMenu_Num != 6);

    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
void MainMenuChoice(int inputNum, int row, int col, string header, string file)
{
    bool charError; string num;
    cin >> inputNum;
    system("CLS");
    charError = cin.fail();

    if (inputNum == 1)
        LoadData(row, col, header, file);

    else if (inputNum== 2)
        SubjectMenu(row, col, header, file);

    else if (inputNum == 3)
        CompareSubjectsMenu(row, col, header, file);

    else if (inputNum == 4)
        SortDataMenu(row, col, header, file);
    /*
    else if (inputNum == 5)
    */

    else if (inputNum == 6)
    {
        cout << "Thanks for using our system! Hope to see you again." << endl;
        exit(0);
    }

    else if (charError)
    {
        cout << "Invalid Input! Please Try Again!" << endl;
        cin.clear();
        getline(cin, num);
        Continue();
    }
    else
    {
        cout << "Invalid Input! Please Try Again!" << endl;
        Continue();
    }
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
void LoadData(int row, int col, string header, string file)
{
    cout << "Enter File Name : ";
    cin >> file;
    system("CLS");

    ifstream inputFile;
    inputFile.open(file);
    inputFile >> col >> header >> row;

    if (!inputFile)
    {
        while (!inputFile)
        {
            cout << "Error: file could not be opened. Please Try Again!"<< endl;
            cout << "Enter File Name : ";
            cin >> file;
            system("CLS");
            inputFile.open(file);
            inputFile >> col >> header >> row;
            if (!inputFile)
                cout << "";
            else
            {
                cout << "Your file has been loaded successfully." << endl;
                Continue();
                MainMenu(row, col, header, file);
            }
        }
    }

    else
    {
        cout << "Your file has been loaded successfully." << endl;
        Continue();
        MainMenu(row, col, header, file);
    }
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
int* arrayInformation(int inputNum, int row, int col, string file)
{
    int* marks = new int[row];
    int detail, arrayDetail[row][col];
    string header;
    ifstream inputFile;
    inputFile.open(file);
    inputFile >> col >> header >> row;

    for ( int i = 0; i < row; i++)
    {
        for ( int j = 0; j < col; j++)
        {
            inputFile >> detail;
            inputFile.ignore(1,',');
            arrayDetail[i][j] = detail;
        }
        marks[i] = arrayDetail[i][inputNum];
    }

    return marks;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
char Header(int num, int col, string header, string file)
{
    ifstream inputFile;
    inputFile.open(file);

    int n = header.size();
    char arrayHeader[n];
    char* headerPointer;

    strcpy(arrayHeader, header.c_str());
    headerPointer = strtok(arrayHeader, ",");

    for( int i = 0; i < col; i++)
    {
        if (headerPointer != NULL)
        {
            strcpy(arrayHeader, headerPointer);
            headerPointer = strtok(NULL, ",");
            if (i == num)
                cout << arrayHeader;
        }
    }
    return 0;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
void subjectList(int col, string header)
{
    int n = header.size();
    char arrayHeader[n];
    char* headerPointer;

    strcpy(arrayHeader, header.c_str());
    headerPointer = strtok(arrayHeader, ",");

    for (int i = 1; i < col+1; i++)
    {
        if (headerPointer != NULL)
        {
            strcpy(arrayHeader, headerPointer);
            headerPointer = strtok (NULL, ",");
            if (i >= 3)
                cout << "                 [" << i-2 << "] - " << arrayHeader << endl;
        }
    }
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
void SubjectMenu(int row, int col, string header, string file)
{
    ifstream inputFile;
    inputFile.open(file);
    int SubjectMenu_Num = 0;

    if (!inputFile)
    {
        cout << "Invalid Data! Please Load Data!" << endl;
        Continue();
        MainMenu(row, col, header, file);
    }

    else
    {
        do
        {
            cout << "___________________________________________________" << endl << endl;
            cout << "    ================= Subjects ================     " << endl;

            subjectList(col, header);
            cout << "                 [" << col-1 << "] - Back To Main Menu" << endl;
            cout << "___________________________________________________" << endl << endl;
            cout << " Please Select A Subject. " << endl;
            SubjectMenuChoice(SubjectMenu_Num, row, col, header, file);
        }
        while(SubjectMenu_Num != col-1);
    }
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
void SubjectMenuChoice(int inputNum, int row, int col, string header, string file)
{
    bool charError; string num;
    cin >> inputNum;
    system("CLS");
    charError = cin.fail();

    if (inputNum > 0 && inputNum < col-1)
        StatisticsMenu(inputNum, row, col, header, file);

    else if (inputNum == col-1)
        MainMenu(row, col, header, file);

    else if (charError)
    {
        cout << "Invalid Input! Please Try Again!" << endl;
        cin.clear();
        getline(cin, num);
        Continue();
    }

    else
    {
        cout << "Invalid Input! Please Try Again!" << endl;
        Continue();
    }
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
void StatisticsMenu(int SubjectMenu_Num, int row, int col, string header, string file)
{
    bool charError;
    string num;
    int StatisticsMenu_Num;
    int* arrayMarks = arrayInformation(SubjectMenu_Num+1, row, col, file);
    ofstream File;

    do
    {
        cout << "_________________________________________________________________" << endl;
        cout << "|                                                               |" << endl;
        cout << "|    ===================== Statistics =====================     |" << endl;
        cout << "|          Minimum mark -------------------------- [1]          |" << endl;
        cout << "|          Maximum mark -------------------------- [2]          |" << endl;
        cout << "|          Median -------------------------------- [3]          |" << endl;
        cout << "|          Mean ---------------------------------- [4]          |" << endl;
        cout << "|          Variance ------------------------------ [5]          |" << endl;
        cout << "|          Standard deviation -------------------- [6]          |" << endl;
        cout << "|          Frequencies of the distinct numbers --- [7]          |" << endl;
        cout << "|          Histogram ----------------------------- [8]          |" << endl;
        cout << "|          Above/Below mean ---------------------- [9]          |" << endl;
        cout << "|          Back to Subject Menu ------------------ [10]         |" << endl;
        cout << "|_______________________________________________________________|" << endl << endl;
        cout << " Please Enter Your Desire Number. " << endl;
        cin >> StatisticsMenu_Num;
        system("CLS");

        // TO CHECK THE INPUT IS WHETHER include CHARACTER
        charError = cin.fail();

        if (StatisticsMenu_Num == 1)
        {
            cout << "-----------------------------------" << endl;
            cout << "|      Subject      |   Minimum   |" << endl;
            cout << "-----------------------------------" << endl;
            cout << "|" << setw(12) << Header(SubjectMenu_Num+1, col, header, file) << setw(7) << "|" << setw(7) << Minimum(arrayMarks, row, file) << setw(7) << "|" << endl;
            cout << "-----------------------------------" << endl;
            Continue();
        }

        else if (StatisticsMenu_Num == 2)
        {
            cout << "-----------------------------------" << endl;
            cout << "|      Subject      |   Maximum   |" << endl;
            cout << "-----------------------------------" << endl;
            cout << "|" << setw(12) << Header(SubjectMenu_Num+1, col, header, file) << setw(7) << "|" << setw(7) << Maximum(arrayMarks, row, file) << setw(7) << "|" << endl;
            cout << "-----------------------------------" << endl;
            Continue();
        }


        else if (StatisticsMenu_Num == 3)
        {
            cout << "-----------------------------------" << endl;
            cout << "|      Subject      |    Median   |" << endl;
            cout << "-----------------------------------" << endl;
            cout << "|" << setw(12) << Header(SubjectMenu_Num+1, col, header, file) << setw(7) << "|" << setw(9) << Median(arrayMarks, row, col, file) << setw(5) << "|" << endl;
            cout << "-----------------------------------" << endl;
            Continue();
        }

        else if (StatisticsMenu_Num == 4)
        {
            cout << "----------------------------------" << endl;
            cout << "|      Subject      |    Mean    |" << endl;
            cout << "----------------------------------" << endl;
            cout << "|" << setw(12) << Header(SubjectMenu_Num+1, col, header, file) << setw(7) << "|" << setw(8) << Mean(arrayMarks, row, file)<< setw(5) << "|" << endl;
            cout << "----------------------------------" << endl;
            Continue();
        }

        else if (StatisticsMenu_Num == 5)
        {
            cout << "--------------------------------------" << endl;
            cout << "|      Subject      |    Variance    |" << endl;
            cout << "--------------------------------------" << endl;
            cout << "|" << setw(12) << Header(SubjectMenu_Num+1, col, header, file) << setw(7) << "|" << setw(11) << Variance(arrayMarks, row, file) << setw(6) << "|" << endl;
            cout << "--------------------------------------" << endl;
            Continue();
        }

        else if (StatisticsMenu_Num == 6)
        {
            cout << "--------------------------------------------------" << endl;
            cout << "|      Subject      |     Standard Deviation     |" << endl;
            cout << "-------------------------------------------------" << endl;
            cout << "|" << setw(12) << Header(SubjectMenu_Num+1, col, header, file) << setw(7) << "|" << setw(16) << StandardDeviation(arrayMarks, row, file) << setw(13) << "|" << endl;
            cout << "--------------------------------------------------" << endl;
            Continue();
        }

        else if (StatisticsMenu_Num == 7)
        {
            DistinctNumberFrequency(arrayMarks, row, col, header, file);
            Continue();
        }
        else if (StatisticsMenu_Num == 8)
        {
            Histogram(SubjectMenu_Num, row, col, header, file);
            Continue();
        }
        else if (StatisticsMenu_Num == 9)
        {
            AboveBelowMean(SubjectMenu_Num, row, col, header, file);
            cout << endl;
            Continue();
        }
        else if (StatisticsMenu_Num == 10)
            SubjectMenu(row, col, header, file);
        else if (charError)
            {
                cout << "Invalid Input! Please Try Again!" << endl;
                cin.clear();
                getline(cin, num);
                Continue();
            }
        else
        {
            cout << "Invalid Input! Please Try Again!" << endl;
            Continue();
        }
    }
    while(StatisticsMenu_Num != 10);

    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
int Minimum(int* arrayMarks, int size, string file)
{
    int SmallestNum = arrayMarks[0];

    for (int i = 0; i < size; i++)
    {
        if (arrayMarks[i] < SmallestNum)
            SmallestNum = arrayMarks[i];
    }
    return SmallestNum;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
int Maximum(int* arrayMarks, int size, string file)
{
    int BiggestNum = arrayMarks[0];

    for (int i = 1; i < size; i++)
    {
        if (arrayMarks[i] > BiggestNum)
            BiggestNum = arrayMarks[i];
    }
    return BiggestNum;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
double Median(int* arrayMarks, int row, int col, string file)
{
    int* arrayID = arrayInformation(0, row, col, file);
    double median;
    SortAscending(arrayMarks, arrayID, row);

    // even number
    if ( row%2 == 0 )
        median = (arrayMarks[row/2] + arrayMarks[(row/2) - 1]) / 2.00;

    // odd number
    else
        median = arrayMarks[(row-1) / 2];
    cout << setprecision(2) << fixed << showpoint;
    return median;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
double Mean(int* arrayMarks, int size, string file)
{
    double sum = 0;
    for ( int i = 0; i < size; i++)
    {
        sum = sum + arrayMarks[i];
    }
    cout << setprecision(2) << fixed << showpoint;
    return (sum) / (size);
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
double Variance(int* arrayMarks, int size, string file)
{
    double sum = 0;

    for ( int i = 0; i < size; i++)
    {
        sum = sum + pow(arrayMarks[i] - Mean(arrayMarks, size, file), 2);
    }
    return (sum) / (size);
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
double StandardDeviation(int* arrayMarks, int size, string file)
{
    cout << setprecision(2) << fixed << showpoint;
    return pow(Variance(arrayMarks, size, file), 0.5);
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
void DistinctNumberFrequency( int* arrayMarks, int row, int col, string header, string file)
{
    int* arrayID = arrayInformation(0, row, col, file);
    int count;
    SortAscending(arrayMarks, arrayID, row);
    ofstream SaveFile;
    SaveFile.open("DistinctNumberFrequency.txt");

    ///// TABLE HEADER /////
    cout << "-------------------------" << endl;
    cout << "|  Marks  |  Frequency  |" << endl;
    cout << "-------------------------" << endl;
    SaveFile << "-------------------------" << endl;
    SaveFile << "|  Marks  |  Frequency  |" << endl;
    SaveFile << "-------------------------" << endl;

    for(int i = 0; i < row; i++)
    {
        count = 1;
        for (int j = i+1; j < row; j++)
        {
            if (arrayMarks[i] == arrayMarks[j])
            {
                count++;
                i++;
            }
        }
        cout << "|" << setw(5) << arrayMarks[i] << setw(5) << "|" << setw(7) << count << setw(7) << "|" << endl;
        SaveFile << "|" << setw(5) << arrayMarks[i] << setw(5) << "|" << setw(7) << count << setw(7) << "|" << endl;
    }

    cout << "-------------------------" << endl;
    SaveFile << "-------------------------" << endl;

    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////
void Histogram(int SubjectMenu_Num, int row, int col, string header, string file)
{
    int* arrayMarks = arrayInformation(SubjectMenu_Num+1, row, col, file);
    int* arrayID = arrayInformation(0, row, col, file);
    int firstsector = 0, secondsector = 0, thirdsector = 0, forthsector = 0, fifthsector = 0;
    SortAscending(arrayMarks, arrayID, row);
    cout << "Histogram : " << Header(SubjectMenu_Num+1, col, header, file) << endl;
    cout << string(30, '=') << endl << endl;

    for (int i=0; i<row; i++)
    {
        if(arrayMarks[i]>= 0 && arrayMarks[i] <= 19)
            firstsector++;
        else if (arrayMarks[i]>= 20 && arrayMarks[i] <=39)
            secondsector++;
        else if (arrayMarks[i]>= 40 && arrayMarks[i] <= 59)
            thirdsector++;
        else if (arrayMarks[i]>= 60 && arrayMarks[i] <= 79)
            forthsector++;
        else
            fifthsector++;
    }
    int frequency[5] = {firstsector, secondsector, thirdsector, forthsector, fifthsector};
    int* arrayFreq = frequency;
    printHistogram(Maximum(arrayFreq, 5, file), firstsector, secondsector, thirdsector, forthsector, fifthsector);
    cout << "|---------------------------------------------------------------------------> Marks" << endl;
    cout << "     |0-19|        |20-39|        |40-59|        |60-79|        |80-100|" << endl;
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
void printHistogram(int maxNum, int firstsector, int secondsector, int thirdsector, int forthsector, int fifthsector)
{
    for (int i = maxNum; i > 0; i--)
    {
        if (i <= firstsector)
            cout << "       *       ";
        else
            cout << "               ";

        if (i <= secondsector)
            cout << "       *       ";
        else
            cout << "               ";

        if (i <= thirdsector)
            cout << "       *       ";
        else
            cout << "               ";

        if (i <= forthsector)
            cout << "       *       ";
        else
            cout << "               ";

        if (i <= fifthsector)
            cout << "       *       ";
        else
            cout << "               ";
        cout << endl;
    }
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
void AboveBelowMean(int SubjectMenu_Num, int row, int col, string header, string file)
{
    int* arrayMarks1= arrayInformation(SubjectMenu_Num+1, row, col, file); int* arrayMarks2= arrayInformation(SubjectMenu_Num+1, row, col, file);
    int* arrayID1 = arrayInformation(0, row, col, file);  int* arrayID2 = arrayInformation(0, row, col, file);
    int count1 = 0, count2 = 0;
    ofstream SaveFile;

    cout << "Above/Below Mean : " << Header(SubjectMenu_Num+1, col, header, file) << endl;
    cout << string(30, '=') << endl << endl;
    cout << "Average Marks: " << Mean(arrayMarks1, row, file) << endl << endl;
    cout << " Marks Above Mean " << string(30, ' ') << " Marks Below Mean " << endl;
    cout << "---------------------------------" << string(16, ' ') << "---------------------------------" << endl;
    cout << "|        ID        |    Mark    |" << string(16, ' ') << "|        ID        |    Mark    |" << endl;
    cout << "---------------------------------" << string(16, ' ') << "---------------------------------" << endl;

    //above average
    for (int i = 0; i < row; i++)
    {
        SortDescending(arrayMarks1, arrayID1, row);
        SortAscending(arrayMarks2, arrayID2, row);
        if (arrayMarks1[i] != Mean(arrayMarks1, row, file))
        {
            if (arrayMarks1[i] > Mean(arrayMarks1, row, file))
            {
                cout << "|" << setw(12) <<  arrayID1[i] << setw(7) << "|" << setw(7) << arrayMarks1[i] << setw(6) << "|";
                count1++;
            }

            else if (i == count1)
                cout << "---------------------------------"; SaveFile << "---------------------------------";

            if (arrayMarks2[i] < Mean(arrayMarks1, row, file))
            {
                cout << string(16, ' ') << "|" << setw(12) << arrayID2[i] << setw(7) << "|" << setw(7) << arrayMarks2[i] << setw(6) << "|" << endl;
                count2++;
            }

            else if (i == count2)
                cout << string(16, ' ') << "---------------------------------" << endl; SaveFile << string(16, ' ') << "---------------------------------" << endl;
        }

        if (count1 < count2)
        {
            if (i >= count1 && i < count2)
                cout << string(33, ' ');  SaveFile << string(33, ' ');

        }

        else
        {
            if (i > count2 && i < count1)
                    cout << endl; SaveFile << endl;
        }
    }
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
void CompareSubjectsMenu(int row, int col, string header, string file)
{
    ifstream inputFile;
    inputFile.open(file);
    int CompareSubjectsMenu_Num1 = 0, CompareSubjectsMenu_Num2 = 0;

    if (!inputFile)
    {
        cout << "Invalid Data! Please Load Data!" << endl;
        Continue();
        MainMenu(row, col, header, file);
    }

    else
    {
        do
        {
            cout << "___________________________________________________" << endl << endl;
            cout << "    ============= Compare Subjects ============     " << endl;

            subjectList(col, header);
            cout << "                 [" << col-1 << "] - Back To Main Menu" << endl;
            cout << "___________________________________________________" << endl << endl;
            CompareSubjectsChoice1(CompareSubjectsMenu_Num1, CompareSubjectsMenu_Num2, row, col, header, file);
        }
        while(CompareSubjectsMenu_Num1 == col-1 || CompareSubjectsMenu_Num2 == col-1);
    }
        return;
    }
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
void CompareSubjectsChoice1(int inputNum1, int inputNum2, int row, int col, string header, string file)
{
        bool charError; string num;
        ///// INPUT FIRST SUBJECT /////
        cout << "Please Select The First Subject: ";
        cin >> inputNum1;

        charError = cin.fail();

        if (inputNum1 == col-1)
        {
            system("CLS");
            MainMenu(row, col, header, file);
        }

        else if (inputNum1 > 0 && inputNum1 < col-1)
        {
            cout << endl;
            CompareSubjectsChoice2(inputNum1, inputNum2, row, col, header, file);
        }

        else if (charError)
        {
            system("CLS");
            cout << "Invalid Subject! Please Try Again!" << endl;
            cin.clear();
            getline(cin, num);
            Continue();
            CompareSubjectsMenu(row, col, header, file);
        }

        else
        {
            system("CLS");
            cout << "Invalid Subject! Please Try Again!" << endl;
            Continue();
            CompareSubjectsMenu(row, col, header, file);
        }
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
void CompareSubjectsChoice2(int inputNum1, int inputNum2, int row, int col, string header, string file)
{
    bool charError; string num;
    cout << "Please Select The Second Subject: ";
    cin >> inputNum2;
    system("CLS");

    charError = cin.fail();

    if (inputNum2 == col-1)
    {
        MainMenu(row, col, header, file);
    }

    else if (inputNum2 > 0 && inputNum2 < col-1)
    {
        if (inputNum1 == inputNum2)
        {
            cout << "You have selected two same subjects. Please try again!" << endl;
            Continue();
            CompareSubjectsMenu(row, col, header, file);
        }

        else
        {
            CompareTable(inputNum1, inputNum2, row, col, header, file);
            CompareSubjectsMenu(row, col, header, file);
        }
    }

    else if (charError)
    {
        cout << "Invalid Subject! Please Try Again!" << endl;
        cin.clear();
        getline(cin,num);
        Continue();
        CompareSubjectsMenu(row, col, header, file);
    }

    else
    {
        cout << "Invalid Subject! Please Try Again!" << endl;
        Continue();
        CompareSubjectsMenu(row, col, header, file);
    }
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
double Pearson(int sumofX, int sumofY, int sumofXY, int sumofXSquare, int sumofYSquare, int row)
{
    double pearson, P1, P2, P3;
    P1 = (row*sumofXY)-(sumofX*sumofY);
    P2 = (row*sumofXSquare)-(sumofX*sumofX);
    P3 = (row*sumofYSquare)-(sumofY*sumofY);
    pearson = P1 / pow(P2*P3,0.5);

    return pearson;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
double LinearA(int sumofX, int sumofY, int sumofXY, int sumofXSquare, int sumofYSquare, int row)
{
    double a1, a2;
    a1 = (sumofY*sumofXSquare) - (sumofX*sumofXY);
    a2 = (row*sumofXSquare) - (sumofX*sumofX);
    return a1 / a2;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
double LinearB(int sumofX, int sumofY, int sumofXY, int sumofXSquare, int sumofYSquare, int row)
{
    double b1, b2;
    b1 = (row*sumofXY) - (sumofX*sumofY);
    b2 = (row*sumofXSquare) - (sumofX*sumofX);
    return b1 / b2;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
void CompareTable(int CompareSubjectsMenu_Num1, int CompareSubjectsMenu_Num2, int row, int col, string header, string file)
{
    int sumofX = 0, sumofY = 0, sumofXY = 0, sumofXSquare = 0, sumofYSquare = 0;
    int* arrayMarks_X = arrayInformation(CompareSubjectsMenu_Num1+1, row, col, file);
    int* arrayMarks_Y = arrayInformation(CompareSubjectsMenu_Num2+1, row, col, file);

    cout << setw(32) << Header(CompareSubjectsMenu_Num1 + 1, col, header, file) << " ( X )  VS  ";
    cout << Header(CompareSubjectsMenu_Num2 + 1, col, header, file) << " ( Y )" << endl << endl;

    ///// TABLE HEADER /////
    cout << "----------------------------------------------------------------------------------" << endl;
    cout << "|    STUDENT    |     X     |     Y     |     XY     |     X^2     |     Y^2     |" << endl;
    cout << "----------------------------------------------------------------------------------" << endl;

    for ( int i = 0; i < row; i++)
    {
        ///// CALCULATE SUM OF EACH CALCULATION /////
        sumofX = sumofX + arrayMarks_X[i];
        sumofY = sumofY + arrayMarks_Y[i];
        sumofXY = sumofXY+ (arrayMarks_X[i]*arrayMarks_Y[i]);
        sumofXSquare = sumofXSquare + pow(arrayMarks_X[i],2);
        sumofYSquare = sumofYSquare + pow(arrayMarks_Y[i],2);

        ///// TABLE CONTENT ///////
        cout << "|" << setw(8) << i+1 << setw(8) << "|" <<
             setw(6) << arrayMarks_X[i]<< setw(6) << "|" <<
             setw(6) << arrayMarks_Y[i] << setw(6) << "|" <<
             setw(8) << arrayMarks_X[i]*arrayMarks_Y[i] << setw(5) << "|" <<
             setw(8) << pow(arrayMarks_X[i],2) << setw(6) << "|" <<
             setw(8) << pow(arrayMarks_Y[i],2) << setw(6) << "|" << endl;
    }

    ///// TOTAL PRINT INSIDE TABLE /////
    cout << "==================================================================================" << endl;
    cout << "|    Total =    |" <<
         setw(7) << sumofX << setw(5) << "|" <<
         setw(7) << sumofY << setw(5) << "|" <<
         setw(9) << sumofXY << setw(4) << "|" <<
         setw(9) << sumofXSquare << setw(5) << "|" <<
         setw(9) << sumofYSquare << setw(5) << "|" << endl;
    cout << "==================================================================================" << endl << endl;

    ///// PRINT PEARSON CALCULATION /////
    cout << "1 . Pearson's Correlation" << endl << endl;
    cout << "    r = (" << row << "*" << sumofXY << "-" << sumofX << "*" << sumofY << ")" << " / sqrt(("
         << row << "*" << sumofXSquare << " - " << sumofX << "*" << sumofX << ") * ("
         << row << "*" << sumofYSquare << " - " << sumofY << "*" << sumofY << "))"<< endl;
    cout << "      = " << Pearson(sumofX, sumofY, sumofXY, sumofXSquare, sumofYSquare, row) << endl << endl;

    ///// PRINT LINEAR CALCULATION /////
    cout << "2 . Linear Regression" << endl << endl;
    cout << "    a = (" << sumofY << "*" << sumofXSquare << " - " << sumofX << "*" << sumofXY << ") / ("
         << row << "*" << sumofXSquare << " - " << sumofX << "*" << sumofX << ")" << endl;
    cout << "      = " << LinearA(sumofX, sumofY, sumofXY, sumofXSquare, sumofYSquare, row) << endl;

    cout << "    b = (" << row << "*" << sumofXY << " - " << sumofX << "*" << sumofY << ") / ("
         << row << "*" << sumofXSquare << " - " << sumofX << "*" << sumofX << ")" << endl;
    cout << "      = " << LinearB(sumofX, sumofY, sumofXY, sumofXSquare, sumofYSquare, row) << endl << endl;

    cout << "    y'= " << LinearA(sumofX, sumofY, sumofXY, sumofXSquare, sumofYSquare, row) << " + "
         << LinearB(sumofX, sumofY, sumofXY, sumofXSquare, sumofYSquare, row) << "x" << endl << endl;
    Continue();

    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
void SortDataMenu(int row, int col, string header, string file)
{
    int SortDataMenu_Num = 0;
    bool charError;
    string num;
    ifstream inputFile;
    inputFile.open(file);

    if (!inputFile)
    {
        cout << "Invalid Data! Please Load Data!" << endl;
        Continue();
        MainMenu(row, col, header, file);
    }

    else
    {
        do
        {
            cout << "____________________________________________________" << endl;
            cout << "|                                                  |" << endl;
            cout << "|    =============== Sort Data ===============     |" << endl;
            cout << "|          Ascending Order --------- [1]           |" << endl;
            cout << "|          Descending Order -------- [2]           |" << endl;
            cout << "|          Back to Main Menu ------- [3]           |" << endl;
            cout << "|__________________________________________________|" << endl << endl;
            cout << " Please Enter Your Desire Number. " << endl;
            cin >> SortDataMenu_Num;
            system("CLS");

            // TO CHECK THE INPUT IS WHETHER include CHARACTER
            charError = cin.fail();

            if (SortDataMenu_Num > 0 && SortDataMenu_Num < 3)
                SortSubjectsMenu(SortDataMenu_Num, row, col, header, file);

            else if (SortDataMenu_Num == 3)
                    MainMenu(row, col, header, file);

            else if (charError)
            {
                cout << "Invalid Input! Please Try Again!" << endl;
                cin.clear();
                getline(cin, num);
                Continue();
            }

            else
            {
                cout << "Invalid Input! Please Try Again!" << endl;
                Continue();
            }
        }
        while(SortDataMenu_Num != 3);
    }
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
void SortSubjectsMenu(int SortDataMenu_Num, int row, int col, string header, string file)
{
    int SortSubjectsMenu_Num = 0;
    bool charError;
    string num;

    do
    {
        cout << "___________________________________________________" << endl << endl;
        cout << "    ================ Sort Data ================     " << endl;

        subjectList(col, header);
        cout << "                 [" << col-1 << "] - Back To Sort Data Menu" << endl;
        cout << "___________________________________________________" << endl << endl;
        cout << " Please Select A Subject." << endl;
        cin >> SortSubjectsMenu_Num;
        system("CLS");

        charError = cin.fail();

        if(SortSubjectsMenu_Num > 0 && SortSubjectsMenu_Num < col-1)
        {
            AscendDescend(SortDataMenu_Num, SortSubjectsMenu_Num, row, col, header, file);
            Continue();
        }

        else if (SortSubjectsMenu_Num == col-1)
            SortDataMenu(row, col, header, file);

        else if (charError)
        {
            cout << "Invalid Input! Please Try Again!" << endl;
            cin.clear();
            getline(cin, num);
            Continue();
        }

        else
        {
            cout << "Invalid Input! Please Try Again!" << endl;
            Continue();
        }
    }
    while(SortSubjectsMenu_Num != col-1);
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
void SortAscending(int* array1, int* array2, int size)
{
    int temp1, temp2;
    for(int i = 0; i < size; i++)
    {
        for (int j = i+1; j < size; j++)
        {
            if(array1[i] > array1[j])
			{
				temp1 = array1[i];
				array1[i] = array1[j];
				array1[j] = temp1;

				temp2 = array2[i];
				array2[i] = array2[j];
				array2[j] = temp2;
			}
        }
    }
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
void SortDescending(int* array1, int* array2, int size)
{
    int temp1, temp2;
    for(int i = 0; i < size; i++)
    {
        for (int j = i+1; j < size; j++)
        {
            if(array1[j] > array1[i])
			{
				temp1 = array1[i];
				array1[i] = array1[j];
				array1[j] = temp1;

				temp2 = array2[i];
				array2[i] = array2[j];
				array2[j] = temp2;
			}
        }
    }
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
void AscendDescend(int SortDataMenu_Num, int SortSubjectsMenu_Num, int row, int col, string header, string file)
{
    int* arrayMarks = arrayInformation(SortSubjectsMenu_Num+1, row, col, file);
    int* arrayID = arrayInformation(0, row, col, file);

    cout << "Sort Data : ( "  <<  Header(SortSubjectsMenu_Num + 1, col, header, file) << ")" << endl;

    ///// PRINT HEADER /////
    cout << "-------------------------------------" << endl;
    cout << "|         ID          |    Marks    |" << endl;
    cout << "-------------------------------------" << endl;

    ///// PRINT THE ID AND MARKS /////
    for(int i = 0; i < row; i++)
    {
        if (SortDataMenu_Num == 1)
        {
            SortAscending(arrayMarks, arrayID, row);
            cout << "|" << setw(15) << arrayID[i] << setw(7) << "|" << setw(8) << arrayMarks[i] << setw(6) << "|" << endl;
        }

        else if (SortDataMenu_Num == 2)
        {
            SortDescending(arrayMarks, arrayID, row);
            cout << "|" << setw(15) << arrayID[i] << setw(7) << "|" << setw(8) << arrayMarks[i] << setw(6) << "|" << endl;
        }
    }

    cout << "-------------------------------------" << endl;

    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
void Continue()
{
    system("pause");
    system("CLS");
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////
