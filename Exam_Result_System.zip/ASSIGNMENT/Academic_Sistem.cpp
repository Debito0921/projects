#include <iostream>
#include <fstream>
#include <cmath>
#include <iomanip>
#include <string>
#include <stdlib.h>
#include <bits/stdc++.h>

using namespace std;

////// MAIN MENU  //////
void MainMenu(int, int, string, string);
void MainMenuChoice(int, int, int, string, string);

////// LOAD DATA //////
void LoadData(int, int, string, string);
int* arrayInformation(int, int, int, string);
void SortAscending(int*, int*, int);
void SortDescending(int*, int*, int);
char* Subject(int, int, string);
void subjectList(int, string);

////// STATISTICS //////
void SubjectMenu(int, int, string, string);
void SubjectMenuChoice(int, int, int, string, string);
void StatisticsMenu(int, int, int, string, string);
int Minimum(int*, int);
int Maximum(int*, int);
double Median(int*, int*, int);
double Mean(int*, int);
double Variance(int*, int);
double StandardDeviation(int*, int);
void DistinctMarksFrequency(int*, int*, int, string);
void DistinctMarksFrequencyTXT(int*, int, int, string);
void DistinctMarksFrequencyHTML(int*, int, string);
void Histogram(int*, int*, int, string, string);
void printHistogram(int, int, int, int, int, int);
void printHistogramTXT(ofstream&, int, int, int, int, int, int);
void HistogramTXT(int*, int*, int*, int, int, int, int, int, int, int, string);
void HistogramHTML(double, double, double, double, double, double, string);
void AboveBelowMean(int, int, int, string, string);
void AboveBelowMeanTXT(int*, int*, int*, int*, int, int, int, string);
void AboveBelowMeanHTML(int*, int*, int*, int*, int, string);

////// COMPARE SUBJECTS //////
void CompareSubjectsMenu(int, int, string, string);
void CompareSubjectsChoice1(int, int, int, int, string, string);
void CompareSubjectsChoice2(int, int, int, int, string, string);
void CompareTable(int, int, int, int, string, string);
double Pearson(int, int, int, int, int, int);
double LinearA(int, int, int, int, int, int);
double LinearB(int, int, int, int, int, int);
void PrintPearsonLinearCalculation(int, int, int, int, int, int);
void CompareSubjectsTXT(int*, int*, int*, int, int, int, int, int, int, string, string);
void CompareSubjectsHTML(int*, int*, int*, int, int, int, int, int, int, string, string);

////// SORT DATA /////
void SortDataMenu(int, int, string, string);
void SortDataSubjectsMenu(int, int, int, string, string);
void AscendDescend(int, int, int, int, string, string);
void SortDataTXT(ofstream&, int*, int*, int, int, string);
void SortDataHTML(ofstream&, int*, int*, int, int, string);

////// ACADEMIC REPORT /////
void AcademicReportMenu(int, int, string, string);
void AcademicReportMenuChoice(int, int, int, string, string);
void AcademicReport(int, int, int, string, string);
void SaveAcademicReportMenu(int*, int*, int, int, int, string, string, string);
void AcademicReportTXT(int*, int*, int, string);
void AcademicReportHTML(int*, int*, int, string);

///// EXTRAS /////
void Continue();
void HTMLTableHeader(ofstream&);

int main()
{
    cout << " -------------------------------------------------------" << endl;
    cout << "    Welcome To Academic Information And Report System " << endl;
    cout << " -------------------------------------------------------" << endl;
    Continue();
    string file, header;
    int row = 0, col = 0;

    MainMenu(row, col, header, file);
return 0;
}

/////////////////////////////////////////////////////////////////////////////////////////////
void MainMenu(int row, int col, string header, string file)
{
    int MainMenu_Num = 0;

    do
    {
        cout << "_____________________________________________________________" << endl;
        cout << "|                                                           |" << endl;
        cout << "|    ==================== Main Menu ====================    |" << endl;
        cout << "|        Load Data ----------------------------- [1]        |" << endl;
        cout << "|        Subjects ------------------------------ [2]        |" << endl;
        cout << "|        Compare Subjects ---------------------- [3]        |" << endl;
        cout << "|        Sort of Data -------------------------- [4]        |" << endl;
        cout << "|        Academic Report ----------------------- [5]        |" << endl;
        cout << "|        EXIT ---------------------------------- [6]        |" << endl;
        cout << "|___________________________________________________________|" << endl << endl;
        cout << " Please Enter Your Desire Number. " << endl;
        MainMenuChoice(MainMenu_Num, row, col, header, file);
    }
    while (MainMenu_Num != 6);

    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
void MainMenuChoice(int inputNum, int row, int col, string header, string file)
{
    string num;
    cin >> inputNum;
    system("CLS");

    if (inputNum == 1)
        LoadData(row, col, header, file);
    else if (inputNum== 2)
        SubjectMenu(row, col, header, file);
    else if (inputNum == 3)
        CompareSubjectsMenu(row, col, header, file);
    else if (inputNum == 4)
        SortDataMenu(row, col, header, file);
    else if (inputNum == 5)
        AcademicReportMenu(row, col, header, file);
    else if (inputNum == 6)
    {
        cout << "Thanks for using our system! Hope to see you again." << endl;
        exit(0);
    }

    else if (cin.fail())
    {
        cout << "Invalid Input! Please Try Again!" << endl;
        cin.clear();
        getline(cin, num);
        Continue();
    }
    else
    {
        cout << "Invalid Input! Please Try Again!" << endl;
        Continue();
    }
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

// =========================================== LOAD DATA ================================================== //
/////////////////////////////////////////////////////////////////////////////////////////////
void LoadData(int row, int col, string header, string file)
{
    cout << "Enter File Name : ";
    cin >> file;
    system("CLS");

    ifstream inputFile;
    inputFile.open(file);
    inputFile >> col >> header >> row;

    if (!inputFile)
    {
        while (!inputFile)
        {
            cout << "Error: file could not be opened. Please Try Again!"<< endl;
            cout << "Enter File Name : ";
            cin >> file;
            system("CLS");
            inputFile.open(file);
            inputFile >> col >> header >> row;
            if (!inputFile)
                cout << "";
            else
            {
                cout << "Your file has been loaded successfully." << endl;
                Continue();
                MainMenu(row, col, header, file);
            }
            inputFile.close();
        }
    }

    else
    {
        cout << "Your file has been loaded successfully." << endl;
        Continue();
        MainMenu(row, col, header, file);
    }
    inputFile.close();
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
int* arrayInformation(int inputNum, int row, int col, string file)
{
    int* marks = new int[row];
    int detail, arrayDetail[row][col];
    string header;
    ifstream inputFile;
    inputFile.open(file);
    inputFile >> col >> header >> row;

    for ( int i = 0; i < row; i++)
    {
        for ( int j = 0; j < col; j++)
        {
            inputFile >> detail;
            inputFile.ignore(1,',');
            arrayDetail[i][j] = detail;
        }
        marks[i] = arrayDetail[i][inputNum];
    }

    return marks;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
void SortAscending(int* array1, int* array2, int size)
{
    int temp1, temp2;
    for(int i = 0; i < size; i++)
    {
        for (int j = i+1; j < size; j++)
        {
            if(array1[i] > array1[j])
			{
				temp1 = array1[i];
				array1[i] = array1[j];
				array1[j] = temp1;

				temp2 = array2[i];
				array2[i] = array2[j];
				array2[j] = temp2;
			}
        }
    }
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
void SortDescending(int* array1, int* array2, int size)
{
    int temp1, temp2;
    for(int i = 0; i < size; i++)
    {
        for (int j = i+1; j < size; j++)
        {
            if(array1[j] > array1[i])
			{
				temp1 = array1[i];
				array1[i] = array1[j];
				array1[j] = temp1;

				temp2 = array2[i];
				array2[i] = array2[j];
				array2[j] = temp2;
			}
        }
    }
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
char* Subject(int num, int col, string header)
{
    int n = header.size();
    char* arrayHeader = new char[n];
    char* headerPointer;

    strcpy(arrayHeader, header.c_str());
    headerPointer = strtok(arrayHeader, ",");

    for( int i = 0; i < col; i++)
    {
        if (headerPointer != NULL)
        {
            strcpy(arrayHeader, headerPointer);
            headerPointer = strtok(NULL, ",");
            if (i == num)
                return arrayHeader;
        }
    }
    return 0;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
void subjectList(int col, string header)
{
    int n = header.size();
    char arrayHeader[n];
    char* headerPointer;

    strcpy(arrayHeader, header.c_str());
    headerPointer = strtok(arrayHeader, ",");

    for (int i = 1; i < col+1; i++)
    {
        if (headerPointer != NULL)
        {
            strcpy(arrayHeader, headerPointer);
            headerPointer = strtok (NULL, ",");
            if (i >= 3)
                cout << "                 [" << i-2 << "] - " << arrayHeader << endl;
        }
    }
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

// =========================================== VIEW SUBJECTS =============================================== //
/////////////////////////////////////////////////////////////////////////////////////////////
void SubjectMenu(int row, int col, string header, string file)
{
    ifstream inputFile;
    inputFile.open(file);
    int SubjectMenu_Num = 0;

    if (!inputFile)
    {
        cout << "Invalid Data! Please Load Data!" << endl;
        Continue();
        MainMenu(row, col, header, file);
    }

    else
    {
        do
        {
            cout << "___________________________________________________" << endl << endl;
            cout << "    ================= Subjects ================     " << endl;

            subjectList(col, header);
            cout << "                 [" << col-1 << "] - Back To Main Menu" << endl;
            cout << "___________________________________________________" << endl << endl;
            cout << " Please Select A Subject. " << endl;
            SubjectMenuChoice(SubjectMenu_Num, row, col, header, file);
        }
        while(SubjectMenu_Num != col-1);
    }
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
void SubjectMenuChoice(int inputNum, int row, int col, string header, string file)
{
    string num;
    cin >> inputNum;
    system("CLS");

    if (inputNum > 0 && inputNum < col-1)
        StatisticsMenu(inputNum, row, col, header, file);

    else if (inputNum == col-1)
        MainMenu(row, col, header, file);

    else if (cin.fail())
    {
        cout << "Invalid Input! Please Try Again!" << endl;
        cin.clear();
        getline(cin, num);
        Continue();
    }

    else
    {
        cout << "Invalid Input! Please Try Again!" << endl;
        Continue();
    }
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
void StatisticsMenu(int SubjectMenu_Num, int row, int col, string header, string file)
{
    string num;
    string subs(Subject(SubjectMenu_Num+1, col, header));
    int StatisticsMenu_Num;
    int* arrayMarks = arrayInformation(SubjectMenu_Num+1, row, col, file);
    int* arrayID = arrayInformation(0, row, col, file);

    do
    {
        cout << "_________________________________________________________________" << endl;
        cout << "|                                                               |" << endl;
        cout << "|    ===================== Statistics =====================     |" << endl;
        cout << "|          Minimum mark -------------------------- [1]          |" << endl;
        cout << "|          Maximum mark -------------------------- [2]          |" << endl;
        cout << "|          Median -------------------------------- [3]          |" << endl;
        cout << "|          Mean ---------------------------------- [4]          |" << endl;
        cout << "|          Variance ------------------------------ [5]          |" << endl;
        cout << "|          Standard deviation -------------------- [6]          |" << endl;
        cout << "|          Frequencies of the distinct marks ----- [7]          |" << endl;
        cout << "|          Histogram ----------------------------- [8]          |" << endl;
        cout << "|          Above/Below mean ---------------------- [9]          |" << endl;
        cout << "|          Back to Subject Menu ------------------ [10]         |" << endl;
        cout << "|_______________________________________________________________|" << endl << endl;
        cout << " Please Enter Your Desire Number. " << endl;
        cin >> StatisticsMenu_Num;
        system("CLS");

        if (StatisticsMenu_Num == 1)
        {
            cout << "===================================" << endl;
            cout << "|      Subject      |   Minimum   |" << endl;
            cout << "===================================" << endl;
            cout << "|" << setw(12) << subs << setw(8) << "|" << setw(7) << Minimum(arrayMarks, row) << setw(7) << "|" << endl;
            cout << "===================================" << endl;
            Continue();
        }

        else if (StatisticsMenu_Num == 2)
        {
            cout << "===================================" << endl;
            cout << "|      Subject      |   Maximum   |" << endl;
            cout << "===================================" << endl;
            cout << "|" << setw(12) << subs << setw(8) << "|" << setw(7) << Maximum(arrayMarks, row)  << setw(7) << "|" << endl;
            cout << "===================================" << endl;
            Continue();
        }


        else if (StatisticsMenu_Num == 3)
        {
            cout << "===================================" << endl;
            cout << "|      Subject      |    Median   |" << endl;
            cout << "===================================" << endl;
            cout << "|" << setw(12) << subs << setw(8) << "|" << setw(9) << Median(arrayMarks, arrayID, row) << setw(5) << "|" << endl;
            cout << "===================================" << endl;
            Continue();
        }

        else if (StatisticsMenu_Num == 4)
        {
            cout << "=================================="<< endl;
            cout << "|      Subject      |    Mean    |" << endl;
            cout << "==================================" << endl;
            cout << "|" << setw(12) << subs << setw(8) << "|" << setw(8) << Mean(arrayMarks, row) << setw(5) << "|" << endl;
            cout << "==================================" << endl;
            Continue();
        }

        else if (StatisticsMenu_Num == 5)
        {
            cout << "======================================" << endl;
            cout << "|      Subject      |    Variance    |" << endl;
            cout << "======================================" << endl;
            cout << "|" << setw(12) << subs << setw(8) << "|" << setw(11) << Variance(arrayMarks, row) << setw(6) << "|" << endl;
            cout << "======================================" << endl;
            Continue();
        }

        else if (StatisticsMenu_Num == 6)
        {
            cout << "==================================================" << endl;
            cout << "|      Subject      |     Standard Deviation     |" << endl;
            cout << "==================================================" << endl;
            cout << "|" << setw(12) << subs << setw(8) << "|" << setw(16) << StandardDeviation(arrayMarks, row)  << setw(13) << "|" << endl;
            cout << "==================================================" << endl;
            Continue();
        }

        else if (StatisticsMenu_Num == 7)
        {
            DistinctMarksFrequency(arrayMarks, arrayID,row, subs);
            Continue();
        }
        else if (StatisticsMenu_Num == 8)
        {
            Histogram(arrayMarks, arrayID, row, file, subs);
            Continue();
        }
        else if (StatisticsMenu_Num == 9)
        {
            AboveBelowMean(SubjectMenu_Num, row, col, file, subs);
            cout << endl;
            Continue();
        }
        else if (StatisticsMenu_Num == 10)
            SubjectMenu(row, col, header, file);
        else if (cin.fail())
        {
            cout << "Invalid Input! Please Try Again!" << endl;
            cin.clear();
            getline(cin, num);
            Continue();
        }
        else
        {
            cout << "Invalid Input! Please Try Again!" << endl;
            Continue();
        }
    }
    while(StatisticsMenu_Num != 10);

    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
/***************************************************************************************
Programmer    : Hooi Thing Hong
Name          : Minimum
Task          : This function will find the minimum value in the particular column of the data array.
Data in       : Data in the particular row of data in the array, number of data in the row
Data returned : Minimum value of particular row of array.
Referred to   : -
***************************************************************************************/
int Minimum(int* arrayMarks, int size)
{
    int SmallestNum = arrayMarks[0];

    for (int i = 0; i < size; i++)
    {
        if (arrayMarks[i] < SmallestNum)
            SmallestNum = arrayMarks[i];
    }
    return SmallestNum;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
/**********************************************************************
Programmer    : Hooi Thing Hong
Name          : Maximum
Task          : This function will find the maximum value in the particular column of the data array.
Data in       : Data in the particular row of data in the array, number of data in the row
Data returned : Maximum value of particular row of array.
Referred to   : -
**********************************************************************/
int Maximum(int* arrayMarks, int size)
{
    int BiggestNum = arrayMarks[0];

    for (int i = 1; i < size; i++)
    {
        if (arrayMarks[i] > BiggestNum)
            BiggestNum = arrayMarks[i];
    }
    return BiggestNum;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
/**********************************************************************
Programmer    : Hooi Thing Hong
Name          : Mean
Task          : This function will find the middle value in the particular column of the data array.
Data in       : Data in the particular row of data in the array, number of data in the row,
                particular column of the data in the array, number of data in the row.
Data returned : Middle value of particular row of array.
Referred to   : -
**********************************************************************/
double Median(int* arrayMarks, int* arrayID, int row)
{
    double median;
    SortAscending(arrayMarks, arrayID, row);

    // even number
    if ( row%2 == 0 )
        median = (arrayMarks[row/2] + arrayMarks[(row/2) - 1]) / 2.00;

    // odd number
    else
        median = arrayMarks[(row-1) / 2];
    cout << setprecision(2) << fixed << showpoint;
    return median;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
/**********************************************************************
Programmer    : Hooi Thing Hong
Name          : Mean
Task          : This function will find the average value in the particular column of the data array.
Data in       : Data in the particular row of array, number of data in a row.
Data returned : Average value of particular row of array.
Referred to   : -
**********************************************************************/
double Mean(int* arrayMarks, int size)
{
    double sum = 0;
    for ( int i = 0; i < size; i++)
    {
        sum = sum + arrayMarks[i];
    }
    cout << setprecision(2) << fixed << showpoint;
    return (sum) / (size);
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
/**********************************************************************
Programmer    : Hooi Thing Hong
Name          : Variance
Task          : This function will find the variance in the particular column of the data array.
Data in       : Data in the particular row of array, number of data in a row.
Data returned : Variance of particular row of array.
Referred to   : -
**********************************************************************/
double Variance(int* arrayMarks, int size)
{
    double sum = 0;

    for ( int i = 0; i < size; i++)
    {
        sum = sum + pow(arrayMarks[i] - Mean(arrayMarks, size), 2);
    }
    return (sum) / (size);
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
/**********************************************************************
Programmer    : Hooi Thing Hong
Name          : StandardDeviation
Task          : This function will square root the function the variance in the particular column of the data array.
Data in       : Data in the particular row of array, number of data in a row.
Data returned : Standard Deviation of particular row of array.
Referred to   : -
**********************************************************************/
double StandardDeviation(int* arrayMarks, int size)
{
    cout << setprecision(2) << fixed << showpoint;
    return pow(Variance(arrayMarks, size), 0.5);
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////

void DistinctMarksFrequency(int* arrayMarks, int* arrayID, int row, string subs)
{
    int count;
    SortAscending(arrayMarks, arrayID, row);
    DistinctMarksFrequencyTXT(arrayMarks, row, count, subs);
    DistinctMarksFrequencyHTML(arrayMarks, row, subs);

    cout << "Frequency of Distinct Marks : " << subs << endl;
    cout << string(40, '=') << endl << endl;
    ///// TABLE HEADER /////
    cout << "=========================" << endl;
    cout << "|  Marks  |  Frequency  |" << endl;
    cout << "=========================" << endl;

    for(int i = 0; i < row; i++)
    {
        count = 1;
        for (int j = i+1; j < row; j++)
        {
            if (arrayMarks[i] == arrayMarks[j])
            {
                count++;
                i++;
            }
        }
        cout << "|" << setw(5) << arrayMarks[i] << setw(5) << "|" << setw(7) << count << setw(7) << "|" << endl;
    }
    cout << "=========================" << endl;
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
/**********************************************************************
Programmer    : Hooi Thing Hong
Name          : DistinctMarksFrequencyTXT
Task          : This function will save the output of the DistinctMarksFrequency function in text file.
Data in       : Data in the particular row of array, number of data in a row,
                the frequency of the particular column of the data array, particular column of the header.
Data returned : -
Referred to   : -
**********************************************************************/
void DistinctMarksFrequencyTXT(int* arrayMarks, int row, int count, string subject)
{
    ofstream txtFile;
    txtFile.open("DistinctMarksFrequency_" + subject + ".txt");
    txtFile << "Frequency of Distinct Marks : " << subject <<endl;
    txtFile << string(40, '=') << endl << endl;
    txtFile << "=========================" << endl;
    txtFile << "|  Marks  |  Frequency  |" << endl;
    txtFile << "=========================" << endl;
    for(int i = 0; i < row; i++)
    {
        count = 1;
        for (int j = i+1; j < row; j++)
        {
            if (arrayMarks[i] == arrayMarks[j])
            {
                count++;
                i++;
            }
        }
        txtFile << "|" << setw(5) << arrayMarks[i] << setw(5) << "|" << setw(7) << count << setw(7) << "|" << endl;
    }
    txtFile << "=========================" << endl;
    txtFile.close();
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
void DistinctMarksFrequencyHTML(int* arrayMarks, int row, string subject)
{
    int count;
    ofstream HTMLFile;
    HTMLFile.open("DistinctMarksFrequency_" + subject + ".html");
    HTMLTableHeader(HTMLFile);
    HTMLFile << "<h2 style = 'font-family:Bellota'>  Frequency of Distinct Marks :&nbsp" << subject << "</h2>" << endl << endl;
    HTMLFile << "<table style = 'width:20%; font-family:Bellota;' >" << endl << "  <tr>" << endl << "    <th>Marks</th>" << endl << "    <th>Frequency</th>" << endl << "  </tr>" << endl;
    for(int i = 0; i < row; i++)
    {
        count = 1;
        for (int j = i+1; j < row; j++)
        {
            if (arrayMarks[i] == arrayMarks[j])
            {
                count++;
                i++;
            }
        }
        HTMLFile << "  <tr>" << endl << "    <td>" << arrayMarks[i] << "</td>" << endl << "    <td>" << count << "</td>" << endl << "</tr>" << endl;
    }
    HTMLFile << "</table>" << endl << "</body>" << endl << "</html>";
    HTMLFile.close();
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
void Histogram(int* arrayMarks, int* arrayID, int row, string file, string subject)
{
    int firstsector = 0, secondsector = 0, thirdsector = 0, forthsector = 0, fifthsector = 0;
    SortAscending(arrayMarks, arrayID, row);
    cout << "Histogram : " << subject << endl;
    cout << string(30, '=') << endl << endl;
    for (int i = 0; i < row; i++)
    {
        if(arrayMarks[i]>= 0 && arrayMarks[i] <= 19)
            firstsector++;
        else if (arrayMarks[i]>= 20 && arrayMarks[i] <=39)
            secondsector++;
        else if (arrayMarks[i]>= 40 && arrayMarks[i] <= 59)
            thirdsector++;
        else if (arrayMarks[i]>= 60 && arrayMarks[i] <= 79)
            forthsector++;
        else
            fifthsector++;
    }
    int frequency[5] = {firstsector, secondsector, thirdsector, forthsector, fifthsector};
    int* arrayFreq = frequency;
    printHistogram(Maximum(arrayFreq, 5), firstsector, secondsector, thirdsector, forthsector, fifthsector);
    HistogramTXT(arrayMarks, arrayID, frequency, Maximum(arrayFreq, 5), row, firstsector, secondsector, thirdsector, forthsector, fifthsector, subject);
    HistogramHTML(Maximum(arrayFreq, 5), firstsector, secondsector, thirdsector, forthsector, fifthsector, subject);
    cout << "|---------------------------------------------------------------------------> Marks" << endl;
    cout << "     |0-19|        |20-39|        |40-59|        |60-79|        |80-100|" << endl;
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
void printHistogram(int maxFreq, int firstsector, int secondsector, int thirdsector, int forthsector, int fifthsector)
{
    for (int i = maxFreq; i > 0; i--)
    {
        if (i <= firstsector)
            cout << "       *       ";
        else
            cout << "               ";

        if (i <= secondsector)
            cout << "       *       ";
        else
            cout << "               ";

        if (i <= thirdsector)
            cout << "       *       ";
        else
            cout << "               ";

        if (i <= forthsector)
            cout << "       *       ";
        else
            cout << "               ";

        if (i <= fifthsector)
            cout << "       *       ";
        else
            cout << "               ";
        cout << endl;
    }
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
/**********************************************************************
Programmer    : Hooi Thing Hong
Name          : printHistogramTXT
Task          : This function will save the output of the printHistogram function in text file.
Data in       : ( OFSTREAM TXTFILE ), the maximum frequency of the particular column of the data array,
                the range from 0-19 in the particular column of the data array, the range from 20-39 in the particular column of the data array
                the range from 40-59 in the particular column of the data array, the range from 60-79 in the particular column of the data array
                the range from 80-100 in the particular column of the data array.
Data returned : -
Referred to   : -
**********************************************************************/
void printHistogramTXT(ofstream& txtFile, int maxFreq, int firstsector, int secondsector, int thirdsector, int forthsector, int fifthsector)
{
    for (int i = maxFreq; i > 0; i--)
    {
        if (i <= firstsector)
            txtFile << "       *       ";
        else
            txtFile << "               ";

        if (i <= secondsector)
            txtFile << "       *       ";
        else
            txtFile << "               ";

        if (i <= thirdsector)
            txtFile << "       *       ";
        else
            txtFile << "               ";

        if (i <= forthsector)
            txtFile << "       *       ";
        else
            txtFile << "               ";

        if (i <= fifthsector)
            txtFile << "       *       ";
        else
            txtFile << "               ";
        txtFile << endl;
    }
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
/**********************************************************************
Programmer    : Hooi Thing Hong
Name          : HistogramTXT
Task          : This function will save the output of the Histogram function in text file.
Data in       : Data in the particular row of array, number of data in the row, the frequency of the particular column of the data array,
                the maximum frequency of the particular column of the data array, number of data in the row,
                the range from 0-19 in the particular column of the data array, the range from 20-39 in the particular column of the data array
                the range from 40-59 in the particular column of the data array, the range from 60-79 in the particular column of the data array
                the range from 80-100 in the particular column of the data array, particular column of the header.
Data returned : -
Referred to   : -
**********************************************************************/
void HistogramTXT(int* arrayMarks, int* arrayID, int* arrayFreq, int maxFrequency, int row, int firstsector, int secondsector, int thirdsector, int forthsector, int fifthsector, string subject)
{
    ofstream txtFile;
    txtFile.open("Histogram_" + subject + ".txt");
    txtFile << "Frequency of Distinct Marks : " << subject << endl;
    txtFile << string(40, '=') << endl << endl;
    printHistogramTXT(txtFile, Maximum(arrayFreq, 5), firstsector, secondsector, thirdsector, forthsector, fifthsector);
    txtFile << "|---------------------------------------------------------------------------> Marks" << endl;
    txtFile << "     |0-19|        |20-39|        |40-59|        |60-79|        |80-100|" << endl;
    txtFile.close();
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
void HistogramHTML(double maxFrequency, double firstsector, double secondsector, double thirdsector, double forthsector, double fifthsector, string subject)
{
    double width1 = (firstsector/maxFrequency)*(100.00);
    double width2 = (secondsector/maxFrequency)*(100);
    double width3 = (thirdsector/maxFrequency)*(100);
    double width4 = (forthsector/maxFrequency)*(100);
    double width5 = (fifthsector/maxFrequency)*(100);
    ofstream HTMLFile;
    HTMLFile.open("Histogram_" + subject + ".html");
    HTMLFile << "<!DOCTYPE html>" << endl << "<html>" << endl << "<body>" << endl << "<h1 style = 'font-family:Bellota'> Histogram : " << subject  << "</h1>" << endl << "<h2 style = 'font-family:Bellota'><table style='width:100%;'>" << endl;
    HTMLFile << endl << "<tr>" << endl << "<td style='width:100px;'> | 0-19 |</td>" << endl << "<td><div style = 'background-color: #f9ccac; width:" << width1 << "%'>" << firstsector << "</div> </td> </tr>" << endl;
    HTMLFile << "<tr>" << endl << "<td>| 20-39 |</td>" << endl << "<td><div style = 'background-color: #f9ccac; width:" << width2 << "%'>" << secondsector << "</div> </td> </tr> " << endl;
    HTMLFile << "<tr>" << endl << "<td>| 40-59 |</td>" << endl << "<td><div style = 'background-color: #f9ccac; width:" << width3 << "%'>" << thirdsector << "</div> </td> </tr> " << endl;
    HTMLFile << "<tr>" << endl << "<td>| 60-79 |</td>" << endl << "<td><div style = 'background-color: #f9ccac; width:" << width4 << "%'>" << forthsector << "</div> </td> </tr> " << endl;
    HTMLFile << "<tr>" << endl << "<td>|80-100|</td>" << endl << "<td><div style = 'background-color: #f9ccac; width:" << width5 << "%'>" << fifthsector << "</div> </td> </tr> </h2>" << endl;
    HTMLFile << "</table>" << endl << "</body>" << endl << "</html>" << endl << endl;
    HTMLFile.close();
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
void AboveBelowMean(int SubjectMenu_Num, int row, int col, string file, string subject)
{
    int* arrayMarks1 = arrayInformation(SubjectMenu_Num+1, row, col, file); int* arrayMarks2 = arrayInformation(SubjectMenu_Num+1, row, col, file);
    int* arrayID1 = arrayInformation(0, row, col, file);                    int* arrayID2 = arrayInformation(0, row, col, file);
    int count1 = 0, count2 = 0;
    SortDescending(arrayMarks1, arrayID1, row); SortAscending(arrayMarks2, arrayID2, row);
    AboveBelowMeanHTML(arrayMarks1, arrayMarks2, arrayID1, arrayID2, row, subject);

    cout << "Above/Below Mean : " << subject << endl;
    cout << string(30, '=') << endl << endl;
    cout << "Average Marks: " << Mean(arrayMarks1, row) << endl << endl;
    cout << " Marks Above Mean " << string(30, ' ') << " Marks Below Mean " << endl;
    cout << "=================================" << string(16, ' ') << "=================================" << endl;
    cout << "|        ID        |    Mark    |" << string(16, ' ') << "|        ID        |    Mark    |" << endl;
    cout << "=================================" << string(16, ' ') << "=================================" << endl;

    //above average
    for (int i = 0; i < row; i++)
    {
        if (arrayMarks1[i] != Mean(arrayMarks1, row))
        {
            if (arrayMarks1[i] > Mean(arrayMarks1, row))
            {
                count1++;
                cout << "|" << setw(12) <<  arrayID1[i] << setw(7) << "|" << setw(7) << arrayMarks1[i] << setw(6) << "|";
            }

            else if (i == count1)
                cout << "=================================";

            if (arrayMarks2[i] < Mean(arrayMarks1, row))
            {
                cout << string(16, ' ') << "|" << setw(12) << arrayID2[i] << setw(7) << "|" << setw(7) << arrayMarks2[i] << setw(6) << "|" << endl;
                count2++;
            }

            else if (i == count2)
                cout << string(16, ' ') << "=================================" << endl;
        }

        if (count1 < count2)
        {
            if (i >= count1 && i < count2)
                cout << string(33, ' ');
        }

        else
        {
            if (i > count2 && i < count1)
                cout << endl;
        }
        AboveBelowMeanTXT(arrayMarks1, arrayMarks2, arrayID1, arrayID2, row, count1, count2, subject);
    }
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
/**********************************************************************
Programmer    : Hooi Thing Hong
Name          : AboveBelowMeanTXT
Task          : This function will save the output of the AboveBelowMean function in text file.
Data in       : 4 particular column in the data array, number of data in the row, 2 frequencies of the particular column in the data array
                particular column of the header.
Data returned : -
Referred to   : -
**********************************************************************/
void AboveBelowMeanTXT(int* arrayMarks1, int* arrayMarks2, int* arrayID1, int* arrayID2, int row, int count1, int count2, string subject)
{
    ofstream txtFile;
    txtFile << setprecision(2) << fixed << showpoint;
    txtFile.open("AboveBelowMean_" + (subject) + ".txt");
    txtFile << "Above/Below Mean : " << subject << endl;
    txtFile << string(30, '=') << endl << endl;
    txtFile << "Average Marks: " << Mean(arrayMarks1, row) << endl << endl;
    txtFile << " Marks Above Mean " << string(30, ' ') << " Marks Below Mean " << endl;
    txtFile << "=================================" << string(16, ' ') << "=================================" << endl;
    txtFile << "|        ID        |    Mark    |" << string(16, ' ') << "|        ID        |    Mark    |" << endl;
    txtFile << "=================================" << string(16, ' ') << "=================================" << endl;
    //above average
    for (int i = 0; i < row; i++)
    {
        if (arrayMarks1[i] != Mean(arrayMarks1, row))
        {
            if (arrayMarks1[i] > Mean(arrayMarks1, row))
                txtFile << "|" << setw(12) <<  arrayID1[i] << setw(7) << "|" << setw(7) << arrayMarks1[i] << setw(6) << "|";

            else if (i == count1)
                txtFile << "=================================";

            if (arrayMarks2[i] < Mean(arrayMarks1, row))
                txtFile << string(16, ' ') << "|" << setw(12) << arrayID2[i] << setw(7) << "|" << setw(7) << arrayMarks2[i] << setw(6) << "|" << endl;

            else if (i == count2)
                txtFile << string(16, ' ') << "=================================" << endl;
        }

        if (count1 < count2)
        {
            if (i >= count1 && i < count2)
                txtFile << string(33, ' ');
        }

        else
        {
            if (i > count2 && i < count1)
                txtFile << endl;
        }
    }
    txtFile.close();
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
void AboveBelowMeanHTML(int* arrayMarks1, int* arrayMarks2, int* arrayID1, int* arrayID2, int row, string subject)
{
    int count;
    ofstream HTMLFile;
    HTMLFile << setprecision(2) << fixed << showpoint;
    HTMLFile.open("AboveBelowMean_" + subject + ".html");
    HTMLTableHeader(HTMLFile);
    HTMLFile << "<h2 style = 'font-family:Pasajero'> Above/Below Mean :&nbsp" << subject << "</h2>" << endl << endl;
    HTMLFile << "<h2 style = 'font-family:Pasajero'> Average Marks = " << Mean(arrayMarks1, row) <<"</h2>" <<  endl;
    HTMLFile << "<style>" << endl << "h3 { word-spacing: 700px;} </style>" << endl;
    HTMLFile << "<h3 style = 'font-family:Pasajero'> Above_Mean Below_Mean </h3>" << endl;
    HTMLFile << "<div>" << endl << "<table style ='width:45%; font-family:Bellota; float:left'>" << endl << "  <tr>" << endl << "    <th>ID</th>" << endl << "    <th>Marks</th>" << endl << "  </tr>" << endl;
    for(int i = 0; i < row; i++)
    {
        if (arrayMarks1[i] != Mean(arrayMarks1, row))
        {
            if (arrayMarks1[i] > Mean(arrayMarks1, row))
            {
                HTMLFile << "<tr>" << endl << "    <td>" << arrayID1[i] << "</td>" << endl << "    <td>" << arrayMarks1[i] << "</td>" << endl << "</tr>" << endl;
            }
        }
    }
    HTMLFile << "</table>" << endl << "<table style='width:45%; font-family:Bellota; float:right'>" << endl << "  <tr>" << endl << "    <th>ID</th>" << endl << "    <th>Marks</th>" << endl << "  </tr>" << endl;
    for(int i = 0; i < row; i++)
    {
        if (arrayMarks2[i] != Mean(arrayMarks2, row))
        {
            if (arrayMarks2[i] < Mean(arrayMarks2, row))
            {
                HTMLFile << "<tr>" << endl << "    <td>" << arrayID2[i] << "</td>" << endl << "    <td>" << arrayMarks2[i] << "</td>" << endl << "</tr>" << endl;
            }
        }
    }
    HTMLFile << "</table>" << endl << "</div>" << endl << "</body>" << endl << "</html>";
    HTMLFile.close();
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

// =========================================== COMPARE SUBJECT ============================================ //
/////////////////////////////////////////////////////////////////////////////////////////////
void CompareSubjectsMenu(int row, int col, string header, string file)
{
    ifstream inputFile;
    inputFile.open(file);
    int CompareSubjectsMenu_Num1 = 0, CompareSubjectsMenu_Num2 = 0;

    if (!inputFile)
    {
        cout << "Invalid Data! Please Load Data!" << endl;
        Continue();
        MainMenu(row, col, header, file);
    }

    else
    {
        do
        {
            cout << "___________________________________________________" << endl << endl;
            cout << "    ============= Compare Subjects ============     " << endl;

            subjectList(col, header);
            cout << "                 [" << col-1 << "] - Back To Main Menu" << endl;
            cout << "___________________________________________________" << endl << endl;
            CompareSubjectsChoice1(CompareSubjectsMenu_Num1, CompareSubjectsMenu_Num2, row, col, header, file);
        }
        while(CompareSubjectsMenu_Num1 == col-1 || CompareSubjectsMenu_Num2 == col-1);
    }
        return;
    }
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
void CompareSubjectsChoice1(int inputNum1, int inputNum2, int row, int col, string header, string file)
{
        string num;
        ///// INPUT FIRST SUBJECT /////
        cout << "Please Select The First Subject: ";
        cin >> inputNum1;

        if (inputNum1 == col-1)
        {
            system("CLS");
            MainMenu(row, col, header, file);
        }

        else if (inputNum1 > 0 && inputNum1 < col-1)
        {
            cout << endl;
            CompareSubjectsChoice2(inputNum1, inputNum2, row, col, header, file);
        }

        else if (cin.fail())
        {
            system("CLS");
            cout << "Invalid Subject! Please Try Again!" << endl;
            cin.clear();
            getline(cin, num);
            Continue();
            CompareSubjectsMenu(row, col, header, file);
        }

        else
        {
            system("CLS");
            cout << "Invalid Subject! Please Try Again!" << endl;
            Continue();
            CompareSubjectsMenu(row, col, header, file);
        }
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
void CompareSubjectsChoice2(int inputNum1, int inputNum2, int row, int col, string header, string file)
{
    string num;
    cout << "Please Select The Second Subject: ";
    cin >> inputNum2;
    system("CLS");

    if (inputNum2 == col-1)
    {
        MainMenu(row, col, header, file);
    }

    else if (inputNum2 > 0 && inputNum2 < col-1)
    {
        if (inputNum1 == inputNum2)
        {
            cout << "You have selected two same subjects. Please try again!" << endl;
            Continue();
            CompareSubjectsMenu(row, col, header, file);
        }

        else
        {
            CompareTable(inputNum1, inputNum2, row, col, header, file);
            CompareSubjectsMenu(row, col, header, file);
        }
    }

    else if (cin.fail())
    {
        cout << "Invalid Subject! Please Try Again!" << endl;
        cin.clear();
        getline(cin,num);
        Continue();
        CompareSubjectsMenu(row, col, header, file);
    }

    else
    {
        cout << "Invalid Subject! Please Try Again!" << endl;
        Continue();
        CompareSubjectsMenu(row, col, header, file);
    }
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
double Pearson(int sumofX, int sumofY, int sumofXY, int sumofXSquare, int sumofYSquare, int row)
{
    double P1, P2, P3;
    P1 = (row*sumofXY)-(sumofX*sumofY);
    P2 = (row*sumofXSquare)-(sumofX*sumofX);
    P3 = (row*sumofYSquare)-(sumofY*sumofY);
    return P1 / pow(P2*P3,0.5);
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
double LinearA(int sumofX, int sumofY, int sumofXY, int sumofXSquare, int sumofYSquare, int row)
{
    double a1, a2;
    a1 = (sumofY*sumofXSquare) - (sumofX*sumofXY);
    a2 = (row*sumofXSquare) - (sumofX*sumofX);
    return a1 / a2;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
double LinearB(int sumofX, int sumofY, int sumofXY, int sumofXSquare, int sumofYSquare, int row)
{
    double b1, b2;
    b1 = (row*sumofXY) - (sumofX*sumofY);
    b2 = (row*sumofXSquare) - (sumofX*sumofX);
    return b1 / b2;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
void CompareTable(int CompareSubjectsMenu_Num1, int CompareSubjectsMenu_Num2, int row, int col, string header, string file)
{
    // string has a constructor that takes a const char*
    string subs1(Subject(CompareSubjectsMenu_Num1 + 1, col, header));
    string subs2(Subject(CompareSubjectsMenu_Num2 + 1, col, header));
    int sumofX = 0, sumofY = 0, sumofXY = 0, sumofXSquare = 0, sumofYSquare = 0;
    int* arrayMarks_X = arrayInformation(CompareSubjectsMenu_Num1+1, row, col, file);
    int* arrayMarks_Y = arrayInformation(CompareSubjectsMenu_Num2+1, row, col, file);
    int* arrayID = arrayInformation(0, row, col, file);
    cout << "Compare Subject " << endl;
    cout << string(20, '=') << endl << endl;
    cout << setw(32) << subs1 << " ( X )  VS  " << subs2 << " ( Y )" << endl << endl;

    ///// TABLE HEADER /////
    cout << "===================================================================================" << endl;
    cout << "|       ID       |     X     |     Y     |     XY     |     X^2     |     Y^2     |" << endl;
    cout << "===================================================================================" << endl;

    for ( int i = 0; i < row; i++)
    {
        ///// CALCULATE SUM OF EACH CALCULATION /////
        sumofX = sumofX + arrayMarks_X[i]; sumofY = sumofY + arrayMarks_Y[i]; sumofXY = sumofXY+ (arrayMarks_X[i]*arrayMarks_Y[i]);
        sumofXSquare = sumofXSquare + pow(arrayMarks_X[i],2); sumofYSquare = sumofYSquare + pow(arrayMarks_Y[i],2);

        ///// TABLE CONTENT ///////
        cout << "|" << setw(12) << arrayID[i] << setw(5) << "|" << setw(6) << arrayMarks_X[i]<< setw(6) << "|" << setw(6) << arrayMarks_Y[i] << setw(6) << "|" << setw(8) << arrayMarks_X[i]*arrayMarks_Y[i] << setw(5) << "|" << setw(8) << arrayMarks_X[i]*arrayMarks_X[i] << setw(6) << "|" << setw(8) << arrayMarks_Y[i]*arrayMarks_Y[i] << setw(6) << "|" << endl;
        }

    ///// TOTAL PRINT INSIDE TABLE /////
    cout << "===================================================================================" << endl;
    cout << "|    Total =     |" << setw(7) << sumofX << setw(5) << "|" << setw(7) << sumofY << setw(5) << "|" << setw(9) << sumofXY << setw(4) << "|" << setw(9) << sumofXSquare << setw(5) << "|" << setw(9) << sumofYSquare << setw(5) << "|" << endl;
    cout << "===================================================================================" << endl << endl;
    PrintPearsonLinearCalculation(sumofX, sumofY, sumofXY, sumofXSquare, sumofYSquare,row);
    CompareSubjectsTXT(arrayMarks_X, arrayMarks_Y, arrayID, sumofX, sumofY, sumofXY, sumofXSquare, sumofYSquare, row, subs1, subs2);
    CompareSubjectsHTML(arrayMarks_X, arrayMarks_Y, arrayID, sumofX, sumofY, sumofXY, sumofXSquare, sumofYSquare, row, subs1, subs2);
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
void PrintPearsonLinearCalculation(int sumofX, int sumofY, int sumofXY, int sumofXSquare, int sumofYSquare, int row)
{
     ///// PRINT PEARSON CALCULATION /////
    cout << setprecision(6) << fixed << showpoint;
    cout << "1 . Pearson's Correlation" << endl << endl;
    cout << "    r = (" << row << "*" << sumofXY << "-" << sumofX << "*" << sumofY << ")" << " / sqrt(("
         << row << "*" << sumofXSquare << " - " << sumofX << "*" << sumofX << ") * (" << row << "*" << sumofYSquare << " - " << sumofY << "*" << sumofY << "))"<< endl;
    cout << "      = " << Pearson(sumofX, sumofY, sumofXY, sumofXSquare, sumofYSquare, row) << endl << endl;

    ///// PRINT LINEAR CALCULATION /////
    cout << "2 . Linear Regression" << endl << endl;
    cout << "    a = (" << sumofY << "*" << sumofXSquare << " - " << sumofX << "*" << sumofXY << ") / (" << row << "*" << sumofXSquare << " - " << sumofX << "*" << sumofX << ")" << endl;
    cout << "      = " << LinearA(sumofX, sumofY, sumofXY, sumofXSquare, sumofYSquare, row) << endl;
    cout << "    b = (" << row << "*" << sumofXY << " - " << sumofX << "*" << sumofY << ") / (" << row << "*" << sumofXSquare << " - " << sumofX << "*" << sumofX << ")" << endl;
    cout << "      = " << LinearB(sumofX, sumofY, sumofXY, sumofXSquare, sumofYSquare, row) << endl << endl;
    cout << "    y'= " << LinearA(sumofX, sumofY, sumofXY, sumofXSquare, sumofYSquare, row) << " + " << LinearB(sumofX, sumofY, sumofXY, sumofXSquare, sumofYSquare, row) << "x" << endl << endl;
    Continue();
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
/**********************************************************************
Programmer    : Hooi Thing Hong
Name          : CompareSubjectsTXT
Task          : This function will save the output of the CompareTable function in text file.
Data in       : 3 particular data column in the data array, sum of the 2 seperates particular data column in the data array,
                total sum of the 2 selected column of data in the data array, square of 2 seperate particular column data in the data array,
                number of row in the data, 2 particular column of the header.
Data returned : -
Referred to   : -
**********************************************************************/
void CompareSubjectsTXT(int* arrayMarks_X, int* arrayMarks_Y, int* arrayID, int sumofX, int sumofY, int sumofXY, int sumofXSquare, int sumofYSquare, int row, string subject1, string subject2)
{
    ofstream txtFile;
    txtFile.open("CompareSubjects_" + (subject1) + " vs " + (subject2) + ".txt");
    txtFile << "Compare Subject " << endl;
    txtFile << string(20, '=') << endl << endl;
    txtFile << setw(32) << subject1 << " ( X )  VS  " << subject2 << " ( Y )" << endl << endl;
    txtFile << "----------------------------------------------------------------------------------" << endl;
    txtFile << "|    STUDENT    |     X     |     Y     |     XY     |     X^2     |     Y^2     |" << endl;
    txtFile << "----------------------------------------------------------------------------------" << endl;
    for ( int i = 0; i < row; i++)
    {
        txtFile << "|" << setw(12) << arrayID[i] << setw(4) << "|" << setw(6) << arrayMarks_X[i]<< setw(6) << "|" << setw(6) << arrayMarks_Y[i] << setw(6) << "|" << setw(8) << arrayMarks_X[i]*arrayMarks_Y[i]
                << setw(5) << "|" << setw(8) << arrayMarks_X[i]*arrayMarks_X[i] << setw(6) << "|" << setw(8) << arrayMarks_Y[i]*arrayMarks_Y[i] << setw(6) << "|" << endl;
    }
    txtFile << "==================================================================================" << endl;
    txtFile << "|    Total =    |" << setw(7) << sumofX << setw(5) << "|" << setw(7) << sumofY << setw(5) << "|" << setw(9) << sumofXY << setw(4) << "|" << setw(9) << sumofXSquare << setw(5) << "|" << setw(9) << sumofYSquare << setw(5) << "|" << endl;
    txtFile << "==================================================================================" << endl << endl;
    //Print  Pearson's calculation
    txtFile << setprecision(6) << fixed << showpoint;
    txtFile << "1 . Pearson's Correlation" << endl << endl;
    txtFile << "    r = (" << row << "*" << sumofXY << "-" << sumofX << "*" << sumofY << ")" << " / sqrt((" << row << "*" << sumofXSquare << " - " << sumofX << "*" << sumofX << ") * (" << row << "*" << sumofYSquare << " - " << sumofY << "*" << sumofY << "))"<< endl;
    txtFile << "      = " << Pearson(sumofX, sumofY, sumofXY, sumofXSquare, sumofYSquare, row) << endl << endl;

    ///// PRINT LINEAR CALCULATION /////
    txtFile << "2 . Linear Regression" << endl << endl;
    txtFile << "    a = (" << sumofY << "*" << sumofXSquare << " - " << sumofX << "*" << sumofXY << ") / (" << row << "*" << sumofXSquare << " - " << sumofX << "*" << sumofX << ")" << endl;
    txtFile << "      = " << LinearA(sumofX, sumofY, sumofXY, sumofXSquare, sumofYSquare, row) << endl;
    txtFile << "    b = (" << row << "*" << sumofXY << " - " << sumofX << "*" << sumofY << ") / (" << row << "*" << sumofXSquare << " - " << sumofX << "*" << sumofX << ")" << endl;
    txtFile << "      = " << LinearB(sumofX, sumofY, sumofXY, sumofXSquare, sumofYSquare, row) << endl << endl;
    txtFile << "    y'= " << LinearA(sumofX, sumofY, sumofXY, sumofXSquare, sumofYSquare, row) << " + " << LinearB(sumofX, sumofY, sumofXY, sumofXSquare, sumofYSquare, row) << "x" << endl << endl;
    txtFile.close();
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
void CompareSubjectsHTML(int* arrayMarks_X, int* arrayMarks_Y, int* arrayID, int sumofX, int sumofY, int sumofXY, int sumofXSquare, int sumofYSquare, int row, string subject1, string subject2)
{
    ofstream HTMLFile;
    HTMLFile.open("CompareSubjects_" + (subject1) + " vs " + (subject2) + ".html");
    HTMLTableHeader(HTMLFile);
    HTMLFile << "<h2 style = 'font-family:Pasajero'> Compare Subjects </h2>" << endl << endl;
    HTMLFile << "<h3 style = 'font-family:Pasajero'> <span style=""padding-right:340px;""></span>" << subject1 << " ( X ) VS " << subject2 << " ( Y ) </h3>" << endl;
    HTMLFile << "<table style = 'width:60%; font-family:Bellota;'>" << endl << "  <tr>" << endl << "    <th>Student</th>" << endl << "    <th>X</th>" << endl << "    <th>Y</th>" << endl
           << "    <th>XY</th>" << endl << "    <th>X^2</th>" << endl <<"    <th>Y^2</th>" << endl <<"  </tr>" << endl;
    for(int i = 0; i < row; i++)
    {
        HTMLFile << "  <tr>" << endl << "    <td>" << arrayID[i] << "</td>" << endl << "    <td>" << arrayMarks_X[i] << "</td>" << endl;
        HTMLFile << "    <td>" << arrayMarks_Y[i] << "</td>" << endl << "    <td>" << arrayMarks_X[i]*arrayMarks_Y[i] << "</td>" << endl;
        HTMLFile << "    <td>" << arrayMarks_X[i]*arrayMarks_X[i] << "</td>" << endl << "    <td>" << arrayMarks_Y[i]*arrayMarks_Y[i] << "</td>" << endl << "</tr>" << endl;
    }
    HTMLFile << "  <tr style = 'font-weight: bold;'>" << endl << "    <td> Total = </td>" << endl << "<td>" << sumofX << "</td>" << endl;
    HTMLFile << "    <td>" << sumofY << "</td>" << endl << "<td>" << sumofXY<< "</td>" << endl;
    HTMLFile << "    <td>" << sumofXSquare<< "</td>" << endl << "<td>" << sumofYSquare << "</td>" << endl << "</tr>" << endl << "</table>" << endl;
    ///// PEARSON CALCULATION /////
    HTMLFile << "<h3 style = 'font-family:Pasajero'> 1. Pearson's Correlation </h3>" << endl;
    HTMLFile << "<p style = 'font-family:Pasajero'> r &nbsp= (" << row << "*" << sumofXY << "-" << sumofX << "*" << sumofY << ")" << " / sqrt((" << row << "*" << sumofXSquare
           << " - " << sumofX << "*" << sumofX << ") * (" << row << "*" << sumofYSquare << " - " << sumofY << "*" << sumofY << ")) </p>" << endl;
    HTMLFile << "<p style = 'font-family:Pasajero'>&nbsp&nbsp&nbsp&nbsp= " << Pearson(sumofX, sumofY, sumofXY, sumofXSquare, sumofYSquare, row) << "</p> <br>" << endl;
    ///// LINEAR CALCULATION /////
    HTMLFile << "<h3 style = 'font-family:Pasajero'> 2. Linear Regression </h3>" << endl;;
    HTMLFile << "<p style = 'font-family:Pasajero'> a &nbsp= (" << sumofY << "*" << sumofXSquare << " - " << sumofX << "*" << sumofXY << ") / ("
           << row << "*" << sumofXSquare << " - " << sumofX << "*" << sumofX << ")" << endl;
    HTMLFile << "<p style = 'font-family:Pasajero'>&nbsp&nbsp&nbsp&nbsp= " << LinearA(sumofX, sumofY, sumofXY, sumofXSquare, sumofYSquare, row) << "</p>" << endl;
    HTMLFile << "<p style = 'font-family:Pasajero'> b &nbsp= (" << "(" << row << "*" << sumofXY << " - " << sumofX << "*" << sumofY << ") / ("
           << row << "*" << sumofXSquare << " - " << sumofX << "*" << sumofX << ")" << endl;
    HTMLFile << "<p style = 'font-family:Pasajero'>&nbsp&nbsp&nbsp&nbsp= " << LinearB(sumofX, sumofY, sumofXY, sumofXSquare, sumofYSquare, row) << "</p>" << endl;
    HTMLFile << "<P style = 'font-family:Pasajero'> y'&nbsp= " << LinearA(sumofX, sumofY, sumofXY, sumofXSquare, sumofYSquare, row) << " + "
           << LinearB(sumofX, sumofY, sumofXY, sumofXSquare, sumofYSquare, row) << "x" << endl;
    HTMLFile << "</table>" << endl << "</body>" << endl << "</html>";
    HTMLFile.close();
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

// =========================================== SORT DATA ============================================ //
/////////////////////////////////////////////////////////////////////////////////////////////
void SortDataMenu(int row, int col, string header, string file)
{
    int SortDataMenu_Num = 0;
    string num;
    ifstream inputFile;
    inputFile.open(file);

    if (!inputFile)
    {
        cout << "Invalid Data! Please Load Data!" << endl;
        Continue();
        MainMenu(row, col, header, file);
    }

    else
    {
        do
        {
            cout << "____________________________________________________" << endl;
            cout << "|                                                  |" << endl;
            cout << "|    =============== Sort Data ===============     |" << endl;
            cout << "|          Ascending Order --------- [1]           |" << endl;
            cout << "|          Descending Order -------- [2]           |" << endl;
            cout << "|          Back to Main Menu ------- [3]           |" << endl;
            cout << "|__________________________________________________|" << endl << endl;
            cout << " Please Enter Your Desire Number. " << endl;
            cin >> SortDataMenu_Num;
            system("CLS");

            if (SortDataMenu_Num > 0 && SortDataMenu_Num < 3)
                SortDataSubjectsMenu(SortDataMenu_Num, row, col, header, file);

            else if (SortDataMenu_Num == 3)
                    MainMenu(row, col, header, file);

            else if (cin.fail())
            {
                cout << "Invalid Input! Please Try Again!" << endl;
                cin.clear();
                getline(cin, num);
                Continue();
            }

            else
            {
                cout << "Invalid Input! Please Try Again!" << endl;
                Continue();
            }
        }
        while(SortDataMenu_Num != 3);
    }
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
void SortDataSubjectsMenu(int SortDataMenu_Num, int row, int col, string header, string file)
{
    int SortDataSubjectsMenu_Num = 0;
    string num;

    do
    {
        cout << "___________________________________________________" << endl << endl;
        cout << "    ================ Sort Data ================     " << endl;

        subjectList(col, header);
        cout << "                 [" << col-1 << "] - Back To Sort Data Menu" << endl;
        cout << "___________________________________________________" << endl << endl;
        cout << " Please Select A Subject." << endl;
        cin >> SortDataSubjectsMenu_Num;
        system("CLS");

        if(SortDataSubjectsMenu_Num > 0 && SortDataSubjectsMenu_Num < col-1)
        {
            AscendDescend(SortDataMenu_Num, SortDataSubjectsMenu_Num, row, col, header, file);
            Continue();
        }

        else if (SortDataSubjectsMenu_Num == col-1)
            SortDataMenu(row, col, header, file);

        else if (cin.fail())
        {
            cout << "Invalid Input! Please Try Again!" << endl;
            cin.clear();
            getline(cin, num);
            Continue();
        }

        else
        {
            cout << "Invalid Input! Please Try Again!" << endl;
            Continue();
        }
    }
    while(SortDataSubjectsMenu_Num != col-1);
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
void AscendDescend(int SortDataMenu_Num, int SortSubjectsMenu_Num, int row, int col, string header, string file)
{
    int* arrayMarks = arrayInformation(SortSubjectsMenu_Num+1, row, col, file);
    int* arrayID = arrayInformation(0, row, col, file);
    ofstream txtFile; ofstream HTMLFile;
    // string has a constructor that takes a const char*
    string subs(Subject(SortSubjectsMenu_Num + 1, col, header));

    if (SortDataMenu_Num == 1)
        cout << "Sort Marks Ascending : " << subs << endl;
    else
        cout << "Sort Marks Descending : " << subs << endl;
    cout << string(30, '=') << endl << endl;

    ///// PRINT HEADER /////
    cout << "-------------------------------------" << endl;
    cout << "|         ID          |    Marks    |" << endl;
    cout << "-------------------------------------" << endl;

    ///// PRINT THE ID AND MARKS /////
    for(int i = 0; i < row; i++)
    {
        if (SortDataMenu_Num == 1)
        {
            SortAscending(arrayMarks, arrayID, row);
            cout << "|" << setw(15) << arrayID[i] << setw(7) << "|" << setw(8) << arrayMarks[i] << setw(6) << "|" << endl;
            txtFile.open("SortAscending_" + (subs) + ".txt");
            HTMLFile.open("SortAscending_" + (subs) + ".html");
            SortDataTXT(txtFile, arrayMarks, arrayID, SortDataMenu_Num, row, subs);
            SortDataHTML(HTMLFile, arrayMarks, arrayID, SortDataMenu_Num, row, subs);
        }

        else if (SortDataMenu_Num == 2)
        {
            SortDescending(arrayMarks, arrayID, row);
            cout << "|" << setw(15) << arrayID[i] << setw(7) << "|" << setw(8) << arrayMarks[i] << setw(6) << "|" << endl;
            txtFile.open("SortDescending_" + (subs) + ".txt");
            HTMLFile.open("SortDescending_" + (subs) + ".html");
            SortDataTXT(txtFile, arrayMarks, arrayID, SortDataMenu_Num, row, subs);
            SortDataHTML(HTMLFile, arrayMarks, arrayID, SortDataMenu_Num, row, subs);
        }
    }
    txtFile.close(); HTMLFile.close();
    cout << "-------------------------------------" << endl;

    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
/**********************************************************************
Programmer    : Hooi Thing Hong
Name          : SortDataTXT
Task          : This function will save the output of the AscendDescend function in text file.
Data in       : (OFSTREAM txtFILE), 2 types of data in the particular column of the data array,
                user's input number in the SortDataSubjectsMenu, number of row of the data, particular column of the header.
Data returned : -
Referred to   : -
**********************************************************************/
void SortDataTXT(ofstream& txtFile, int* arrayMarks, int* arrayID, int inputNum, int row, string subject)
{
    if (inputNum == 1)
    {
        txtFile << "Sort Marks Ascending : " << subject << endl;
    }
    else
    {
        txtFile << "Sort Marks Descending : " << subject << endl;
    }
    txtFile << string(30, '=') << endl << endl;
    txtFile << "-------------------------------------" << endl;
    txtFile << "|         ID          |    Marks    |" << endl;
    txtFile << "-------------------------------------" << endl;

    for(int i = 0; i < row; i++)
    {
        txtFile << "|" << setw(15) << arrayID[i] << setw(7) << "|" << setw(8) << arrayMarks[i] << setw(6) << "|" << endl;
    }
    txtFile << "-------------------------------------" << endl << endl;
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
void SortDataHTML(ofstream &HTMLFile, int* arrayMarks, int* arrayID, int inputNum, int row, string subject)
{
    HTMLTableHeader(HTMLFile);
    if (inputNum == 1)
    {
        HTMLFile << "<h2 style = 'font-family:Pasajero'> Sort Data Ascending :&nbsp" << subject << "</h2>" << endl << endl;
    }
    else
    {
        HTMLFile << "<h2 style = 'font-family:Pasajero' > Sort Data Descending :&nbsp"<< subject << "</h2>" << endl << endl;
    }
    HTMLFile << "<table style = 'width:40%; font-family:Bellota;'>" << endl << "  <tr>" << endl << "    <th>ID</th>" << endl << "    <th>Marks</th>" << endl << "  </tr>" << endl;
    for(int i = 0; i < row; i++)
    {
        HTMLFile << "  <tr>" << endl << "    <td>" << arrayID[i] << "</td>" << endl << "    <td>" << arrayMarks[i] << "</td>" << endl << "</tr>" << endl;
    }
    HTMLFile << "</table>" << endl << "</body>" << endl << "</html>";
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

// ======================================== ACADEMIC REPORT =========================================== //
/////////////////////////////////////////////////////////////////////////////////////////////
void AcademicReportMenu(int row, int col, string header, string file)
{
    int AcademicReportMenu_Num = 0;
    ifstream inputFile;
    inputFile.open(file);

    if (!inputFile)
    {
        cout << "Invalid Data! Please Load Data!" << endl;
        Continue();
        MainMenu(row, col, header, file);
    }

    else
    do
    {
        cout << "___________________________________________________" << endl << endl;
        cout << "    ============= Academic Report =============     " << endl;

        subjectList(col, header);
        cout << "                 [" << col-1 << "] - Back To Main Menu" << endl;
        cout << "___________________________________________________" << endl << endl;
        cout << " Please Select A Subject." << endl;
        AcademicReportMenuChoice(AcademicReportMenu_Num, row, col, header, file );

    }
    while(AcademicReportMenu_Num != col-1);

    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
void AcademicReportMenuChoice(int inputNum, int row, int col, string header, string file)
{
    string num;
    cin >> inputNum;
    system("CLS");

    if(inputNum > 0 && inputNum < col-1)
    {
        AcademicReport(inputNum, row, col, header, file);
        Continue();
    }

    else if (inputNum == col-1)
        MainMenu(row, col, header, file);
    else if (cin.fail())
    {
        cout << "Invalid Input! Please Try Again!" << endl;
        cin.clear();
        getline(cin,num);
        Continue();
    }

    else
    {
        cout << "Invalid Input! Please Try Again!" << endl;
        Continue();
    }
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
void AcademicReport(int AcademicReportMenu_Num, int row, int col, string header, string file)
{
    int* arrayMarks = arrayInformation(AcademicReportMenu_Num+1, row, col, file);
    int* arrayID = arrayInformation(0, row, col, file);
    string subs(Subject(AcademicReportMenu_Num + 1, col, header));
    cout << "Academic Report : " << subs << endl;
    cout << string(32, '=') << endl << endl;
    cout << "Statistics" << string(18, ' ') << endl;
    cout << "===================================================================================================================" << endl;
    cout << "|     Minimum     |     Maximum     |     Median     |     Mean     |     Variance     |    Standard Deviation    |" << endl;
    cout << "===================================================================================================================" << endl;
    cout << "|" << setw(9) << Minimum(arrayMarks, row) << setw(9) << "|" << setw(9) << Maximum(arrayMarks, row) << setw(9) << "|"
         << setw(10) <<  Median(arrayMarks, arrayID, row) << setw(7) << "|" << setw(9) << Mean(arrayMarks, row) << setw(6) << "|"
         << setw(12) <<  Variance(arrayMarks, row) << setw(7) << "|" << setw(15) << StandardDeviation(arrayMarks, row) << setw(12) << "|" << endl;
    cout << "===================================================================================================================" << endl << endl;
    SaveAcademicReportMenu(arrayMarks, arrayID, AcademicReportMenu_Num, row, col, header, file, subs);
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
void SaveAcademicReportMenu(int* arrayMarks, int* arrayID, int AcademicReportMenu_Num, int row, int col, string header, string file, string subject)
{
    int SaveAcademicReportMenu_Num = 0; string num;
    do
    {
        cout << "=========================================================" << endl;
        cout << "|           Do you want to save this report?            |" << endl;
        cout << "|          YES  -------------------------- [1]          |" << endl;
        cout << "|           NO  -------------------------- [2]          |" << endl;
        cout << "=========================================================" << endl;
        cout << "Please Select Your Choice." << endl;
        cin >> SaveAcademicReportMenu_Num;
        system("CLS");

        if (SaveAcademicReportMenu_Num == 1)
        {
            AcademicReportTXT(arrayMarks, arrayID, row, subject);
            AcademicReportHTML(arrayMarks, arrayID, row, subject);
            cout << "Your File Already Save Successfully." << endl;
            Continue();
            AcademicReportMenu(row, col, header, file);
        }

        else if (SaveAcademicReportMenu_Num == 2)
        {
            AcademicReportMenu(row, col, header, file);
        }

        else if (cin.fail())
        {
            cout << "Invalid Input! Please Try Again!" << endl;
            cin.clear();
            getline(cin,num);
            Continue();
            AcademicReport(AcademicReportMenu_Num, row, col, header, file);
        }

        else
        {
            cout << "Invalid Input! Please Try Again!" << endl;
            Continue();
            AcademicReport(AcademicReportMenu_Num, row, col, header, file);
        }

    }
    while(SaveAcademicReportMenu_Num != 2);
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
/**********************************************************************
Programmer    : Hooi Thing Hong
Name          : AcademicReportTXT
Task          : This function will save the output of the AcademicReport function in text file.
Data in       : 2 types of data in the particular row of data in the array, number of data in the row, particular column of the header.
Data returned : -
Referred to   : -
**********************************************************************/
void AcademicReportTXT(int* arrayMarks, int* arrayID, int row, string subject)
{
    ofstream txtFile;
    txtFile.open("AcademicReport_" + subject + ".txt");
    txtFile << "Academic Report : " << subject << endl;
    txtFile << setprecision(2) << fixed << showpoint;
    txtFile << string(32, '=') << endl << endl;
    txtFile << "Statistics" << string(18, ' ') << endl;
    txtFile << "===================================================================================================================" << endl;
    txtFile << "|     Minimum     |     Maximum     |     Median     |     Mean     |     Variance     |    Standard Deviation    |" << endl;
    txtFile << "===================================================================================================================" << endl;
    txtFile << "|" << setw(9) << Minimum(arrayMarks, row) << setw(9) << "|" << setw(9) << Maximum(arrayMarks, row) << setw(9) << "|"
            << setw(10) <<  Median(arrayMarks, arrayID, row) << setw(7) << "|" << setw(9) << Mean(arrayMarks, row) << setw(6) << "|"
            << setw(12) <<  Variance(arrayMarks, row) << setw(7) << "|" << setw(15) << StandardDeviation(arrayMarks, row) << setw(12) << "|" << endl;
    txtFile << "===================================================================================================================" << endl << endl;
    txtFile.close();
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
/**********************************************************************
Programmer    : Hooi Thing Hong
Name          : AcademicReportHTML
Task          : This function will save the output of the AcademicReport function in html file.
Data in       : 2 types of data in the particular row of data in the array, number of data in the row, particular column of the header.
Data returned : -
Referred to   : -
**********************************************************************/
void AcademicReportHTML(int* arrayMarks, int* arrayID, int row, string subject)
{
    ofstream HTMLFile;
    HTMLFile.open("AcademicReport_" + subject + ".html");
    HTMLTableHeader(HTMLFile);
    HTMLFile << setprecision(2) << fixed << showpoint;
    HTMLFile << "<h2 style = 'font-family:Bellota'>  Academic Report :&nbsp" << subject << "</h2><br>" << endl << endl;
    HTMLFile << "<h2 style = 'font-family:Bellota'>  Statistics </h2> ";
    HTMLFile << "<table style = 'width:70%; font-family:Bellota;' >" << endl << "  <tr>" << endl << "    <th>Minimum</th>" << endl << "    <th>Maximum</th>" << endl
             << endl << "    <th>Median</th>" << endl << "    <th>Mean</th>" << endl << "    <th>Variance</th>" << endl << "    <th>Standard Deviation</th>" << endl<< "  </tr>" << endl;
    HTMLFile << "  <tr>" << endl << "    <td>" <<  Minimum(arrayMarks, row) << "</td>" << endl << "    <td>" << Maximum(arrayMarks, row) << "</td>" << endl
             << "    <td>" <<  Median(arrayMarks, arrayID, row) << "</td>" << endl << "    <td>" << Mean(arrayMarks, row) << "</td>" << endl
             << "    <td>" << Variance(arrayMarks, row) << "</td>" << endl << "    <td>" << StandardDeviation(arrayMarks, row) << "</td>" << endl << "</tr>" << endl;
    HTMLFile << "</table>" << endl << "</body>" << endl << "</html>";
    HTMLFile.close();
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

// =========================================== EXTRAS =============================================== //
/////////////////////////////////////////////////////////////////////////////////////////////
void Continue()
{
    system("pause");
    system("CLS");
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
void HTMLTableHeader(ofstream &HTMLFile)
{
    HTMLFile << "<!DOCTYPE html>" << endl << "<html>" << endl <<"<head>" << endl << "<style>" << endl;
    HTMLFile << "table, th, td {" << endl << "  border: 3px double black;" << endl << "  border-collapse: collapse;" << endl << "}" << endl;
    HTMLFile << "th, td{" << endl << "padding; 15px;" << endl << "text-align: center;" << endl << "}" << endl;
    HTMLFile << " tr:nth-child(even) {" << endl << "background-color:#fbefcc;}" << endl;
    HTMLFile << " tr:nth-child(odd) {" << endl << "background-color: #f9ccac;}" << endl;
    HTMLFile << " th {" << endl << " background-color: #a2836e;" << endl << "color: white;}" << endl;
    HTMLFile << "</style>" << endl << "</head>" << endl << "<body>" << endl << endl;
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

