#include <iostream>
#include <fstream>
#include <cmath>
#include <iomanip>
#include <string>
#include <stdlib.h>
#include <bits/stdc++.h>

using namespace std;

////// MENU //////
void MainMenu();
void subjectList();
void SubjectMenu();
void StatisticsMenu();
void CompareSubjectsMenu();
void LoadData();

////// STATISTICS //////
int Minimum();
int Maximum();
double Median();
double Mean();
double Variance();
double StandardDeviation();
void DistinctNumberFrequency();
void Histogram();
void AboveBelowMean();
void PrintHistogram(int frequency);

////// COMPARE SUBJECTS //////
void CompareSubjectsChoice();
void CompareTable();
double Pearson(int, int, int, int, int);
double LinearA(int, int, int, int, int);
double LinearB(int, int, int, int, int);

////// SORT DATA /////
void SortDataMenu();
void SortSubjectsMenu();
void AscendDescend();

void Continue();

//GLOBAL VARIABLE
string file, header;
int row = 0, col = 0;
int MainMenu_Num, SubjectMenu_Num, StatisticsMenu_Num,CompareSubjectsMenu_num1, CompareSubjectsMenu_num2, SortDataMenu_Num, SortSubjectsMenu_Num;

int main()
{
    cout << " -------------------------------------------------------" << endl;
    cout << "    Welcome To Academic Information And Report System " << endl;
    cout << " -------------------------------------------------------" << endl;
    Continue();

    do
    {
        MainMenu();
    }
    while (MainMenu_Num != 6);

return 0;
}

/////////////////////////////////////////////////////////////////////////////////////////////
void MainMenu()
{
    bool charError;
    string num;

    cout << "_____________________________________________________________" << endl;
    cout << "|                                                           |" << endl;
    cout << "|    ==================== Main Menu ====================    |" << endl;
    cout << "|        Load Data ----------------------------- [1]        |" << endl;
    cout << "|        Subjects ------------------------------ [2]        |" << endl;
    cout << "|        Compare Subjects ---------------------- [3]        |" << endl;
    cout << "|        Sort of Data -------------------------- [4]        |" << endl;
    cout << "|        Academic Report ----------------------- [5]        |" << endl;
    cout << "|        EXIT ---------------------------------- [6]        |" << endl;
    cout << "|___________________________________________________________|" << endl << endl;
    cout << " Please Enter Your Desire Number. " << endl;
    cin >> MainMenu_Num;
    cin.ignore();
    system("CLS");

    charError = cin.fail();

    if (MainMenu_Num == 1)
        LoadData();

    else if (MainMenu_Num == 2)
        SubjectMenu();

    else if (MainMenu_Num == 3)
        CompareSubjectsMenu();

    else if (MainMenu_Num == 4)
        SortDataMenu();
/*
    else if (MainMenu_Num == 5)
*/

    else if (MainMenu_Num == 6)
    {
        cout << "Thanks for using our system! Hope to see you again." << endl;
        exit(0);
    }

    else if (charError)
    {
        cin.clear();
        getline(cin, num);
        cout << "Invalid Input! Please Try Again!" << endl;
        Continue();
        MainMenu();
    }

    else
        cout << "Invalid Input! Please Try Again!" << endl;
        Continue();
        MainMenu();

    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
void LoadData()
{
    cout << "Enter File Name : ";
    cin >> file;
    system("CLS");

    ifstream inputFile;
    inputFile.open(file);

    if (!inputFile)
    {
        while (!inputFile)
        {
            cout << "Error: file could not be opened. Please Try Again!"<< endl;
            cout << "Enter File Name : ";
            cin >> file;
            system("CLS");
            inputFile.open(file);

            if (!inputFile)
                cout << "";
            else
                cout << "Your file has been loaded successfully." << endl;
        }
    }

    else
        cout << "Your file has been loaded successfully." << endl;
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
int* arrayInformation(int inputNum)
{
    ifstream inputFile;
    inputFile.open(file);
    inputFile >> col >> header >> row;
    int* marks = new int[row];
    int detail;

    int arrayDetail[row][col];

    for ( int i = 0; i < row; i++)
    {
        for ( int j = 0; j < col; j++)
        {
            inputFile >> detail;
            inputFile.ignore(1,',');
            arrayDetail[i][j] = detail;
        }
        marks[i] = arrayDetail[i][inputNum];
    }

    return marks;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
void subjectList()
{
        ifstream inputFile;
        inputFile.open(file);
        inputFile >> col >> header >> row;

        int n = header.size();
        char arrayHeader[n];
        char* headerPointer;

        strcpy(arrayHeader, header.c_str());
        headerPointer = strtok(arrayHeader, ",");

        for (int i = 1; i < col+1; i++)
        {
            if (headerPointer != NULL)
            {
                strcpy(arrayHeader, headerPointer);
                headerPointer = strtok (NULL, ",");

                if (i >= 3)
                    cout << "                 [" << i-2 << "] - " << arrayHeader << endl;
            }
        }
        return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
void SubjectMenu()
{
    bool charError;
    string num;
    ifstream inputFile;
    inputFile.open(file);

    if (!inputFile)
    {
        cout << "Invalid Data! Please Load Data!" << endl;
        Continue();
        MainMenu();
    }

    else
    {
        cout << "___________________________________________________" << endl << endl;
        cout << "    ================= Subjects ================     " << endl;

        subjectList();
        cout << "                 [" << col-1 << "] - Back To Main Menu" << endl;
        cout << "___________________________________________________" << endl << endl;
        cout << " Please Select A Subject. " << endl;
        cin >> SubjectMenu_Num;
        cin.ignore();
        system("CLS");

        // TO CHECK THE INPUT IS WHETHER include CHARACTER
        charError = cin.fail();

        if (SubjectMenu_Num > 0 && SubjectMenu_Num < col-1)
            do
            {
                StatisticsMenu();
            }
            while(StatisticsMenu_Num != 10);

        else if (SubjectMenu_Num == col-1)
                MainMenu();

        else if (charError)
        {
            cin.clear();
            getline(cin, num);
            cout << "Invalid Input! Please Try Again!" << endl;
            Continue();
            SubjectMenu();
        }

        else
            cout << "Invalid Input! Please Try Again!" << endl;
            Continue();
            SubjectMenu();
    }
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
void StatisticsMenu()
{
    int n = header.size();
    char arrayHeader[n];
    char* headerPointer;
    bool charError;
    string num;

    cout << "_________________________________________________________________" << endl;
    cout << "|                                                               |" << endl;
    cout << "|    ===================== Statistics =====================     |" << endl;
    cout << "|          Minimum mark -------------------------- [1]          |" << endl;
    cout << "|          Maximum mark -------------------------- [2]          |" << endl;
    cout << "|          Median -------------------------------- [3]          |" << endl;
    cout << "|          Mean ---------------------------------- [4]          |" << endl;
    cout << "|          Variance ------------------------------ [5]          |" << endl;
    cout << "|          Standard deviation -------------------- [6]          |" << endl;
    cout << "|          Frequencies of the distinct numbers --- [7]          |" << endl;
    cout << "|          Histogram ----------------------------- [8]          |" << endl;
    cout << "|          Above/Below mean ---------------------- [9]          |" << endl;
    cout << "|          Back to Subject Menu ------------------ [10]         |" << endl;
    cout << "|_______________________________________________________________|" << endl << endl;
    cout << " Please Enter Your Desire Number. " << endl;
    cin >> StatisticsMenu_Num;
    cin.ignore();
    system("CLS");

    // TO CHECK THE INPUT IS WHETHER include CHARACTER
    charError = cin.fail();

    strcpy(arrayHeader, header.c_str());
    headerPointer = strtok(arrayHeader, ",");

    if (StatisticsMenu_Num == 1)
    {
        for (int i = 0; i < col; i++)
            {
                 if (headerPointer != NULL)
                {
                    strcpy(arrayHeader, headerPointer);
                    headerPointer = strtok (NULL, ",");

                    if (i == SubjectMenu_Num+1)
                    {
                        cout << "-----------------------------" << endl;
                        cout << "|   Subject   |   Minimum   |" << endl;
                        cout << "-----------------------------" << endl;
                        cout << "|" << setw(8) << arrayHeader << setw(6) << "|" << setw(7) << Minimum() << setw(7) << "|" << endl;
                        cout << "-----------------------------" << endl;
                    }
                }
            }
    }

    else if (StatisticsMenu_Num == 2)
         for (int i = 0; i < col; i++)
            {
                if (headerPointer != NULL)
                {
                    strcpy(arrayHeader, headerPointer);
                    headerPointer = strtok (NULL, ",");

                    if (i == SubjectMenu_Num+1)
                    {
                        cout << "-----------------------------" << endl;
                        cout << "|   Subject   |   Maximum   |" << endl;
                        cout << "-----------------------------" << endl;
                        cout << "|" << setw(9) << arrayHeader << setw(5) << "|" << setw(7) << Maximum() << setw(7) << "|" << endl;
                        cout << "-----------------------------" << endl;
                    }
                }
            }


    else if (StatisticsMenu_Num == 3)
        for (int i = 0; i < col; i++)
        {
            if (headerPointer != NULL)
            {
                strcpy(arrayHeader, headerPointer);
                headerPointer = strtok (NULL, ",");

                if (i == SubjectMenu_Num+1)
                {
                    cout << "-----------------------------" << endl;
                    cout << "|   Subject   |    Median   |" << endl;
                    cout << "-----------------------------" << endl;
                    cout << "|" << setw(9) << arrayHeader << setw(5) << "|" << setw(9) << Median() << setw(5) << "|" << endl;
                    cout << "-----------------------------" << endl;
                }
            }
        }

    else if (StatisticsMenu_Num == 4)
        for (int i = 0; i < col; i++)
        {
            if (headerPointer != NULL)
            {
                strcpy(arrayHeader, headerPointer);
                headerPointer = strtok (NULL, ",");

                if (i == SubjectMenu_Num+1)
                {
                    cout << "----------------------------" << endl;
                    cout << "|   Subject   |    Mean    |" << endl;
                    cout << "----------------------------" << endl;
                    cout << "|" << setw(9) << arrayHeader << setw(5) << "|" << setw(8) << Mean() << setw(5) << "|" << endl;
                    cout << "----------------------------" << endl;
                }
            }
        }

    else if (StatisticsMenu_Num == 5)
        for (int i = 0; i < col; i++)
        {
            if (headerPointer != NULL)
            {
                strcpy(arrayHeader, headerPointer);
                headerPointer = strtok (NULL, ",");

                if (i == SubjectMenu_Num+1)
                {
                    cout << "--------------------------------" << endl;
                    cout << "|   Subject   |    Variance    |" << endl;
                    cout << "--------------------------------" << endl;
                    cout << "|" << setw(8) << arrayHeader << setw(6) << "|" << setw(11) << Variance() << setw(6) << "|" << endl;
                    cout << "--------------------------------" << endl;
                }
            }
        }

    else if (StatisticsMenu_Num == 6)
        for (int i = 0; i < col; i++)
        {
            if (headerPointer != NULL)
            {
                strcpy(arrayHeader, headerPointer);
                headerPointer = strtok (NULL, ",");

                if (i == SubjectMenu_Num+1)
                {
                    cout << "----------------------------------------------" << endl;
                    cout << "|    Subject    |     Standard Deviation     |" << endl;
                    cout << "----------------------------------------------" << endl;
                    cout << "|" << setw(10) << arrayHeader << setw(6) << "|" << setw(16) << StandardDeviation() << setw(13) << "|" << endl;
                    cout << "----------------------------------------------" << endl;
                }
            }
        }
    else if (StatisticsMenu_Num == 7)
        DistinctNumberFrequency();
    else if (StatisticsMenu_Num ==8)
        Histogram();
    else if (StatisticsMenu_Num ==9)
        AboveBelowMean();
    else if (StatisticsMenu_Num == 10)
        SubjectMenu();


    else if (charError)
        {
            cin.clear();
            getline(cin, num);
            cout << "Invalid Input! Please Try Again!" << endl;
            Continue();
            StatisticsMenu();
        }

    else
        cout << "Invalid Input! Please Try Again!" << endl;
        Continue();
        StatisticsMenu();

    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
int Minimum()
{
    int* arrayMarks = arrayInformation(SubjectMenu_Num+1);
    int SmallestNum = arrayMarks[0];

    for (int i = 0; i < row; i++)
    {
        if (arrayMarks[i] < SmallestNum)
            SmallestNum = arrayMarks[i];
    }
    return SmallestNum;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
int Maximum()
{
    int* arrayMarks = arrayInformation(SubjectMenu_Num+1);
    int BiggestNum = arrayMarks[0];

    for (int i = 0; i < row; i++)
    {
        if (arrayMarks[i] > BiggestNum)
            BiggestNum = arrayMarks[i];
    }
    return BiggestNum;
}
///////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
double Median()
{
    int* arrayMarks = arrayInformation(SubjectMenu_Num+1);
    int temp;
    double median;

    for(int i = 0; i < row; i++)
    {
        for (int j = i+1; j < row; j++)
        {
            if(arrayMarks[i] > arrayMarks[j])
			{
				temp  = arrayMarks[i];
				arrayMarks[i] = arrayMarks[j];
				arrayMarks[j] = temp;
			}
        }
    }
    // even number
    if ( row%2 == 0 )
        median = (arrayMarks[row/2] + arrayMarks[(row/2) - 1]) / 2.00;

    // odd number
    else
        median = arrayMarks[(row-1) / 2];
    cout << setprecision(2) << fixed << showpoint;
    return median;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
double Mean()
{
    int* arrayMarks = arrayInformation(SubjectMenu_Num+1);
    double sum = 0;
    for ( int i = 0; i < row; i++)
    {
        sum = sum + arrayMarks[i];
    }
    cout << setprecision(2) << fixed << showpoint;
    return (sum) / (row);
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
double Variance()
{
    int* arrayMarks = arrayInformation(SubjectMenu_Num+1);
    double sum = 0;

    for ( int i = 0; i < row; i++)
    {
        sum = sum + pow(arrayMarks[i] - Mean(), 2);
    }
    return (sum) / (row);
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
double StandardDeviation()
{
    cout << setprecision(2) << fixed << showpoint;
    return pow(Variance(), 0.5);
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
void DistinctNumberFrequency()
{
    int temp, count;
    int* arrayMarks = arrayInformation(SubjectMenu_Num+1);
    ofstream file;
    file.open("DistinctNumber.txt");

    ///// TABLE HEADER /////
    cout << "-------------------------" << endl;
    cout << "|  Marks  |  Frequency  |" << endl;
    cout << "-------------------------" << endl;

    file << "-------------------------" << endl;
    file << "|  Marks  |  Frequency  |" << endl;
    file << "-------------------------" << endl;

    for(int i = 0; i < row; i++)
    {
        for (int j = i+1; j < row; j++)
        {
            if(arrayMarks[i] > arrayMarks[j])
            {
                temp  = arrayMarks[i];
                arrayMarks[i] = arrayMarks[j];
                arrayMarks[j] = temp;
            }
        }

    }

    for(int i = 0; i < row; i++)
    {
        count = 1;
        for (int j = i+1; j < row; j++)
        {
            if (arrayMarks[i] == arrayMarks[j])
            {
                i++;
                count ++;
            }
        }
        cout << "|" << setw(5) << arrayMarks[i] << setw(5) << "|" << setw(7) << count << setw(7) << "|" << endl;
        file << "|" << setw(5) << arrayMarks[i] << setw(5) << "|" << setw(7) << count << setw(7) << "|" << endl;
    }

    cout << "-------------------------" << endl;
    file << "-------------------------" << endl;
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////
void Histogram()
{
    int* arrayMarks = arrayInformation(SubjectMenu_Num+1);
    int firstsector = 0;
    int secondsector = 0;
    int thirdsector = 0;
    int forthsector = 0;
    int fifthsector = 0;
    int frequency;

    ofstream file;
    file.open("Histogram.txt");

    cout << "---------------------------------------" << endl;
    cout << "|   Marks Range   |    Frequencies    |" << endl;
    cout << "---------------------------------------" << endl;

    file << "---------------------------------------" << endl;
    file << "|   Marks Range   |    Frequencies    |" << endl;
    file << "---------------------------------------" << endl;

    //histogram
    for (int i=0; i<row; i++)
    {

        if(arrayMarks[i]>= 0 && arrayMarks[i] <= 19)
        {
            firstsector+=1;
        }
        else if (arrayMarks[i]>= 20 && arrayMarks[i] <=39)
        {
            secondsector+=1;
        }
        else if (arrayMarks[i]>= 40 && arrayMarks[i] <= 59)
        {
            thirdsector+=1;
        }
        else if (arrayMarks[i]>= 60 && arrayMarks[i] <= 79)
        {
            forthsector+=1;
        }
        else if (arrayMarks[i]>= 80 && arrayMarks[i] <= 100)
        {
            fifthsector+=1;
        }
    }
    cout << "|" << setw(10) << "0-19"  << setw(8)<< "|"; PrintHistogram(firstsector); cout << setw(20)<< "|"<< endl;
    cout << "|" << setw(10) << "20-39" << setw(8)<< "|"; PrintHistogram(secondsector);cout << setw(20)<< "|"<< endl;
    cout << "|" << setw(10) << "40-59" << setw(8)<< "|"; PrintHistogram(thirdsector); cout << setw(20)<< "|"<< endl;
    cout << "|" << setw(10) << "60-79" << setw(8)<< "|"; PrintHistogram(forthsector); cout << setw(20)<< "|"<< endl;
    cout << "|" << setw(10) << "80-100"<< setw(8)<< "|"; PrintHistogram(fifthsector); cout << setw(20)<< "|"<< endl;

    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////
void PrintHistogram(int frequency)
{
    for (int i = 0; i < frequency; i++)
        cout << "*";
}
/////////////////////////////////////////////////////////////////////////////////////////////

void SaveFile()
{
    ofstream file;
}

/////////////////////////////////////////////////////////////////////////////////////////////
void AboveBelowMean()
{
    //mean
    int* arrayMarks = arrayInformation(SubjectMenu_Num+1);
    int* arrayID = arrayInformation(0);
    ofstream file;
    file.open("AboveBelowMean.txt");

    cout << "The average score is : " << Mean() << endl;
    cout << " Marks above average. "  << endl;

    file << "The average score is : " << Mean() << endl;
    file << " Marks above average. "  << endl;

    cout << "---------------------------------" << endl;
    cout << "|        ID        |    Mark    |" << endl;
    cout << "---------------------------------" << endl;

    file << "---------------------------------" << endl;
    file << "|        ID        |    Mark    |" << endl;
    file << "---------------------------------" << endl;

    //above average
    for (int i=0; i<row; i++)
    {
        if (arrayMarks[i] > Mean())
        {
            cout << "|" << setw(9) << arrayID[i] << setw(9) << "|" << setw(7) << arrayMarks[i] << setw(6) << "|" << endl;
            file << "|" << setw(9) << arrayID[i] << setw(9) << "|" << setw(7) << arrayMarks[i] << setw(6) << "|" << endl;
        }
    }
    cout << "--------------------------------";
    file << "--------------------------------";


    cout << endl;
    cout << " Marks Below Average. " << endl;
    cout << "---------------------------------" << endl;
    cout << "|        ID        |    Mark    |" << endl;
    cout << "---------------------------------" << endl;

    file << endl;
    file << " Marks Below Average. " << endl;
    file << "---------------------------------" << endl;
    file << "|        ID        |    Mark    |" << endl;
    file << "---------------------------------" << endl;


    //below average
    for (int i=0; i<row; i++)
    {
        if (arrayMarks[i] < Mean())
        {
            cout << "|" << setw(9) << arrayID[i] << setw(9) << "|" << setw(7) << arrayMarks[i] << setw(6) << "|" << endl;
            file << "|" << setw(9) << arrayID[i] << setw(9) << "|" << setw(7) << arrayMarks[i] << setw(6) << "|" << endl;
        }
    }
    cout << "--------------------------------"<< endl;
    file << "--------------------------------"<< endl;

    return;
}

/////////////////////////////////////////////////////////////////////////////////////////////
void CompareSubjectsMenu()
{
    ifstream inputFile;
    inputFile.open(file);

    if (!inputFile)
    {
        cout << "Invalid Data! Please Load Data!" << endl;
        Continue();
        MainMenu();
    }

    else
        cout << "___________________________________________________" << endl << endl;
        cout << "    ============= Compare Subjects ============     " << endl;

        subjectList();
        cout << "                 [" << col-1 << "] - Back To Main Menu" << endl;
        cout << "___________________________________________________" << endl << endl;
        CompareSubjectsChoice();
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
void CompareSubjectsChoice()
{
        bool charError1, charError2;
        string num;

        cout << "Please Select The First Subject: ";
        cin >> CompareSubjectsMenu_num1;

        int inputNum1 = CompareSubjectsMenu_num1;
        charError1 = cin.fail();

        if (inputNum1 == col-1)
        {
            system("CLS");
            MainMenu();
        }

        else if (inputNum1 > 0 && inputNum1 < col-1)
        {
            cout << endl;
            cout << "Please Select The Second Subject: ";
            cin >> CompareSubjectsMenu_num2;
            cin.ignore();
            system("CLS");
            int inputNum2 = CompareSubjectsMenu_num2;
            charError2 = cin.fail();

            if (inputNum2 == col-1)
            {
                MainMenu();
            }


            else if (inputNum2 > 0 && inputNum2 < col-1)
            {
                if (inputNum1 == inputNum2)
                {
                    cout << "You have selected two same subjects. Please try again!" << endl;
                    Continue();
                    CompareSubjectsMenu();
                }

                else
                CompareTable();
            }

            else if (charError2)
            {
                cin.clear();
                getline(cin,num);
                cout << "Invalid Subject! Please Try Again!" << endl;
                Continue();
                CompareSubjectsMenu();
            }

            else
                cout << "Invalid Subject! Please Try Again!" << endl;
                Continue();
                CompareSubjectsMenu();
        }


        else if (charError1)
        {
            cin.clear();
            getline(cin, num);
            system("CLS");
            cout << "Invalid Subject! Please Try Again!" << endl;
            Continue();
            CompareSubjectsMenu();
        }

        else
            system("CLS");
            cout << "Invalid Subject! Please Try Again!" << endl;
            Continue();
            CompareSubjectsMenu();
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
double Pearson(int sumofX, int sumofY, int sumofXY, int sumofXSquare, int sumofYSquare)
{
    double pearson, P1, P2, P3;
    P1 = (row*sumofXY)-(sumofX*sumofY);
    P2 = (row*sumofXSquare)-(sumofX*sumofX);
    P3 = (row*sumofYSquare)-(sumofY*sumofY);
    pearson = P1 / pow(P2*P3,0.5);

    return pearson;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
double LinearA(int sumofX, int sumofY, int sumofXY, int sumofXSquare, int sumofYSquare)
{
    double a1, a2;
    a1 = (sumofY*sumofXSquare) - (sumofX*sumofXY);
    a2 = (row*sumofXSquare) - (sumofX*sumofX);
    return a1 / a2;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
double LinearB(int sumofX, int sumofY, int sumofXY, int sumofXSquare, int sumofYSquare)
{
    double b1, b2;
    b1 = (row*sumofXY) - (sumofX*sumofY);
    b2 = (row*sumofXSquare) - (sumofX*sumofX);
    return b1 / b2;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
void CompareTable()
{
    int n = header.size();
    int sumofX = 0, sumofY = 0, sumofXY = 0, sumofXSquare = 0, sumofYSquare = 0;
    char arrayHeader[n];
    char* headerPointer;
    int* arrayMarks_X = arrayInformation(CompareSubjectsMenu_num1+1);
    int* arrayMarks_Y = arrayInformation(CompareSubjectsMenu_num2+1);
    ofstream file;
    file.open("CompareTable.txt");

    strcpy(arrayHeader, header.c_str());
    headerPointer = strtok(arrayHeader, ",");

    for(int i = 0; i < col; i++)
    {
        if (headerPointer != NULL)
        {
            strcpy(arrayHeader, headerPointer);
            headerPointer = strtok (NULL, ",");
        }

        if (i == CompareSubjectsMenu_num1 + 1)
            cout << setw(32) << arrayHeader << " ( X )  VS  ";
            file << setw(32) << arrayHeader << " ( X )  VS  ";

        else if  (i == CompareSubjectsMenu_num2 + 1)
            cout << arrayHeader << " ( Y )" << endl << endl;
            file << arrayHeader << " ( Y )" << endl << endl;
    }


    ///// TABLE HEADER /////
    cout << "----------------------------------------------------------------------------------" << endl;
    cout << "|    STUDENT    |     X     |     Y     |     XY     |     X^2     |     Y^2     |" << endl;
    cout << "----------------------------------------------------------------------------------" << endl;

    file << "----------------------------------------------------------------------------------" << endl;
    file << "|    STUDENT    |     X     |     Y     |     XY     |     X^2     |     Y^2     |" << endl;
    file << "----------------------------------------------------------------------------------" << endl;

    for ( int i = 0; i < row; i++)
    {
        ///// CALCULATE SUM OF EACH CALCULATION /////
        sumofX = sumofX + arrayMarks_X[i];
        sumofY = sumofY + arrayMarks_Y[i];
        sumofXY = sumofXY+ (arrayMarks_X[i]*arrayMarks_Y[i]);
        sumofXSquare = sumofXSquare + pow(arrayMarks_X[i],2);
        sumofYSquare = sumofYSquare + pow(arrayMarks_Y[i],2);

        ///// TABLE CONTENT ///////
        cout << "|" << setw(8) << i+1 << setw(8) << "|" << setw(6) << arrayMarks_X[i]<< setw(6) << "|" <<
             setw(6) << arrayMarks_Y[i] << setw(6) << "|" <<
             setw(8) << arrayMarks_X[i]*arrayMarks_Y[i] << setw(5) << "|" <<
             setw(8) << pow(arrayMarks_X[i],2) << setw(6) << "|" <<
             setw(8) << pow(arrayMarks_Y[i],2) << setw(6) << "|" << endl;
        file << "|" << setw(8) << i+1 << setw(8) << "|" << setw(6) << arrayMarks_X[i]<< setw(6) << "|" <<
             setw(6) << arrayMarks_Y[i] << setw(6) << "|" <<
             setw(8) << arrayMarks_X[i]*arrayMarks_Y[i] << setw(5) << "|" <<
             setw(8) << pow(arrayMarks_X[i],2) << setw(6) << "|" <<
             setw(8) << pow(arrayMarks_Y[i],2) << setw(6) << "|" << endl;
    }

    ///// TOTAL PRINT INSIDE TABLE /////
    cout << "==================================================================================" << endl;
    cout << "|    Total =    |" <<
         setw(7) << sumofX << setw(5) << "|" <<
         setw(7) << sumofY << setw(5) << "|" <<
         setw(9) << sumofXY << setw(4) << "|" <<
         setw(9) << sumofXSquare << setw(5) << "|" <<
         setw(9) << sumofYSquare << setw(5) << "|" << endl;
    cout << "==================================================================================" << endl << endl;

    file << "==================================================================================" << endl;
    file << "|    Total =    |" <<
         setw(7) << sumofX << setw(5) << "|" <<
         setw(7) << sumofY << setw(5) << "|" <<
         setw(9) << sumofXY << setw(4) << "|" <<
         setw(9) << sumofXSquare << setw(5) << "|" <<
         setw(9) << sumofYSquare << setw(5) << "|" << endl;
    file << "==================================================================================" << endl << endl;

    ///// PRINT PEARSON CALCULATION /////
    cout << "1 . Pearson's Correlation" << endl << endl;
    cout << "    r = (" << row << "*" << sumofXY << "-" << sumofX << "*" << sumofY << ")" << " / sqrt(("
         << row << "*" << sumofXSquare << " - " << sumofX << "*" << sumofX << ") * ("
         << row << "*" << sumofYSquare << " - " << sumofY << "*" << sumofY << "))"<< endl;
    cout << "      = " << Pearson(sumofX, sumofY, sumofXY, sumofXSquare, sumofYSquare) << endl << endl;
    file << "1 . Pearson's Correlation" << endl << endl;
    file << "    r = (" << row << "*" << sumofXY << "-" << sumofX << "*" << sumofY << ")" << " / sqrt(("
         << row << "*" << sumofXSquare << " - " << sumofX << "*" << sumofX << ") * ("
         << row << "*" << sumofYSquare << " - " << sumofY << "*" << sumofY << "))"<< endl;
    file << "      = " << Pearson(sumofX, sumofY, sumofXY, sumofXSquare, sumofYSquare) << endl << endl;

    ///// PRINT LINEAR CALCULATION /////
    cout << "2 . Linear Regression" << endl << endl;
    cout << "    a = (" << sumofY << "*" << sumofXSquare << " - " << sumofX << "*" << sumofXY << ") / ("
         << row << "*" << sumofXSquare << " - " << sumofX << "*" << sumofX << ")" << endl;
    cout << "      = " << LinearA(sumofX, sumofY, sumofXY, sumofXSquare, sumofYSquare) << endl;

    cout << "    b = (" << row << "*" << sumofXY << " - " << sumofX << "*" << sumofY << ") / ("
         << row << "*" << sumofXSquare << " - " << sumofX << "*" << sumofX << ")" << endl;
    cout << "      = " << LinearB(sumofX, sumofY, sumofXY, sumofXSquare, sumofYSquare) << endl << endl;

    cout << "    y'= " << LinearA(sumofX, sumofY, sumofXY, sumofXSquare, sumofYSquare) << " + "
         << LinearB(sumofX, sumofY, sumofXY, sumofXSquare, sumofYSquare) << "x" << endl << endl;

         file << "2 . Linear Regression" << endl << endl;
    file << "    a = (" << sumofY << "*" << sumofXSquare << " - " << sumofX << "*" << sumofXY << ") / ("
         << row << "*" << sumofXSquare << " - " << sumofX << "*" << sumofX << ")" << endl;
    file << "      = " << LinearA(sumofX, sumofY, sumofXY, sumofXSquare, sumofYSquare) << endl;

    file << "    b = (" << row << "*" << sumofXY << " - " << sumofX << "*" << sumofY << ") / ("
         << row << "*" << sumofXSquare << " - " << sumofX << "*" << sumofX << ")" << endl;
    file << "      = " << LinearB(sumofX, sumofY, sumofXY, sumofXSquare, sumofYSquare) << endl << endl;

    file << "    y'= " << LinearA(sumofX, sumofY, sumofXY, sumofXSquare, sumofYSquare) << " + "
         << LinearB(sumofX, sumofY, sumofXY, sumofXSquare, sumofYSquare) << "x" << endl << endl;

    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
void SortDataMenu()
{
    bool charError;
    string num;
    ifstream inputFile;
    inputFile.open(file);

    if (!inputFile)
    {
        cout << "Invalid Data! Please Load Data!" << endl;
        Continue();
        MainMenu();
    }

    else
    {
        cout << "____________________________________________________" << endl;
        cout << "|                                                  |" << endl;
        cout << "|    =============== Sort Data ===============     |" << endl;
        cout << "|          Ascending Order --------- [1]           |" << endl;
        cout << "|          Descending Order -------- [2]           |" << endl;
        cout << "|          Back to Main Menu ------- [3]           |" << endl;
        cout << "|__________________________________________________|" << endl << endl;
        cout << " Please Enter Your Desire Number. " << endl;
        cin >> SortDataMenu_Num;
        cin.ignore();
        system("CLS");

        // TO CHECK THE INPUT IS WHETHER include CHARACTER
        charError = cin.fail();

        if (SortDataMenu_Num > 0 && SortDataMenu_Num < 3)
            do
            {
                SortSubjectsMenu();
            }
            while(SortSubjectsMenu_Num != col-1);


        else if (SortDataMenu_Num == 3)
                MainMenu();

        else if (charError)
        {
            cin.clear();
            getline(cin, num);
            cout << "Invalid Input! Please Try Again!" << endl;
            Continue();
            SortDataMenu();
        }

        else
            cout << "Invalid Input! Please Try Again!" << endl;
            Continue();
            SortDataMenu();
    }
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////
void SortSubjectsMenu()
{
    bool charError;
    string num;

    cout << "___________________________________________________" << endl << endl;
    cout << "    ================ Sort Data ================     " << endl;

    subjectList();
    cout << "                 [" << col-1 << "] - Back To Sort Data Menu" << endl;
    cout << "___________________________________________________" << endl << endl;
    cout << " Please Select A Subject." << endl;
    cin >> SortSubjectsMenu_Num;
    cin.ignore();
    system("CLS");

    charError = cin.fail();

    if(SortSubjectsMenu_Num > 0 && SortSubjectsMenu_Num < col-1)
        AscendDescend();

    else if (SortSubjectsMenu_Num == col-1)
        SortDataMenu();

    else if (charError)
    {
        cin.clear();
        getline(cin, num);
        cout << "Invalid Input! Please Try Again!" << endl;
        Continue();
        SortSubjectsMenu();
    }

    else
        cout << "Invalid Input! Please Try Again!" << endl;
        Continue();
        SortSubjectsMenu();

    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////
void AscendDescend()
{
    int temp1, temp2;
    int n = header.size();
    char arrayHeader[n];
    char* headerPointer;
    int* arrayMarks = arrayInformation(SortSubjectsMenu_Num+1);
    int* arrayID = arrayInformation(0);

    strcpy(arrayHeader, header.c_str());
    headerPointer = strtok(arrayHeader, ",");

    ///// PRINT THE SELECTED SUBJECT /////
    for (int i = 0; i < col; i++)
    {
        if (headerPointer != NULL)
        {
            strcpy(arrayHeader, headerPointer);
            headerPointer = strtok (NULL, ",");
        }
         if (i == SortSubjectsMenu_Num + 1)
            cout << setw(16) << "( " <<  arrayHeader << " )" << endl;
    }

    ///// PRINT HEADER /////
    cout << "-------------------------------------" << endl;
    cout << "|         ID          |    Marks    |" << endl;
    cout << "-------------------------------------" << endl;

    ///// PRINT THE ID AND MARKS /////
    for(int i = 0; i < row; i++)
    {
        for (int j = i+1; j < row; j++)
        {
            if (SortDataMenu_Num == 1)
            {
                if(arrayMarks[i] > arrayMarks[j])
                {
                    temp1  = arrayMarks[i];
                    arrayMarks[i] = arrayMarks[j];
                    arrayMarks[j] = temp1;

                    temp2 = arrayID[i];
                    arrayID[i] = arrayID[j];
                    arrayID[j] = temp2;
                }
            }

            else if (SortDataMenu_Num == 2)
            {
                if(arrayMarks[j] > arrayMarks[i])
                {
                    temp1  = arrayMarks[i];
                    arrayMarks[i] = arrayMarks[j];
                    arrayMarks[j] = temp1;

                    temp2 = arrayID[i];
                    arrayID[i] = arrayID[j];
                    arrayID[j] = temp2;
                }
            }
        }
        cout << "|" << setw(15) << arrayID[i] << setw(7) << "|" << setw(8) << arrayMarks[i] << setw(6) << "|" << endl;
    }
    cout << "-------------------------------------" << endl;

    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////
void Continue()
{
    system("pause");
    system("CLS");
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////
