#include <iostream>
#include <fstream>
#include <cmath>
#include <iomanip>
#include <string>
#include <stdlib.h>
#include <bits/stdc++.h>

using namespace std;

////// MAIN MENU  //////
void MainMenu(int, int, string, string);
void MainMenuChoice(int, int, int, string, string);

////// LOAD DATA //////
void LoadData(int, int, string, string);
int* arrayInformation(int, int, int, string);
void SortAscending(int*, int*, int);
void SortDescending(int*, int*, int);
char* Subject(int, int, string);
void subjectList(int, string);

////// STATISTICS //////
void SubjectMenu(int, int, string, string);
void SubjectMenuChoice(int, int, int, string, string);
void StatisticsMenu(int, int, int, string, string);
int Minimum(int*, int);
int Maximum(int*, int);
double Median(int*, int*, int);
double Mean(int*, int);
double Variance(int*, int);
double StandardDeviation(int*, int);
void DistinctMarksFrequency(int*, int*, int);
void Histogram(int*, int*, int, int, string, string);
void printHistogram(int, int, int, int, int, int);
void AboveBelowMean(int, int, int, string);
void SaveDistinctMarksFrequency(ofstream&,int*, int*, int, int, string, int);
void SaveAboveBelowMean(ofstream& , int, int, int, string, string, string);
void SavePrintHistogram(ofstream&, int, int, int, int, int, int);
void SaveHistogram(ofstream&, int*, int*, int*, int, int, int, int, int, int, string);

////// COMPARE SUBJECTS //////
void CompareSubjectsMenu(int, int, string, string);
void CompareSubjectsChoice1(int, int, int, int, string, string);
void CompareSubjectsChoice2(int, int, int, int, string, string);
void CompareTable(int, int, int, int, string, string);
double Pearson(int, int, int, int, int, int);
double LinearA(int, int, int, int, int, int);
double LinearB(int, int, int, int, int, int);
void PrintPearsonLinearCalculation(int, int, int, int, int, int);
void CompareSubjectsHTML(ofstream&, int*, int*, int, int, int, int, int, int, int, int, int, string);
void SaveCompareSubjects(ofstream&, int*, int*, int, int, int, int, int, int, int, int, int, string);

////// SORT DATA /////
void SortDataMenu(int, int, string, string);
void SortSubjectsMenu(int, int, int, string, string);
void AscendDescend(int, int, int, int, string, string);
void SortDataHTML(ofstream&, int*, int*, int, int, int, int, string);
void SaveSortData(ofstream&, int*, int*, int, int, int, int, string);

////// ACADEMIC REPORT /////
void AcademicReportMenu(int, int, string, string);
void AcademicReportMenuChoice(int, int, int, string, string);
void AcademicReport(int*, int*, int, int, int, string, string);
void SaveAcademicReport(ofstream& , int*, int*, int, int, int, string, string);
void AcademicReportHTML(ofstream&, int*, int*, int, int, int, string, string);

///// EXTRAS /////
void Continue();

int main()
{
    cout << " -------------------------------------------------------" << endl;
    cout << "    Welcome To Academic Information And Report System " << endl;
    cout << " -------------------------------------------------------" << endl;
    Continue();
    string file, header;
    int row = 0, col = 0;

    MainMenu(row, col, header, file);
return 0;
}

/////////////////////////////////////////////////////////////////////////////////////////////
void MainMenu(int row, int col, string header, string file)
{
    int MainMenu_Num = 0;

    do
    {
        cout << "_____________________________________________________________" << endl;
        cout << "|                                                           |" << endl;
        cout << "|    ==================== Main Menu ====================    |" << endl;
        cout << "|        Load Data ----------------------------- [1]        |" << endl;
        cout << "|        Subjects ------------------------------ [2]        |" << endl;
        cout << "|        Compare Subjects ---------------------- [3]        |" << endl;
        cout << "|        Sort of Data -------------------------- [4]        |" << endl;
        cout << "|        Academic Report ----------------------- [5]        |" << endl;
        cout << "|        EXIT ---------------------------------- [6]        |" << endl;
        cout << "|___________________________________________________________|" << endl << endl;
        cout << " Please Enter Your Desire Number. " << endl;
        MainMenuChoice(MainMenu_Num, row, col, header, file);
    }
    while (MainMenu_Num != 6);

    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
void MainMenuChoice(int inputNum, int row, int col, string header, string file)
{
    string num;
    cin >> inputNum;
    system("CLS");

    if (inputNum == 1)
        LoadData(row, col, header, file);
    else if (inputNum== 2)
        SubjectMenu(row, col, header, file);
    else if (inputNum == 3)
        CompareSubjectsMenu(row, col, header, file);
    else if (inputNum == 4)
        SortDataMenu(row, col, header, file);
    else if (inputNum == 5)
        AcademicReportMenu(row, col, header, file);
    else if (inputNum == 6)
    {
        cout << "Thanks for using our system! Hope to see you again." << endl;
        exit(0);
    }

    else if (cin.fail())
    {
        cout << "Invalid Input! Please Try Again!" << endl;
        cin.clear();
        getline(cin, num);
        Continue();
    }
    else
    {
        cout << "Invalid Input! Please Try Again!" << endl;
        Continue();
    }
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

// =========================================== LOAD DATA ================================================== //
/////////////////////////////////////////////////////////////////////////////////////////////
void LoadData(int row, int col, string header, string file)
{
    cout << "Enter File Name : ";
    cin >> file;
    system("CLS");

    ifstream inputFile;
    inputFile.open(file);
    inputFile >> col >> header >> row;

    if (!inputFile)
    {
        while (!inputFile)
        {
            cout << "Error: file could not be opened. Please Try Again!"<< endl;
            cout << "Enter File Name : ";
            cin >> file;
            system("CLS");
            inputFile.open(file);
            inputFile >> col >> header >> row;
            if (!inputFile)
                cout << "";
            else
            {
                cout << "Your file has been loaded successfully." << endl;
                Continue();
                MainMenu(row, col, header, file);
            }
            inputFile.close();
        }
    }

    else
    {
        cout << "Your file has been loaded successfully." << endl;
        Continue();
        MainMenu(row, col, header, file);
    }
    inputFile.close();
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
int* arrayInformation(int inputNum, int row, int col, string file)
{
    int* marks = new int[row];
    int detail, arrayDetail[row][col];
    string header;
    ifstream inputFile;
    inputFile.open(file);
    inputFile >> col >> header >> row;

    for ( int i = 0; i < row; i++)
    {
        for ( int j = 0; j < col; j++)
        {
            inputFile >> detail;
            inputFile.ignore(1,',');
            arrayDetail[i][j] = detail;
        }
        marks[i] = arrayDetail[i][inputNum];
    }

    return marks;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
void SortAscending(int* array1, int* array2, int size)
{
    int temp1, temp2;
    for(int i = 0; i < size; i++)
    {
        for (int j = i+1; j < size; j++)
        {
            if(array1[i] > array1[j])
			{
				temp1 = array1[i];
				array1[i] = array1[j];
				array1[j] = temp1;

				temp2 = array2[i];
				array2[i] = array2[j];
				array2[j] = temp2;
			}
        }
    }
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
void SortDescending(int* array1, int* array2, int size)
{
    int temp1, temp2;
    for(int i = 0; i < size; i++)
    {
        for (int j = i+1; j < size; j++)
        {
            if(array1[j] > array1[i])
			{
				temp1 = array1[i];
				array1[i] = array1[j];
				array1[j] = temp1;

				temp2 = array2[i];
				array2[i] = array2[j];
				array2[j] = temp2;
			}
        }
    }
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
char* Subject(int num, int col, string header)
{
    int n = header.size();
    char* arrayHeader = new char[n];
    char* headerPointer;

    strcpy(arrayHeader, header.c_str());
    headerPointer = strtok(arrayHeader, ",");

    for( int i = 0; i < col; i++)
    {
        if (headerPointer != NULL)
        {
            strcpy(arrayHeader, headerPointer);
            headerPointer = strtok(NULL, ",");
            if (i == num)
                return arrayHeader;
        }
    }
    return 0;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
void subjectList(int col, string header)
{
    int n = header.size();
    char arrayHeader[n];
    char* headerPointer;

    strcpy(arrayHeader, header.c_str());
    headerPointer = strtok(arrayHeader, ",");

    for (int i = 1; i < col+1; i++)
    {
        if (headerPointer != NULL)
        {
            strcpy(arrayHeader, headerPointer);
            headerPointer = strtok (NULL, ",");
            if (i >= 3)
                cout << "                 [" << i-2 << "] - " << arrayHeader << endl;
        }
    }
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

// =========================================== VIEW SUBJECTS =============================================== //
/////////////////////////////////////////////////////////////////////////////////////////////
void SubjectMenu(int row, int col, string header, string file)
{
    ifstream inputFile;
    inputFile.open(file);
    int SubjectMenu_Num = 0;

    if (!inputFile)
    {
        cout << "Invalid Data! Please Load Data!" << endl;
        Continue();
        MainMenu(row, col, header, file);
    }

    else
    {
        do
        {
            cout << "___________________________________________________" << endl << endl;
            cout << "    ================= Subjects ================     " << endl;

            subjectList(col, header);
            cout << "                 [" << col-1 << "] - Back To Main Menu" << endl;
            cout << "___________________________________________________" << endl << endl;
            cout << " Please Select A Subject. " << endl;
            SubjectMenuChoice(SubjectMenu_Num, row, col, header, file);
        }
        while(SubjectMenu_Num != col-1);
    }
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
void SubjectMenuChoice(int inputNum, int row, int col, string header, string file)
{
    string num;
    cin >> inputNum;
    system("CLS");

    if (inputNum > 0 && inputNum < col-1)
        StatisticsMenu(inputNum, row, col, header, file);

    else if (inputNum == col-1)
        MainMenu(row, col, header, file);

    else if (cin.fail())
    {
        cout << "Invalid Input! Please Try Again!" << endl;
        cin.clear();
        getline(cin, num);
        Continue();
    }

    else
    {
        cout << "Invalid Input! Please Try Again!" << endl;
        Continue();
    }
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
void StatisticsMenu(int SubjectMenu_Num, int row, int col, string header, string file)
{
    string num;
    int StatisticsMenu_Num;
    int* arrayMarks = arrayInformation(SubjectMenu_Num+1, row, col, file);
    int* arrayID = arrayInformation(0, row, col, file);
    ofstream txtFile;
    string sub(Subject(SubjectMenu_Num+1, col, header));

    do
    {
        cout << "_________________________________________________________________" << endl;
        cout << "|                                                               |" << endl;
        cout << "|    ===================== Statistics =====================     |" << endl;
        cout << "|          Minimum mark -------------------------- [1]          |" << endl;
        cout << "|          Maximum mark -------------------------- [2]          |" << endl;
        cout << "|          Median -------------------------------- [3]          |" << endl;
        cout << "|          Mean ---------------------------------- [4]          |" << endl;
        cout << "|          Variance ------------------------------ [5]          |" << endl;
        cout << "|          Standard deviation -------------------- [6]          |" << endl;
        cout << "|          Frequencies of the distinct marks ----- [7]          |" << endl;
        cout << "|          Histogram ----------------------------- [8]          |" << endl;
        cout << "|          Above/Below mean ---------------------- [9]          |" << endl;
        cout << "|          Back to Subject Menu ------------------ [10]         |" << endl;
        cout << "|_______________________________________________________________|" << endl << endl;
        cout << " Please Enter Your Desire Number. " << endl;
        cin >> StatisticsMenu_Num;
        system("CLS");

        if (StatisticsMenu_Num == 1)
        {
            cout << "===================================" << endl;
            cout << "|      Subject      |   Minimum   |" << endl;
            cout << "===================================" << endl;
            cout << "|" << setw(12) << Subject(SubjectMenu_Num+1, col, header) << setw(7) << "|" << setw(7) << Minimum(arrayMarks, row) << setw(7) << "|" << endl;
            cout << "===================================" << endl;
            Continue();
        }

        else if (StatisticsMenu_Num == 2)
        {
            cout << "===================================" << endl;
            cout << "|      Subject      |   Maximum   |" << endl;
            cout << "===================================" << endl;
            cout << "|" << setw(12) << Subject(SubjectMenu_Num+1, col, header) << setw(7) << "|" << setw(7) << Maximum(arrayMarks, row)  << setw(7) << "|" << endl;
            cout << "===================================" << endl;
            Continue();
        }


        else if (StatisticsMenu_Num == 3)
        {
            cout << "===================================" << endl;
            cout << "|      Subject      |    Median   |" << endl;
            cout << "===================================" << endl;
            cout << "|" << setw(12) << Subject(SubjectMenu_Num+1, col, header) << setw(7) << "|" << setw(9) << Median(arrayMarks, arrayID, row) << setw(5) << "|" << endl;
            cout << "===================================" << endl;
            Continue();
        }

        else if (StatisticsMenu_Num == 4)
        {
            cout << "=================================="<< endl;
            cout << "|      Subject      |    Mean    |" << endl;
            cout << "==================================" << endl;
            cout << "|" << setw(12) << Subject(SubjectMenu_Num+1, col, header) << setw(7) << "|" << setw(8) << Mean(arrayMarks, row) << setw(5) << "|" << endl;
            cout << "==================================" << endl;
            Continue();
        }

        else if (StatisticsMenu_Num == 5)
        {
            cout << "======================================" << endl;
            cout << "|      Subject      |    Variance    |" << endl;
            cout << "======================================" << endl;
            cout << "|" << setw(12) << Subject(SubjectMenu_Num+1, col, header) << setw(7) << "|" << setw(11) << Variance(arrayMarks, row) << setw(6) << "|" << endl;
            cout << "======================================" << endl;
            Continue();
        }

        else if (StatisticsMenu_Num == 6)
        {
            cout << "==================================================" << endl;
            cout << "|      Subject      |     Standard Deviation     |" << endl;
            cout << "==================================================" << endl;
            cout << "|" << setw(12) << Subject(SubjectMenu_Num+1, col, header) << setw(7) << "|" << setw(16) << StandardDeviation(arrayMarks, row)  << setw(13) << "|" << endl;
            cout << "==================================================" << endl;
            Continue();
        }

        else if (StatisticsMenu_Num == 7)
        {
            cout << "Frequency of Distinct Marks:" << Subject(SubjectMenu_Num+1, col, header) << endl;
            cout << string(40, '=') << endl << endl;
            DistinctMarksFrequency(arrayMarks, arrayID,row);
            txtFile.open("DistinctMarksFrequency_" + (sub) +".txt");
            SaveDistinctMarksFrequency(txtFile, arrayMarks, arrayID, row, col, header, SubjectMenu_Num);
            txtFile.close();
            Continue();
        }
        else if (StatisticsMenu_Num == 8)
        {
            cout << "Histogram : " << Subject(SubjectMenu_Num+1, col, header) << endl;
            cout << string(30, '=') << endl << endl;
            Histogram(arrayMarks, arrayID, row, SubjectMenu_Num, file, sub);
            Continue();
        }
        else if (StatisticsMenu_Num == 9)
        {
            cout << "Above/Below Mean : " << Subject(SubjectMenu_Num+1, col, header) << endl;
            cout << string(30, '=') << endl << endl;
            AboveBelowMean(SubjectMenu_Num, row, col, file);
            cout << endl;
            txtFile.open("AboveBelowMean_" + (sub) +".txt");
            SaveAboveBelowMean(txtFile, SubjectMenu_Num, row, col, file, header, sub);
            txtFile.close();
            Continue();
        }
        else if (StatisticsMenu_Num == 10)
            SubjectMenu(row, col, header, file);
        else if (cin.fail())
        {
            cout << "Invalid Input! Please Try Again!" << endl;
            cin.clear();
            getline(cin, num);
            Continue();
        }
        else
        {
            cout << "Invalid Input! Please Try Again!" << endl;
            Continue();
        }
    }
    while(StatisticsMenu_Num != 10);

    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
int Minimum(int* arrayMarks, int size)
{
    int SmallestNum = arrayMarks[0];

    for (int i = 0; i < size; i++)
    {
        if (arrayMarks[i] < SmallestNum)
            SmallestNum = arrayMarks[i];
    }
    return SmallestNum;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
int Maximum(int* arrayMarks, int size)
{
    int BiggestNum = arrayMarks[0];

    for (int i = 1; i < size; i++)
    {
        if (arrayMarks[i] > BiggestNum)
            BiggestNum = arrayMarks[i];
    }
    return BiggestNum;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
double Median(int* arrayMarks, int* arrayID, int row)
{
    double median;
    SortAscending(arrayMarks, arrayID, row);

    // even number
    if ( row%2 == 0 )
        median = (arrayMarks[row/2] + arrayMarks[(row/2) - 1]) / 2.00;

    // odd number
    else
        median = arrayMarks[(row-1) / 2];
    cout << setprecision(2) << fixed << showpoint;
    return median;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
double Mean(int* arrayMarks, int size)
{
    double sum = 0;
    for ( int i = 0; i < size; i++)
    {
        sum = sum + arrayMarks[i];
    }
    cout << setprecision(2) << fixed << showpoint;
    return (sum) / (size);
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
double Variance(int* arrayMarks, int size)
{
    double sum = 0;

    for ( int i = 0; i < size; i++)
    {
        sum = sum + pow(arrayMarks[i] - Mean(arrayMarks, size), 2);
    }
    return (sum) / (size);
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
double StandardDeviation(int* arrayMarks, int size)
{
    cout << setprecision(2) << fixed << showpoint;
    return pow(Variance(arrayMarks, size), 0.5);
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
void DistinctMarksFrequency(int* arrayMarks, int* arrayID, int row)
{
    int count;
    SortAscending(arrayMarks, arrayID, row);

    ///// TABLE HEADER /////
    cout << "=========================" << endl;
    cout << "|  Marks  |  Frequency  |" << endl;
    cout << "=========================" << endl;

    for(int i = 0; i < row; i++)
    {
        count = 1;
        for (int j = i+1; j < row; j++)
        {
            if (arrayMarks[i] == arrayMarks[j])
            {
                count++;
                i++;
            }
        }
        cout << "|" << setw(5) << arrayMarks[i] << setw(5) << "|" << setw(7) << count << setw(7) << "|" << endl;
    }

    cout << "=========================" << endl;
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////
void SaveDistinctMarksFrequency(ofstream &txtFile,int* arrayMarks, int* arrayID, int row, int col, string header,int SubjectMenu_Num )
{
    int count;
    SortAscending(arrayMarks, arrayID, row);
    string sub(Subject(SubjectMenu_Num+1, col, header));

    txtFile << "Frequency of Distinct Marks : " << sub <<endl;
    txtFile << string(40, '=') << endl << endl;
    txtFile << "=========================" << endl;
    txtFile << "|  Marks  |  Frequency  |" << endl;
    txtFile << "=========================" << endl;
    for(int i = 0; i < row; i++)
    {
        count = 1;
        for (int j = i+1; j < row; j++)
        {
            if (arrayMarks[i] == arrayMarks[j])
            {
                count++;
                i++;
            }
        }
        txtFile << "|" << setw(5) << arrayMarks[i] << setw(5) << "|" << setw(7) << count << setw(7) << "|" << endl;
    }

    txtFile << "=========================" << endl;
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////
void Histogram(int* arrayMarks, int* arrayID, int row, int SubjectMenu_Num, string file, string sub)
{
    int firstsector = 0, secondsector = 0, thirdsector = 0, forthsector = 0, fifthsector = 0;
    SortAscending(arrayMarks, arrayID, row);
    ofstream txtFile;
    txtFile.open("Histogram_" + (sub) + ".txt");
    for (int i=0; i<row; i++)
    {
        if(arrayMarks[i]>= 0 && arrayMarks[i] <= 19)
            firstsector++;
        else if (arrayMarks[i]>= 20 && arrayMarks[i] <=39)
            secondsector++;
        else if (arrayMarks[i]>= 40 && arrayMarks[i] <= 59)
            thirdsector++;
        else if (arrayMarks[i]>= 60 && arrayMarks[i] <= 79)
            forthsector++;
        else
            fifthsector++;
    }
    int frequency[5] = {firstsector, secondsector, thirdsector, forthsector, fifthsector};
    int* arrayFreq = frequency;
    printHistogram(Maximum(arrayFreq, 5), firstsector, secondsector, thirdsector, forthsector, fifthsector);
    cout << "|---------------------------------------------------------------------------> Marks" << endl;
    cout << "     |0-19|        |20-39|        |40-59|        |60-79|        |80-100|" << endl;

    SaveHistogram(txtFile, arrayMarks, arrayID, frequency, row, firstsector, secondsector, thirdsector, forthsector, fifthsector, sub);
    txtFile.close();
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
void printHistogram(int maxNum, int firstsector, int secondsector, int thirdsector, int forthsector, int fifthsector)
{
    for (int i = maxNum; i > 0; i--)
    {
        if (i <= firstsector)
            cout << "       *       ";
        else
            cout << "               ";

        if (i <= secondsector)
            cout << "       *       ";
        else
            cout << "               ";

        if (i <= thirdsector)
            cout << "       *       ";
        else
            cout << "               ";

        if (i <= forthsector)
            cout << "       *       ";
        else
            cout << "               ";

        if (i <= fifthsector)
            cout << "       *       ";
        else
            cout << "               ";
        cout << endl;
    }
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////
void SavePrintHistogram (ofstream &txtFile, int maxNum, int firstsector, int secondsector, int thirdsector, int forthsector, int fifthsector)
{
    for (int i = maxNum; i > 0; i--)
    {
        if (i <= firstsector)
            txtFile << "       *       ";
        else
            txtFile << "               ";

        if (i <= secondsector)
            txtFile << "       *       ";
        else
            txtFile << "               ";

        if (i <= thirdsector)
            txtFile << "       *       ";
        else
            txtFile << "               ";

        if (i <= forthsector)
            txtFile << "       *       ";
        else
            txtFile << "               ";

        if (i <= fifthsector)
            txtFile << "       *       ";
        else
            txtFile << "               ";
        txtFile << endl;
    }
    return;
}
void SaveHistogram (ofstream &txtFile, int* arrayMarks, int* arrayID, int* arrayFreq, int row, int firstsector, int secondsector, int thirdsector, int forthsector, int fifthsector, string sub)
{

    SortAscending(arrayMarks, arrayID, row);
    txtFile << "Histogram : " << sub << endl;
    txtFile << string(30, '=') << endl << endl;
    SavePrintHistogram(txtFile, Maximum(arrayFreq, 5), firstsector, secondsector, thirdsector, forthsector, fifthsector);
    txtFile << "|---------------------------------------------------------------------------> Marks" << endl;
    txtFile << "     |0-19|        |20-39|        |40-59|        |60-79|        |80-100|" << endl;
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

void AboveBelowMean(int SubjectMenu_Num, int row, int col, string file)
{
    int* arrayMarks1 = arrayInformation(SubjectMenu_Num+1, row, col, file); int* arrayMarks2 = arrayInformation(SubjectMenu_Num+1, row, col, file);
    int* arrayID1 = arrayInformation(0, row, col, file);                    int* arrayID2 = arrayInformation(0, row, col, file);
    int count1 = 0, count2 = 0;
    SortDescending(arrayMarks1, arrayID1, row); SortAscending(arrayMarks2, arrayID2, row);

    cout << "Average Marks: " << Mean(arrayMarks1, row) << endl << endl;
    cout << " Marks Above Mean " << string(30, ' ') << " Marks Below Mean " << endl;
    cout << "=================================" << string(16, ' ') << "=================================" << endl;
    cout << "|        ID        |    Mark    |" << string(16, ' ') << "|        ID        |    Mark    |" << endl;
    cout << "=================================" << string(16, ' ') << "=================================" << endl;

    //above average
    for (int i = 0; i < row; i++)
    {
        if (arrayMarks1[i] != Mean(arrayMarks1, row))
        {
            if (arrayMarks1[i] > Mean(arrayMarks1, row))
            {
                count1++;
                cout << "|" << setw(12) <<  arrayID1[i] << setw(7) << "|" << setw(7) << arrayMarks1[i] << setw(6) << "|";
            }

            else if (i == count1)
                cout << "=================================";

            if (arrayMarks2[i] < Mean(arrayMarks1, row))
            {
                cout << string(16, ' ') << "|" << setw(12) << arrayID2[i] << setw(7) << "|" << setw(7) << arrayMarks2[i] << setw(6) << "|" << endl;
                count2++;
            }

            else if (i == count2)
                cout << string(16, ' ') << "=================================" << endl;
        }

        if (count1 < count2)
        {
            if (i >= count1 && i < count2)
                cout << string(33, ' ');
        }

        else
        {
            if (i > count2 && i < count1)
                    cout << endl;
        }
    }
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////
void SaveAboveBelowMean(ofstream &txtFile, int SubjectMenu_Num, int row, int col, string file, string header, string sub)
{
    int* arrayMarks1 = arrayInformation(SubjectMenu_Num+1, row, col, file); int* arrayMarks2 = arrayInformation(SubjectMenu_Num+1, row, col, file);
    int* arrayID1 = arrayInformation(0, row, col, file);                    int* arrayID2 = arrayInformation(0, row, col, file);
    int count1 = 0, count2 = 0;
    SortDescending(arrayMarks1, arrayID1, row); SortAscending(arrayMarks2, arrayID2, row);

    txtFile << "Above/Below Mean : " << sub << endl;
    txtFile << string(30, '=') << endl << endl;
    txtFile << "Average Marks: " << Mean(arrayMarks1, row) << endl << endl;
    txtFile << " Marks Above Mean " << string(30, ' ') << " Marks Below Mean " << endl;
    txtFile << "=================================" << string(16, ' ') << "=================================" << endl;
    txtFile << "|        ID        |    Mark    |" << string(16, ' ') << "|        ID        |    Mark    |" << endl;
    txtFile << "=================================" << string(16, ' ') << "=================================" << endl;

    //above average
    for (int i = 0; i < row; i++)
    {
        if (arrayMarks1[i] != Mean(arrayMarks1, row))
        {
            if (arrayMarks1[i] > Mean(arrayMarks1, row))
            {
                count1++;
                txtFile << "|" << setw(12) <<  arrayID1[i] << setw(7) << "|" << setw(7) << arrayMarks1[i] << setw(6) << "|";
            }

            else if (i == count1)
                txtFile << "=================================";

            if (arrayMarks2[i] < Mean(arrayMarks1, row))
            {
                txtFile << string(16, ' ') << "|" << setw(12) << arrayID2[i] << setw(7) << "|" << setw(7) << arrayMarks2[i] << setw(6) << "|" << endl;
                count2++;
            }

            else if (i == count2)
                txtFile << string(16, ' ') << "=================================" << endl;
        }

        if (count1 < count2)
        {
            if (i >= count1 && i < count2)
                txtFile << string(33, ' ');
        }

        else
        {
            if (i > count2 && i < count1)
                txtFile << endl;
        }
    }
    return;
}
// =========================================== COMPARE SUBJECT ============================================ //
/////////////////////////////////////////////////////////////////////////////////////////////
void CompareSubjectsMenu(int row, int col, string header, string file)
{
    ifstream inputFile;
    inputFile.open(file);
    int CompareSubjectsMenu_Num1 = 0, CompareSubjectsMenu_Num2 = 0;

    if (!inputFile)
    {
        cout << "Invalid Data! Please Load Data!" << endl;
        Continue();
        MainMenu(row, col, header, file);
    }

    else
    {
        do
        {
            cout << "___________________________________________________" << endl << endl;
            cout << "    ============= Compare Subjects ============     " << endl;

            subjectList(col, header);
            cout << "                 [" << col-1 << "] - Back To Main Menu" << endl;
            cout << "___________________________________________________" << endl << endl;
            CompareSubjectsChoice1(CompareSubjectsMenu_Num1, CompareSubjectsMenu_Num2, row, col, header, file);
        }
        while(CompareSubjectsMenu_Num1 == col-1 || CompareSubjectsMenu_Num2 == col-1);
    }
        return;
    }
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
void CompareSubjectsChoice1(int inputNum1, int inputNum2, int row, int col, string header, string file)
{
        string num;
        ///// INPUT FIRST SUBJECT /////
        cout << "Please Select The First Subject: ";
        cin >> inputNum1;

        if (inputNum1 == col-1)
        {
            system("CLS");
            MainMenu(row, col, header, file);
        }

        else if (inputNum1 > 0 && inputNum1 < col-1)
        {
            cout << endl;
            CompareSubjectsChoice2(inputNum1, inputNum2, row, col, header, file);
        }

        else if (cin.fail())
        {
            system("CLS");
            cout << "Invalid Subject! Please Try Again!" << endl;
            cin.clear();
            getline(cin, num);
            Continue();
            CompareSubjectsMenu(row, col, header, file);
        }

        else
        {
            system("CLS");
            cout << "Invalid Subject! Please Try Again!" << endl;
            Continue();
            CompareSubjectsMenu(row, col, header, file);
        }
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
void CompareSubjectsChoice2(int inputNum1, int inputNum2, int row, int col, string header, string file)
{
    string num;
    cout << "Please Select The Second Subject: ";
    cin >> inputNum2;
    system("CLS");

    if (inputNum2 == col-1)
    {
        MainMenu(row, col, header, file);
    }

    else if (inputNum2 > 0 && inputNum2 < col-1)
    {
        if (inputNum1 == inputNum2)
        {
            cout << "You have selected two same subjects. Please try again!" << endl;
            Continue();
            CompareSubjectsMenu(row, col, header, file);
        }

        else
        {
            CompareTable(inputNum1, inputNum2, row, col, header, file);
            CompareSubjectsMenu(row, col, header, file);
        }
    }

    else if (cin.fail())
    {
        cout << "Invalid Subject! Please Try Again!" << endl;
        cin.clear();
        getline(cin,num);
        Continue();
        CompareSubjectsMenu(row, col, header, file);
    }

    else
    {
        cout << "Invalid Subject! Please Try Again!" << endl;
        Continue();
        CompareSubjectsMenu(row, col, header, file);
    }
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
double Pearson(int sumofX, int sumofY, int sumofXY, int sumofXSquare, int sumofYSquare, int row)
{
    double P1, P2, P3;
    P1 = (row*sumofXY)-(sumofX*sumofY);
    P2 = (row*sumofXSquare)-(sumofX*sumofX);
    P3 = (row*sumofYSquare)-(sumofY*sumofY);
    return P1 / pow(P2*P3,0.5);
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
double LinearA(int sumofX, int sumofY, int sumofXY, int sumofXSquare, int sumofYSquare, int row)
{
    double a1, a2;
    a1 = (sumofY*sumofXSquare) - (sumofX*sumofXY);
    a2 = (row*sumofXSquare) - (sumofX*sumofX);
    return a1 / a2;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
double LinearB(int sumofX, int sumofY, int sumofXY, int sumofXSquare, int sumofYSquare, int row)
{
    double b1, b2;
    b1 = (row*sumofXY) - (sumofX*sumofY);
    b2 = (row*sumofXSquare) - (sumofX*sumofX);
    return b1 / b2;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
void CompareTable(int CompareSubjectsMenu_Num1, int CompareSubjectsMenu_Num2, int row, int col, string header, string file)
{
    int sumofX = 0, sumofY = 0, sumofXY = 0, sumofXSquare = 0, sumofYSquare = 0;
    int* arrayMarks_X = arrayInformation(CompareSubjectsMenu_Num1+1, row, col, file);
    int* arrayMarks_Y = arrayInformation(CompareSubjectsMenu_Num2+1, row, col, file);
    // string has a constructor that takes a const char*
    string subs1(Subject(CompareSubjectsMenu_Num1 + 1, col, header));
    string subs2(Subject(CompareSubjectsMenu_Num2 + 1, col, header));

    cout << "Compare Subject " << endl;
    cout << string(30, '=') << endl << endl;
    cout << setw(32) << Subject(CompareSubjectsMenu_Num1 + 1, col, header) << " ( X )  VS  ";
    cout << Subject(CompareSubjectsMenu_Num2 + 1, col, header) << " ( Y )" << endl << endl;


    ///// TABLE HEADER /////
    cout << "----------------------------------------------------------------------------------" << endl;
    cout << "|    STUDENT    |     X     |     Y     |     XY     |     X^2     |     Y^2     |" << endl;
    cout << "----------------------------------------------------------------------------------" << endl;

    for ( int i = 0; i < row; i++)
    {
        ///// CALCULATE SUM OF EACH CALCULATION /////
        sumofX = sumofX + arrayMarks_X[i]; sumofY = sumofY + arrayMarks_Y[i]; sumofXY = sumofXY+ (arrayMarks_X[i]*arrayMarks_Y[i]);
        sumofXSquare = sumofXSquare + pow(arrayMarks_X[i],2); sumofYSquare = sumofYSquare + pow(arrayMarks_Y[i],2);

        ///// TABLE CONTENT ///////
        cout << "|" << setw(8) << i+1 << setw(8) << "|" <<
             setw(6) << arrayMarks_X[i]<< setw(6) << "|" <<
             setw(6) << arrayMarks_Y[i] << setw(6) << "|" <<
             setw(8) << arrayMarks_X[i]*arrayMarks_Y[i] << setw(5) << "|" <<
             setw(8) << arrayMarks_X[i]*arrayMarks_X[i] << setw(6) << "|" <<
             setw(8) << arrayMarks_Y[i]*arrayMarks_Y[i] << setw(6) << "|" << endl;
        }

    ///// TOTAL PRINT INSIDE TABLE /////
    cout << "==================================================================================" << endl;
    cout << "|    Total =    |" <<
         setw(7) << sumofX << setw(5) << "|" <<
         setw(7) << sumofY << setw(5) << "|" <<
         setw(9) << sumofXY << setw(4) << "|" <<
         setw(9) << sumofXSquare << setw(5) << "|" <<
         setw(9) << sumofYSquare << setw(5) << "|" << endl;
    cout << "==================================================================================" << endl << endl;
    PrintPearsonLinearCalculation(sumofX, sumofY, sumofXY, sumofXSquare, sumofYSquare,row);

    ofstream myFile,txtFile;
    myFile.open("CompareSubjects_" + (subs1) + " vs " + (subs2) + ".html");
    CompareSubjectsHTML(myFile, arrayMarks_X, arrayMarks_Y, sumofX, sumofY, sumofXY, sumofXSquare, sumofYSquare, CompareSubjectsMenu_Num1, CompareSubjectsMenu_Num2, row, col, header);
    myFile.close();
    txtFile.open("CompareSubjects_" + (subs1) + " vs " + (subs2) + ".txt");
    SaveCompareSubjects(txtFile, arrayMarks_X, arrayMarks_Y, sumofX, sumofY, sumofXY, sumofXSquare, sumofYSquare, CompareSubjectsMenu_Num1, CompareSubjectsMenu_Num2, row, col, header);
    txtFile.close();
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
void PrintPearsonLinearCalculation(int sumofX, int sumofY, int sumofXY, int sumofXSquare, int sumofYSquare, int row)
{
     ///// PRINT PEARSON CALCULATION /////
    cout << setprecision(6) << fixed << showpoint;
    cout << "1 . Pearson's Correlation" << endl << endl;
    cout << "    r = (" << row << "*" << sumofXY << "-" << sumofX << "*" << sumofY << ")" << " / sqrt(("
         << row << "*" << sumofXSquare << " - " << sumofX << "*" << sumofX << ") * (" << row << "*" << sumofYSquare << " - " << sumofY << "*" << sumofY << "))"<< endl;
    cout << "      = " << Pearson(sumofX, sumofY, sumofXY, sumofXSquare, sumofYSquare, row) << endl << endl;

    ///// PRINT LINEAR CALCULATION /////
    cout << "2 . Linear Regression" << endl << endl;
    cout << "    a = (" << sumofY << "*" << sumofXSquare << " - " << sumofX << "*" << sumofXY << ") / (" << row << "*" << sumofXSquare << " - " << sumofX << "*" << sumofX << ")" << endl;
    cout << "      = " << LinearA(sumofX, sumofY, sumofXY, sumofXSquare, sumofYSquare, row) << endl;
    cout << "    b = (" << row << "*" << sumofXY << " - " << sumofX << "*" << sumofY << ") / (" << row << "*" << sumofXSquare << " - " << sumofX << "*" << sumofX << ")" << endl;
    cout << "      = " << LinearB(sumofX, sumofY, sumofXY, sumofXSquare, sumofYSquare, row) << endl << endl;
    cout << "    y'= " << LinearA(sumofX, sumofY, sumofXY, sumofXSquare, sumofYSquare, row) << " + " << LinearB(sumofX, sumofY, sumofXY, sumofXSquare, sumofYSquare, row) << "x" << endl << endl;
    Continue();
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////
void SaveCompareSubjects (ofstream &txtFile, int* arrayMarks_X, int* arrayMarks_Y, int sumofX, int sumofY, int sumofXY, int sumofXSquare, int sumofYSquare, int CompareSubjectsMenu_Num1, int CompareSubjectsMenu_Num2, int row, int col, string header)
{
    txtFile << "Compare Subject " << endl;
    txtFile << string(30, '=') << endl << endl;
    txtFile << setw(32) << Subject(CompareSubjectsMenu_Num1 + 1, col, header) << " ( X )  VS  ";
    txtFile << Subject(CompareSubjectsMenu_Num2 + 1, col, header) << " ( Y )" << endl << endl;

    ///// TABLE HEADER /////
    txtFile << "----------------------------------------------------------------------------------" << endl;
    txtFile << "|    STUDENT    |     X     |     Y     |     XY     |     X^2     |     Y^2     |" << endl;
    txtFile << "----------------------------------------------------------------------------------" << endl;

    for ( int i = 0; i < row; i++)
    {
        txtFile << "|" << setw(8) << i+1 << setw(8) << "|" <<
             setw(6) << arrayMarks_X[i]<< setw(6) << "|" <<
             setw(6) << arrayMarks_Y[i] << setw(6) << "|" <<
             setw(8) << arrayMarks_X[i]*arrayMarks_Y[i] << setw(5) << "|" <<
             setw(8) << arrayMarks_X[i]*arrayMarks_X[i] << setw(6) << "|" <<
             setw(8) << arrayMarks_Y[i]*arrayMarks_Y[i] << setw(6) << "|" << endl;
        }

    ///// TOTAL PRINT INSIDE TABLE /////
    txtFile << "==================================================================================" << endl;
    txtFile << "|    Total =    |" <<
         setw(7) << sumofX << setw(5) << "|" <<
         setw(7) << sumofY << setw(5) << "|" <<
         setw(9) << sumofXY << setw(4) << "|" <<
         setw(9) << sumofXSquare << setw(5) << "|" <<
         setw(9) << sumofYSquare << setw(5) << "|" << endl;
    txtFile << "==================================================================================" << endl << endl;

    //Print  Pearson's calculation
        txtFile << setprecision(6) << fixed << showpoint;
    txtFile << "1 . Pearson's Correlation" << endl << endl;
    txtFile << "    r = (" << row << "*" << sumofXY << "-" << sumofX << "*" << sumofY << ")" << " / sqrt(("
         << row << "*" << sumofXSquare << " - " << sumofX << "*" << sumofX << ") * (" << row << "*" << sumofYSquare << " - " << sumofY << "*" << sumofY << "))"<< endl;
    txtFile << "      = " << Pearson(sumofX, sumofY, sumofXY, sumofXSquare, sumofYSquare, row) << endl << endl;

    ///// PRINT LINEAR CALCULATION /////
    txtFile << "2 . Linear Regression" << endl << endl;
    txtFile << "    a = (" << sumofY << "*" << sumofXSquare << " - " << sumofX << "*" << sumofXY << ") / (" << row << "*" << sumofXSquare << " - " << sumofX << "*" << sumofX << ")" << endl;
    txtFile << "      = " << LinearA(sumofX, sumofY, sumofXY, sumofXSquare, sumofYSquare, row) << endl;
    txtFile << "    b = (" << row << "*" << sumofXY << " - " << sumofX << "*" << sumofY << ") / (" << row << "*" << sumofXSquare << " - " << sumofX << "*" << sumofX << ")" << endl;
    txtFile << "      = " << LinearB(sumofX, sumofY, sumofXY, sumofXSquare, sumofYSquare, row) << endl << endl;
    txtFile << "    y'= " << LinearA(sumofX, sumofY, sumofXY, sumofXSquare, sumofYSquare, row) << " + " << LinearB(sumofX, sumofY, sumofXY, sumofXSquare, sumofYSquare, row) << "x" << endl << endl;
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////
void CompareSubjectsHTML(ofstream &myFile, int* arrayMarks_X, int* arrayMarks_Y, int sumofX, int sumofY, int sumofXY, int sumofXSquare, int sumofYSquare, int inputNum1, int inputNum2, int row, int col, string header)
{
    myFile << "<!DOCTYPE html>" << endl << "<html>" << endl <<"<head>" << endl << "<style>" << endl;
    myFile << "table, th, td {" << endl << "  border: 3px double black;" << endl << "  border-collapse: collapse;" << endl << "}" << endl;
    myFile << "th, td{" << endl << "  padding; 15px;" << endl << "  text-align: center;" << endl << "}" << endl;
    myFile << "#t01 {" << endl << "  width: 100%;" << endl << "  background-color: #f1f1c1;" << endl << "}" << endl;
    myFile << "</style>" << endl << "</head>" << endl << "<body>" << endl << endl;
    myFile << "<h2> Compare Subjects </h2>" << endl << endl;
    myFile << "<h3>" << "<span style=""padding-right:340px;""></span>" << Subject(inputNum1 + 1, col, header) << " ( X ) VS " << Subject(inputNum2 + 1, col, header) << " ( Y )" << endl;
    myFile << "<table style=" << "width:60%>" << endl << "  <tr>" << endl << "    <th>Student</th>" << endl << "    <th>X</th>" << endl << "    <th>Y</th>" << endl
           << "    <th>XY</th>" << endl << "    <th>X^2</th>" << endl <<"    <th>Y^2</th>" << endl <<"  </tr>" << endl;
    for(int i = 0; i < row; i++)
    {
        myFile << "  <tr>" << endl << "    <td>" << i+1 << "</td>" << endl << "    <td>" << arrayMarks_X[i] << "</td>" << endl;
        myFile << "    <td>" << arrayMarks_Y[i] << "</td>" << endl << "    <td>" << arrayMarks_X[i]*arrayMarks_Y[i] << "</td>" << endl;
        myFile << "    <td>" << arrayMarks_X[i]*arrayMarks_X[i] << "</td>" << endl << "    <td>" << arrayMarks_Y[i]*arrayMarks_Y[i] << "</td>" << endl << "</tr>" << endl;
    }
    myFile << "  <tr>" << endl << "    <td>" << "Total = " << "</td>" << endl << "<td>" << sumofX << "</td>" << endl;
    myFile << "    <td>" << sumofY << "</td>" << endl << "<td>" << sumofXY<< "</td>" << endl;
    myFile << "    <td>" << sumofXSquare<< "</td>" << endl << "<td>" << sumofYSquare << "</td>" << endl << "</tr>" << endl << "</table>" << endl;
    ///// PEARSON CALCULATION /////
    myFile << "<h3> 1. Pearson's Correlation </h3>" << endl;
    myFile << "<p> r &nbsp= (" << row << "*" << sumofXY << "-" << sumofX << "*" << sumofY << ")" << " / sqrt((" << row << "*" << sumofXSquare
           << " - " << sumofX << "*" << sumofX << ") * (" << row << "*" << sumofYSquare << " - " << sumofY << "*" << sumofY << ")) </p>" << endl;
    myFile << "<p>&nbsp&nbsp&nbsp&nbsp= " << Pearson(sumofX, sumofY, sumofXY, sumofXSquare, sumofYSquare, row) << "</p> <br>" << endl;
    ///// LINEAR CALCULATION /////
    myFile << "<h3> 2. Linear Regression </h3>" << endl;;
    myFile << "<p> a &nbsp= (" << sumofY << "*" << sumofXSquare << " - " << sumofX << "*" << sumofXY << ") / ("
           << row << "*" << sumofXSquare << " - " << sumofX << "*" << sumofX << ")" << endl;
    myFile << "<p>&nbsp&nbsp&nbsp&nbsp= " << LinearA(sumofX, sumofY, sumofXY, sumofXSquare, sumofYSquare, row) << "</p>" << endl;
    myFile << "<p> b &nbsp= (" << "(" << row << "*" << sumofXY << " - " << sumofX << "*" << sumofY << ") / ("
           << row << "*" << sumofXSquare << " - " << sumofX << "*" << sumofX << ")" << endl;
    myFile << "<p>&nbsp&nbsp&nbsp&nbsp= " << LinearB(sumofX, sumofY, sumofXY, sumofXSquare, sumofYSquare, row) << "</p>" << endl;
    myFile << "<P> y'&nbsp= " << LinearA(sumofX, sumofY, sumofXY, sumofXSquare, sumofYSquare, row) << " + "
           << LinearB(sumofX, sumofY, sumofXY, sumofXSquare, sumofYSquare, row) << "x" << endl;
    myFile << "</table>" << endl << "</body>" << endl << "</html>";
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

// =========================================== SORT DATA ============================================ //
/////////////////////////////////////////////////////////////////////////////////////////////
void SortDataMenu(int row, int col, string header, string file)
{
    int SortDataMenu_Num = 0;
    string num;
    ifstream inputFile;
    inputFile.open(file);

    if (!inputFile)
    {
        cout << "Invalid Data! Please Load Data!" << endl;
        Continue();
        MainMenu(row, col, header, file);
    }

    else
    {
        do
        {
            cout << "____________________________________________________" << endl;
            cout << "|                                                  |" << endl;
            cout << "|    =============== Sort Data ===============     |" << endl;
            cout << "|          Ascending Order --------- [1]           |" << endl;
            cout << "|          Descending Order -------- [2]           |" << endl;
            cout << "|          Back to Main Menu ------- [3]           |" << endl;
            cout << "|__________________________________________________|" << endl << endl;
            cout << " Please Enter Your Desire Number. " << endl;
            cin >> SortDataMenu_Num;
            system("CLS");

            if (SortDataMenu_Num > 0 && SortDataMenu_Num < 3)
                SortSubjectsMenu(SortDataMenu_Num, row, col, header, file);

            else if (SortDataMenu_Num == 3)
                    MainMenu(row, col, header, file);

            else if (cin.fail())
            {
                cout << "Invalid Input! Please Try Again!" << endl;
                cin.clear();
                getline(cin, num);
                Continue();
            }

            else
            {
                cout << "Invalid Input! Please Try Again!" << endl;
                Continue();
            }
        }
        while(SortDataMenu_Num != 3);
    }
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
void SortSubjectsMenu(int SortDataMenu_Num, int row, int col, string header, string file)
{
    int SortSubjectsMenu_Num = 0;
    string num;

    do
    {
        cout << "___________________________________________________" << endl << endl;
        cout << "    ================ Sort Data ================     " << endl;

        subjectList(col, header);
        cout << "                 [" << col-1 << "] - Back To Sort Data Menu" << endl;
        cout << "___________________________________________________" << endl << endl;
        cout << " Please Select A Subject." << endl;
        cin >> SortSubjectsMenu_Num;
        system("CLS");

        if(SortSubjectsMenu_Num > 0 && SortSubjectsMenu_Num < col-1)
        {
            AscendDescend(SortDataMenu_Num, SortSubjectsMenu_Num, row, col, header, file);
            Continue();
        }

        else if (SortSubjectsMenu_Num == col-1)
            SortDataMenu(row, col, header, file);

        else if (cin.fail())
        {
            cout << "Invalid Input! Please Try Again!" << endl;
            cin.clear();
            getline(cin, num);
            Continue();
        }

        else
        {
            cout << "Invalid Input! Please Try Again!" << endl;
            Continue();
        }
    }
    while(SortSubjectsMenu_Num != col-1);
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
void AscendDescend(int SortDataMenu_Num, int SortSubjectsMenu_Num, int row, int col, string header, string file)
{
    int* arrayMarks = arrayInformation(SortSubjectsMenu_Num+1, row, col, file);
    int* arrayID = arrayInformation(0, row, col, file);
    // string has a constructor that takes a const char*
    string subs(Subject(SortSubjectsMenu_Num + 1, col, header));

    cout << "Sort Data : " << Subject(SortSubjectsMenu_Num + 1, col, header) << endl;
    cout << string(30, '=') << endl << endl;

    ///// PRINT HEADER /////
    cout << "-------------------------------------" << endl;
    cout << "|         ID          |    Marks    |" << endl;
    cout << "-------------------------------------" << endl;

    ///// PRINT THE ID AND MARKS /////
    for(int i = 0; i < row; i++)
    {
        if (SortDataMenu_Num == 1)
        {
            SortAscending(arrayMarks, arrayID, row);
            cout << "|" << setw(15) << arrayID[i] << setw(7) << "|" << setw(8) << arrayMarks[i] << setw(6) << "|" << endl;
            ofstream myFile, txtFile;
            myFile.open("SortAscending_" + (subs) + ".html");
            SortDataHTML(myFile, arrayMarks, arrayID, SortSubjectsMenu_Num, row, col, 1, header);
            myFile.close();
            txtFile.open("SortAscending_" + (subs) + ".txt");
            SaveSortData(txtFile, arrayMarks, arrayID, SortSubjectsMenu_Num, row, col, 1, header);
            txtFile.close();
        }

        else if (SortDataMenu_Num == 2)
        {
            SortDescending(arrayMarks, arrayID, row);
            cout << "|" << setw(15) << arrayID[i] << setw(7) << "|" << setw(8) << arrayMarks[i] << setw(6) << "|" << endl;
            ofstream myFile, txtFile;
            myFile.open("SortDescending_" + (subs) + ".html");
            SortDataHTML(myFile, arrayMarks, arrayID, SortSubjectsMenu_Num, row, col, 2, header);
            myFile.close();
            txtFile.open("SortDscending_" + (subs) + ".txt");
            SaveSortData(txtFile, arrayMarks, arrayID, SortSubjectsMenu_Num, row, col, 1, header);
            txtFile.close();
        }
    }
    cout << "-------------------------------------" << endl;

    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////
void SaveSortData(ofstream &txtFile, int* arrayMarks, int* arrayID, int inputNum, int row, int col, int num, string header)
{
    if (num == 1)
    {
        txtFile << " Sort Data Ascending : " << Subject(inputNum + 1, col, header) << endl << endl;
        txtFile << string(30, '=') << endl << endl;
        txtFile << "-------------------------------------" << endl;
        txtFile << "|         ID          |    Marks    |" << endl;
        txtFile << "-------------------------------------" << endl;
    }
    else
    {
        txtFile << " Sort Data Dscending : " << Subject(inputNum + 1, col, header) << endl << endl;
        txtFile << string(30, '=') << endl << endl;
        txtFile << "-------------------------------------" << endl;
        txtFile << "|         ID          |    Marks    |" << endl;
        txtFile << "-------------------------------------" << endl;
    }
    for (int i = 0; i < row; i++)
    {
        txtFile << "|" << setw(15) << arrayID[i] << setw(7) << "|" << setw(8) << arrayMarks[i] << setw(6) << "|" << endl;
    }
    txtFile << "-------------------------------------" << endl;
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////
void SortDataHTML(ofstream &myFile, int* arrayMarks, int* arrayID, int inputNum, int row, int col, int num, string header)
{
    myFile << "<!DOCTYPE html>" << endl << "<html>" << endl <<"<head>" << endl << "<style>" << endl;
    myFile << "table, th, td {" << endl << "  border: 4px double black;" << endl << "  border-collapse: collapse;" << endl << "}" << endl;
    myFile << "th, td{" << endl << "  padding; 15px;" << endl << "  text-align: center;" << endl << "}" << endl;
    myFile << "#t01 {" << endl << "  width: 100%;" << endl << "  background-color: #f1f1c1;" << endl << "}" << endl;
    myFile << "</style>" << endl << "</head>" << endl << "<body>" << endl << endl;
    if (num == 1)
    {
        myFile << "<h2> Sort Data Ascending :&nbsp" << Subject(inputNum + 1, col, header) << "</h2>" << endl << endl;
    }
    else
    {
        myFile << "<h2> Sort Data Descending :&nbsp"<< Subject(inputNum + 1, col, header) << "</h2>" << endl << endl;
    }
    myFile << "<table style=" << "width:40%>" << endl << "  <tr>" << endl << "    <th>ID</th>" << endl << "    <th>Marks</th>" << endl << "  </tr>" << endl;
    for(int i = 0; i < row; i++)
    {
        myFile << "  <tr>" << endl << "    <td>" << arrayID[i] << "</td>" << endl;
        myFile << "    <td>" << arrayMarks[i] << "</td>" << endl << "</tr>" << endl;
    }
    myFile << "</table>" << endl << "</body>" << endl << "</html>";
    return;
}


// ======================================== ACADEMIC REPORT =========================================== //
/////////////////////////////////////////////////////////////////////////////////////////////
void AcademicReportMenu(int row, int col, string header, string file)
{
    int AcademicReportMenu_Num = 0;
    ifstream inputFile;
    inputFile.open(file);

    if (!inputFile)
    {
        cout << "Invalid Data! Please Load Data!" << endl;
        Continue();
        MainMenu(row, col, header, file);
    }

    else
    do
    {
        cout << "___________________________________________________" << endl << endl;
        cout << "    ============= Academic Report =============     " << endl;

        subjectList(col, header);
        cout << "                 [" << col-1 << "] - Back To Main Menu" << endl;
        cout << "___________________________________________________" << endl << endl;
        cout << " Please Select A Subject." << endl;
        AcademicReportMenuChoice(AcademicReportMenu_Num, row, col, header, file);

    }
    while(AcademicReportMenu_Num != col-1);

    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
void AcademicReportMenuChoice(int inputNum, int row, int col, string header, string file)
{
    ofstream txtFile, myFile;
    string num;
    cin >> inputNum;
    system("CLS");
    int* arrayMarks = arrayInformation(inputNum+1, row, col, file);
    int* arrayID = arrayInformation(0, row, col, file);


    if(inputNum > 0 && inputNum < col-1)
    {
        string sub (Subject(inputNum+1, col, header));
        AcademicReport(arrayMarks, arrayID, inputNum, row, col, header, file);
        cin >> inputNum;
        if ( inputNum == 0 )
        {
            cout << "Files has been saved successfully." << endl;
            txtFile.open("Academic_Report_" + (sub) + ".txt");
            myFile.open("Academic_Report_" + (sub) + ".html");
            AcademicReportHTML(myFile, arrayMarks, arrayID, inputNum+1, row, col, header, file);
            SaveAcademicReport(txtFile, arrayMarks, arrayID, inputNum+1, row, col, header, file);
            txtFile.close();
            myFile.close();
            Continue();
        }
        Continue();
    }

    else if (inputNum == col-1)
        MainMenu(row, col, header, file);
    else if (cin.fail())
    {
        cout << "Invalid Input! Please Try Again!" << endl;
        cin.clear();
        getline(cin, num);
        Continue();
    }

    else
    {
        cout << "Invalid Input! Please Try Again!" << endl;
        Continue();
    }
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////
void AcademicReport(int* arrayMarks, int* arrayID, int AcademicReportMenu_Num, int row, int col, string header, string file)
{
    cout << "Academic Report : " << Subject(AcademicReportMenu_Num+1, col, header) << endl;
    cout << string(32, '=') << endl << endl;
    cout << string(32, '=') << endl;
    cout << "1. Statistics" << string(18, ' ') << "|" << endl;
    cout << string(32, '=') << endl << endl;

    cout << "===================================================================================================================" << endl;
    cout << "|     Minimum     |     Maximum     |     Median     |     Mean     |     Variance     |    Standard Deviation    |" << endl;
    cout << "===================================================================================================================" << endl;
    cout << "|" << setw(9) << Minimum(arrayMarks, row) << setw(9) << "|" << setw(9) << Maximum(arrayMarks, row) << setw(9) << "|"
         << setw(10) <<  Median(arrayMarks, arrayID, row) << setw(7) << "|" << setw(9) << Mean(arrayMarks, row) << setw(6) << "|"
         << setw(12) <<  Variance(arrayMarks, row) << setw(7) << "|" << setw(15) << StandardDeviation(arrayMarks, row) << setw(12) << "|" << endl;
    cout << "===================================================================================================================" << endl << endl << endl;


    return;
}

void SaveAcademicReport(ofstream &txtFile, int* arrayMarks, int* arrayID, int AcademicReportMenu_Num, int row, int col, string header, string file)
{
    txtFile << "Academic Report : " << Subject(AcademicReportMenu_Num+1, col, header) << endl;
    txtFile << string(32, '=') << endl << endl;
    txtFile << string(32, '=') << endl;
    txtFile << "1. Statistics" << string(18, ' ') << "|" << endl;
    txtFile << string(32, '=') << endl << endl;
    txtFile << "===================================================================================================================" << endl;
    txtFile << "|     Minimum     |     Maximum     |     Median     |     Mean     |     Variance     |    Standard Deviation    |" << endl;
    txtFile << "===================================================================================================================" << endl;
    txtFile << "|" << setw(9) << Minimum(arrayMarks, row) << setw(9) << "|" << setw(9) << Maximum(arrayMarks, row) << setw(9) << "|"
         << setw(10) <<  Median(arrayMarks, arrayID, row) << setw(7) << "|" << setw(9) << Mean(arrayMarks, row) << setw(6) << "|"
         << setw(12) <<  Variance(arrayMarks, row) << setw(7) << "|" << setw(15) << StandardDeviation(arrayMarks, row) << setw(12) << "|" << endl;
    txtFile << "===================================================================================================================" << endl << endl << endl;
}

void AcademicReportHTML(ofstream &myFile, int* arrayMarks, int* arrayID, int AcademicReportMenu_Num, int row, int col, string header, string file)
{
    myFile << "<!DOCTYPE html>" << endl << "<html>" << endl <<"<head>" << endl << "<style>" << endl;
    myFile << "table, th, td {" << endl << "  border: 2px double black; " << endl << "  border-collapse: collapse;" << endl << "}" << endl;
    myFile << "th, td{" << endl << "  padding; 15px; " << endl << "  text-align: center;" << "   background-color: #f1f1c1;"<< endl << "}" << endl;
    myFile << "</style>" << endl << "</head>" << endl << "<body>" << endl << "<h2> Academic Report :&nbsp" << Subject(AcademicReportMenu_Num+1, col, header) << "</h2>" << endl << endl;
    myFile << "<table style=" << "width:75%>" << endl << "<tr>" << endl;
    myFile << "  <th>Minimum</th>" << endl << "  <th>Maximum</th>" << endl << "  <th>Median</th>" << endl << "  <th>Mean</th>" << endl << "  <th>Variance</th>" << endl << " <th>Standard Deviation</th>" << endl;
    myFile << "</tr>" << endl << "<tr>" << endl;
    myFile << "  <td>" << Minimum(arrayMarks, row) << "</td>" << endl << "  <td>" << Maximum(arrayMarks, row) << "</td>" <<endl;
    myFile << "  <td>" << Median(arrayMarks, arrayID, row) << "</td>" << endl << "  <td>" << Mean(arrayMarks, row) << "</td>" << endl;
    myFile << "  <td>" << Variance(arrayMarks, row) << "</td>" << endl << "  <td>" << StandardDeviation(arrayMarks, row) << "</td>" << endl << endl;
    myFile << "</table>" << endl << endl << "</body>" << endl << "</html>" << endl;
}
/////////////////////////////////////////////////////////////////////////////////////////////

// =========================================== EXTRAS =============================================== //
/////////////////////////////////////////////////////////////////////////////////////////////
void Continue()
{
    system("pause");
    system("CLS");
    return;
}
/////////////////////////////////////////////////////////////////////////////////////////////
