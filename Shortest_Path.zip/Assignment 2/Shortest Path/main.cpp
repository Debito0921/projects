#include <stdio.h>
#include <limits.h>
#include <iostream>
#include <cmath>
#include <fstream>
#include <sstream>
#include <vector>
#include <iomanip>
#include <bits/stdc++.h>


using namespace std;

class Planet
{
    public:
    string p_name;
    int x,y,z;  // coordinates
    int weight,profit;
};

// Calculation for distance between each planets
class Matrix
{
    Planet edgelist[16][2];
    int V;
    int n = 10;
    float planetsArray[10][10];

    public:
        Matrix(int V){
            this->V = V;
            int i, j;
            for(i = 0; i < V; i++) {
                for(j = 0; j < V; j++) {
                    planetsArray[i][j] = 0;
                }
            }
        }

        void addEdge(Planet a, Planet b){
            // Adjacency Matrix
            planetsArray[converter(a)][converter(b)] = distance(a, b);
            planetsArray[converter(b)][converter(a)] = distance(a, b);

        }

        float getMatrix(int i, int j){
            return planetsArray[i][j];
        }

        float distance(Planet start, Planet dest){
            float dis = 0;
            int total = (start.x - dest.x)*(start.x - dest.x) + (start.y - dest.y)*(start.y - dest.y) + (start.z - dest.z)*(start.z - dest.z);
            dis = sqrt(total);
            return dis;
        }

        int converter(Planet p){
            string list1[10] = {"Planet_A","Planet_B","Planet_C","Planet_D","Planet_E","Planet_F","Planet_G","Planet_H","Planet_I","Planet_J"};
            for(int i = 0 ; i < sizeof(list1) ; i++){
                if(p.p_name == list1[i])
                    return i;
            }
        }
};

#define V 10

int minDistance(int dist[],
                bool sptSet[])
{

    // Initialize min value
    int min = INT_MAX, min_index;

    for (int v = 0; v < V; v++)
        if (sptSet[v] == false &&
                   dist[v] <= min)
            min = dist[v], min_index = v;

    return min_index;
}


void printPath(int parent[], int j) //print graph
{

    //base case : j is Planet_A ( source )
    if (parent[j] == - 1)
        return;

    //print every planets that stored inside the array
    printPath(parent, parent[j]);

    if (j == 1)
        cout<<" -> " << "Planet_B";
    if (j == 2)
        cout<<" -> " << "Planet_C";
    if (j == 3)
        cout<<" -> " << "Planet_D";
    if (j == 4)
        cout<<" -> " << "Planet_E";
    if (j == 5)
        cout<<" -> " << "Planet_F";
    if (j == 6)
        cout<<" -> " << "Planet_G";
    if (j == 7)
        cout<<" -> " << "Planet_H";
    if (j == 8)
        cout<<" -> " << "Planet_I";
    if (j == 9)
        cout<<" -> " << "Planet_J";

}

//print the distance of every planet from planet A
int printDistance(int dist[], int n,
                      int parent[])
{
    int source = 0;
    cout << "Planets" << setw(45) << "Distance from Planet_A ( Rounded Off )" << setw(10) << "Graph" << endl;
    for (int i = 0; i < V; i++)
    {
        if (i == 0){
            cout << "Planet_A" << setw(23) << dist[i] << setw(27) << "Planet_A";
            printPath(parent, i);
            cout<<endl;
        }
        if (i == 1){
            cout << "Planet_B" << setw(23) << dist[i] << setw(27) << "Planet_A";
            printPath(parent, i);
            cout<<endl;
        }
        if (i == 2){
            cout << "Planet_C" << setw(23) << dist[i] << setw(27) << "Planet_A";
            printPath(parent, i);
            cout<<endl;
        }
        if (i == 3){
            cout << "Planet_D" << setw(23) << dist[i] << setw(27) << "Planet_A";
            printPath(parent, i);
            cout<<endl;
        }
        if (i == 4){
            cout << "Planet_E" << setw(23) << dist[i] << setw(27) << "Planet_A";
            printPath(parent, i);
            cout<<endl;
        }
        if (i == 5){
            cout << "Planet_F" << setw(23) << dist[i] << setw(27) << "Planet_A";
            printPath(parent, i);
            cout<<endl;
        }
        if (i == 6){
            cout << "Planet_G" << setw(23) << dist[i] << setw(27) << "Planet_A";
            printPath(parent, i);
            cout<<endl;
        }
        if (i == 7){
            cout << "Planet_H" << setw(23) << dist[i] << setw(27) << "Planet_A";
            printPath(parent, i);
            cout<<endl;
        }
        if (i == 8){
            cout << "Planet_I" << setw(23) << dist[i] << setw(27) << "Planet_A";
            printPath(parent, i);
            cout<<endl;
        }
        if (i == 9){
            cout << "Planet_J" << setw(23) << dist[i] << setw(27) << "Planet_A";
            printPath(parent, i);
            cout<<endl;
        }
    }
}

//function to print the graph below
void printGraph(int parent[]){
    string graph[10][7];
    for(int i = 0 ; i < 10 ; i++){
        for(int j = 0 ; j < 7 ; j++)
            graph[i][j] = " ";
    }

    graph[0][3] = "A";
    graph[9][6] = "B";
    graph[6][0] = "C";
    graph[9][3] = "D";
    graph[6][6] = "E";
    graph[3][0] = "F";
    graph[3][3] = "G";
    graph[6][3] = "H";
    graph[9][0] = "I";
    graph[3][6] = "J";
    if((parent[5] == 0) || (parent[0] == 5)) //FA
    {
        graph[1][2] = "/";
        graph[2][1] = "/";
    }
    if((parent[6] == 0) || (parent[0] == 6)) //GA
    {
        graph[1][3] = "|";
        graph[2][3] = "|";
    }
    if((parent[9] == 0) || (parent[0] == 9)) //JA
    {
        graph[1][4]  = "\\";
        graph[2][5]  = "\\";
    }
    if((parent[2] == 5) || (parent[5] == 2)) //CF
    {
        graph[4][0] = "|";
        graph[5][0] = "|";
    }
    if((parent[2] == 6) || (parent[6] == 2)) //CG
    {
        graph[4][2] = "/";
        graph[5][1] = "/";
    }
    if((parent[7] == 5) || (parent[5] == 7)) //HF
    {
        graph[4][1] = "\\";
        graph[5][2] = "\\";
    }
    if((parent[7] == 6) || (parent[6] == 7)) //HG
    {
        graph[4][3] = "|";
        graph[5][3] = "|";
    }
    if((parent[7] == 9) || (parent[9] == 7)) //HJ
    {
        graph[4][5] = "/";
        graph[5][4] = "/";
    }
    if((parent[4] == 6) || (parent[6] == 4)) //EG
    {
        graph[4][4] = "\\";
        graph[5][5] = "\\";
    }
    if((parent[4] == 9) || (parent[9] == 4)) //EJ
    {
        graph[4][6] = "|";
        graph[5][6] = "|";
    }
    if((parent[8] == 2) || (parent[2] == 8)) //IC
    {
        graph[7][0] = "|";
        graph[8][0] = "|";
    }
    if((parent[8] == 7) || (parent[7] == 8)) //IH
    {
        graph[7][2] = "/";
        graph[8][1] = "/";
    }
    if((parent[8] == 3) || (parent[3] == 8)) //ID
    {
        graph[9][1] = "-";
        graph[9][2] = "-";
    }
    if((parent[1] == 3) || (parent[3] == 1)) //BD
    {
        graph[9][4] = "-";
        graph[9][5] = "-";
    }
    if((parent[1] == 7) || (parent[7] == 1)) //BH
    {
        graph[7][4] = "\\";
        graph[8][5] = "\\";
    }
    if((parent[1] == 4) || (parent[4] == 1)) //BE
    {
        graph[7][6] = "|";
        graph[8][6] = "|";
    }

    for(int i = 0 ; i < 10 ; i++){
        for(int j = 0 ; j < 7 ; j++)
            cout << graph[i][j];
        cout<<endl;
    }
}

//function to calculate the shortest distance here
void dijkstra(int graph[V][V], int source)
{
    int dist[V];
    bool flag[V];
    int parent[V]; //parent is to store the went through path into the parent array

    for (int i = 0; i < V; i++)
    {
        parent[0] = -1;
        dist[i] = INT_MAX; //initialize every distance to infinite
        flag[i] = false;  //initialize every vertex as false
    }

    dist[source] = 0;

    //calculation
    for (int count = 0; count < V - 1; count++)
    {

        int u = minDistance(dist, flag);
        flag[u] = true;
        for (int v = 0; v < V; v++)
            if (!flag[v] && graph[u][v] &&
                dist[u] + graph[u][v] < dist[v])
            {
                parent[v] = u;
                dist[v] = dist[u] + graph[u][v];
            }
    }

    printDistance(dist, V, parent);
    printGraph(parent);
}

int main()
{

    Planet p[10];
    fstream myfile;
    myfile.open ("A2planets.txt");

    string t;
    int count = 0;
    const int n = 10;
    while(getline (myfile, t)){
        vector<string> v;
        string::size_type i = 0;
        string::size_type j = t.find(" ");
        while (j != string::npos) {
            v.push_back(t.substr(i, j-i));
            i = ++j;
            j = t.find(" ", j);

            if (j == string::npos)
                v.push_back(t.substr(i, t.length()));
        }
        p[count].p_name = v[0];
        p[count].x = stoi(v[1]);
        p[count].y = stoi(v[2]);
        p[count].z = stoi(v[3]);
        p[count].weight = stoi(v[4]);
        p[count].profit = stoi(v[5]);
        count++;
    }

    Matrix st(10);
    //Add ALL THE EDGES INTO THE MATRIX
    // VERTICES 0  1  2  3  4  5  6  7  8  9
    // PLANETS  a  b  c  d  e  f  g  h  i  j
    st.addEdge(p[0],p[5]);
    st.addEdge(p[0],p[6]);
    st.addEdge(p[0],p[9]);
    st.addEdge(p[5],p[2]);
    st.addEdge(p[5],p[7]);
    st.addEdge(p[6],p[2]);
    st.addEdge(p[6],p[7]);
    st.addEdge(p[6],p[4]);
    st.addEdge(p[9],p[4]);
    st.addEdge(p[9],p[7]);
    st.addEdge(p[2],p[8]);
    st.addEdge(p[7],p[8]);
    st.addEdge(p[7],p[1]);
    st.addEdge(p[4],p[1]);
    st.addEdge(p[8],p[3]);
    st.addEdge(p[1],p[3]);

    int graph[10][10];
    for(int i = 0; i < 10 ; i++){
        for(int j = 0; j<10; j++){
            graph[i][j]= st.getMatrix(i,j);
        }
    }
    dijkstra(graph, 0);
    cout<<endl;
    cout<<endl;
    return 0;
}
