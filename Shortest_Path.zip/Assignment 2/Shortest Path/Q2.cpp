/*
#include <iostream>
#include <chrono>
#include <cstring>
#include <fstream>
#include <bits/stdc++.h>
#define INFINITY 9999

using namespace std;

void dijkstra(int G[10][5],int n,int startnode) {
   int cost[10][5],distance[10],pred[10];
   int visited[10],count,mindistance,nextnode,i,j;
   for(i=0;i<n;i++)
      for(j=0;j<n;j++)
   if(G[i][j]==0)
      cost[i][j]=INFINITY;
   else
      cost[i][j]=G[i][j];
   for(i=0;i<n;i++) {
      distance[i]=cost[startnode][i];
      pred[i]=startnode;
      visited[i]=0;
   }
   distance[startnode]=0;
   visited[startnode]=1;
   count=1;
   while(count<n-1) {
      mindistance=INFINITY;
      for(i=0;i<n;i++)
         if(distance[i]<mindistance&&!visited[i]) {
         mindistance=distance[i];
         nextnode=i;
      }
      visited[nextnode]=1;
      for(i=0;i<n;i++)
         if(!visited[i])
      if(mindistance+cost[nextnode][i]<distance[i]) {
         distance[i]=mindistance+cost[nextnode][i];
         pred[i]=nextnode;
      }
      count++;
   }
   for(i=0;i<n;i++)
   if(i!=startnode) {
      //cout<<"\nDistance of node"<<i<<"="<<distance[i];
      //cout<<"\nPath="<<i;
      j=i;
      do {
         j=pred[j];
         //cout<<"<-"<<j;
      }while(j!=startnode);
   }
}

int main(){
    int planet[10][5];
    int weight[10], profit[10];
    ifstream myfile;
    myfile.open ("A2planets.txt");

    string t;
    int index = 0;
    while(getline(myfile, t)){
        string planetDetails = "";
        int num = 0, i = 0;
        for (auto x : t){
            if (x == ' '){
                if (num > 0){
                    planet[index][i] = stoi(planetDetails);
                    i++;
                }
                planetDetails = "";
                num++;
            }
            else {
                planetDetails = planetDetails + x;
            }
        }
        index++;
    }
    myfile.close();


    for (int i = 0; i < 10; i++){
        for (int j = 0; j < 5; j++){
            cout << planet[i][j] << " ";
        }
        cout << endl;
    }

    dijkstra(planet,10,0);
    return 0;
}
*/
